//
//  ContentView.swift
//  icansee
//
//  Created by WenLi Lee on 2020/11/1.
//
import SwiftUI
import Foundation
import LocalAuthentication


      struct ContentView: View {
        
        var db :SQLiteConnect? = nil
        
        
          var body: some View {
            
            NavigationView{
              Home()
             .edgesIgnoringSafeArea(.all)
             .statusBar(hidden: true)
            }
            .navigationBarHidden(true)
          }
      }
      
      struct ContentView_Previews: PreviewProvider {
          static var previews: some View {
      
              ContentView()
          }
      }

struct select_Pulse: Codable {
    var heart: String
    var DataTime: String
}

class abc: ObservableObject {
    @Published var score = Home()
    
    func a() -> String {
        let a = "\(score.user)"
        return a
    }
}

      
      struct Home : View {
       
        @ObservedObject var bluetooth = settings_()//faceid
      
        @State var  birth = Date()
        
          @State var BIR = ""
          @State var signUp = false
          @State var user = ""
          @State var pass = ""
          @State var uid = ""
          @State var name = ""
          @State var sex = ""
          @State var phone = ""
          @State var email = ""
          @State var height = ""
          @State var weight = ""
          @State var visible = false
          @State var showAlert = false//登入錯
          @State var showAlert2 = false//註冊錯
          var color = Color(red: 255/255, green: 148/255, blue: 101/255)
          @State private var isActive: Bool = false
          @State private var isActive2: Bool = false//登入畫面
          @State var BP = ""
        private  var formatter: DateFormatter = {
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy/MM/dd"
            return formatter
            
            
        }()
        
        
//MARK:- ＬＯＧＩＮ防呆
        var alert: Alert {
            
            Alert(title: Text("登入失敗"), message: Text("請檢查帳號密碼是否輸入錯誤"), dismissButton: .cancel(Text("OK")))
            
        }
        var alert2: Alert {
            
            Alert(title: Text("註冊失敗"), message: Text("請檢查是否輸入錯誤"), dismissButton: .cancel(Text("OK")))
            
        }
//MARK:-
          var body: some View{
             
            ZStack(alignment: Alignment(horizontal: .center, vertical: .center)){
                          
                          ZStack{
                              
                              ZStack(alignment: Alignment(horizontal: .trailing, vertical: .bottom)) {
                                  
                                  Color("Color1")
                                      .clipShape(CShape())
                                  
                                  // adding another Curve...
                                  
                                  Path{path in
                                      
                                      // adding 40 for center...
                                      
                                      path.addArc(center: CGPoint(x: UIScreen.main.bounds.width - 120 , y: UIScreen.main.bounds.height - 50), radius: 40, startAngle: .zero, endAngle: .init(degrees: 180), clockwise: true)
                                  }
                                  .fill(Color.white)
                                  
                                  // adding Buttons...
                                  
                                  Button(action: {
                                      
                                      withAnimation(.easeIn){
                                          
                                          self.signUp = false
                                      }
                                      
                                  }) {
                                      
                                      Image(systemName: signUp ? "xmark" : "person.fill")
                                          .font(.system(size: 25, weight: .bold))
                                          .foregroundColor(Color("Color1"))
                                  }
                                  .offset(x: -110, y: -50)
                                  // disabling Button When its not Use...
                                  .disabled(signUp ? false : true)
                                  
                                  Button(action: {
                                      
                                      withAnimation(.easeOut){
                                          
                                          self.signUp = true
                                      }
                                      
                                  }) {
                                      
                                      Image(systemName: signUp ? "person.badge.plus.fill" : "xmark")
                                          .font(.system(size: signUp ? 26 : 25, weight: .bold))
                                          .foregroundColor(.white)
                                  }
                                  .offset(x: -30, y: -40)
                                  .disabled(signUp ? true : false)
                              }
                              // Moving View Up...
                      
                      
//MARK:- 登入
                      VStack(alignment: .leading, spacing: 25) {
                        Spacer(minLength: 20)
                          Text("Login")
                              .font(.system(size: 35, weight: .bold))
                              .foregroundColor(.white)
                          
                          Text("Username")
                              .foregroundColor(.white)
                              .padding(.top,10)
                          
                          VStack{
                              
                           TextField("Useraname", text: $user)
                            //Home(user:user)
                            
                              
                              Divider()
                                  .background(Color.white.opacity(0.5))
                          }
                          
                          Text("Password")
                              .foregroundColor(.white)
                              .padding(.top,10)
                          
                          VStack{
                            
                            if self.visible{
                                TextField("Paswword", text: $pass).autocapitalization(.none)
                              Divider().background(Color.white.opacity(0.5))//底線
                            }
                            else{
                                SecureField("Paswword", text: $pass).autocapitalization(.none)
                              Divider().background(Color.white.opacity(0.5))//底線
                            }
                          }
                        //pssword eyes
                        Button(action: {
                            self.visible.toggle()
                        }){
                            Image(systemName: self.visible ? "eye.slash.fill" : "eye.fill").foregroundColor(Color.white)
                        }
                        .padding()
                        .background(Color("Color1"))
                        .offset(x: 330, y: -80)
                          
                          HStack{
                              
                              Spacer()
                            
                            /*NavigationLink(destination: pageone(user: $user) , isActive: self.$isActive) {
                                Text("")
                            }*/
                            
                        
                            NavigationLink(destination: pageone(user: $user) , isActive: self.$isActive) {
                                Text("")
                            }
                            NavigationLink(destination: ContentView() , isActive: self.$isActive2) {
                                Text("")
                            }
                        
 //MARK:- 登入webservice
                              Button(action: {
                                self.isActive = true
                                
                                //let y = re.select_Pulse(num: "Biggg", startday: "", endday: "", choose: "2").data(using: .utf8)!
                                
                                //let re = WebService();
                                //JSONDecoder = re.select_Pulse(num: "Biggg", startday: "", endday: "", choose: "1")
                                //print(w1);
                               
            //face id----------------------------------------------
                             /*
                                if(bluetooth.bluetooth == true)
                                {
                                    user="Biggg"
                                    let context:LAContext = LAContext()
                                    if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: nil)
                                    {
                                        context.evaluatePolicy(LAPolicy.deviceOwnerAuthenticationWithBiometrics, localizedReason: "Message") {(good, errpr) in
                                            if good{
                                                self.isActive = true
                                            }
                                            else
                                            {
                                               print("tryagain")
                                            }
                                        }
                                    }
                                }*/
                                
            //webservice----------------------------------------------
                            /*
                                let re = WebService();
                                let w1 = re.Login(userid: user, userpass: pass)
                                //let context :LAContext = LAContext()
                              
                                
                                print(w1);
                                //let re = WebService();
                                //let w1 = re.Login(userid: user, userpass: pass)
                                if w1 == "1"
                                {
                                    
                                    self.isActive = true
                                    
                                }
                                else if w1 == "0"
                                {
                                    self.showAlert = true
                                } */
                                

                              })
                              {
                                  Text("Login")
                                      .fontWeight(.bold)
                                      .foregroundColor(Color("Color1"))
                                      .padding(.vertical)
                                      .padding(.horizontal,45)
                                      .background(Color.white)
                                      .clipShape(Capsule())
                                
                              }
                              .alert(isPresented: $showAlert, content: { self.alert })
                              Spacer()
                          }
                          
                          .padding(.top)
                          
                          Spacer(minLength: 0)
                      }
                    
                      .padding(.top,(UIApplication.shared.windows.first?.safeAreaInsets.top)! + 25)//login字的位置
                      .padding()
                    
                      
                  }
                  .offset(y: signUp ? -UIScreen.main.bounds.height + (UIScreen.main.bounds.height < 750 ? 100 : 200) : 0)
                  .zIndex(1)
                  // Moving View Front In Stack...
                
                
                  
                
//MARK:- 註冊
                  
                  VStack(alignment: .leading, spacing: 25) {
                    Spacer(minLength: 20)
                    Text("Sign Up")
                          .font(.system(size: 35, weight: .bold))
                          .foregroundColor(Color("Color1"))
                    ScrollView(.vertical, showsIndicators: false) {
                        
                    Group{
                     
                      VStack(alignment: .leading, spacing: 10){
                        Text("帳號").foregroundColor(Color("Color1"))
                        TextField("帳號", text: $user)
                        Divider().background(Color("Color1").opacity(0.5))
                      }
                        
                        VStack(alignment: .leading, spacing: 10){
                          Text("密碼").foregroundColor(Color("Color1"))
                          TextField("密碼", text: $pass)
                          Divider().background(Color("Color1").opacity(0.5))
                        }
                        
                        VStack(alignment: .leading, spacing: 10){
                          Text("姓名").foregroundColor(Color("Color1"))
                          TextField("姓名", text: $name)
                          Divider().background(Color("Color1").opacity(0.5))
                        }
                    
                   
                      VStack(alignment: .leading, spacing: 10){
                        
                        DatePicker("生日", selection: $birth, displayedComponents: .date).foregroundColor(Color("Color1"))
                        Text("\(birth, formatter: formatter)")
                        
                        
                        //TextField(date, text: $BIR)
                            //.padding(.top,10)
                        
                        Divider().background(Color("Color1").opacity(0.5))
                      }
                    }
                        
                    
                    VStack(alignment: .leading, spacing: 10){
                        Text("性別").foregroundColor(Color("Color1"))
                        RadioButtonGroups { selected in
                            print("Selected Gender is: \(selected)")
                        if(selected=="男"){
                            sex = "1"
                        }
                        else{
                            sex = "2"
                        }}
                        Divider().background(Color("Color1").opacity(0.5))
                    }
                    VStack(alignment: .leading, spacing: 10){
                          Text("身分證字號").foregroundColor(Color("Color1"))
                          TextField("身分證字號", text: $uid)
                          Divider().background(Color("Color1").opacity(0.5))
                        }
               
                        VStack(alignment: .leading, spacing: 10){
                          Text("聯絡電話").foregroundColor(Color("Color1"))
                          TextField("聯絡電話", text: $phone)
                          Divider().background(Color("Color1").opacity(0.5))
                        }
                        VStack(alignment: .leading, spacing: 10){
                          Text("信箱").foregroundColor(Color("Color1"))
                          TextField("信箱", text: $email)
                          Divider().background(Color("Color1").opacity(0.5))
                        }
                        VStack(alignment: .leading, spacing: 10){
                          Text("身高").foregroundColor(Color("Color1"))
                          TextField("身高", text: $height)
                          Divider().background(Color("Color1").opacity(0.5))
                        }
                        VStack(alignment: .leading, spacing: 10){
                          Text("體重").foregroundColor(Color("Color1"))
                          TextField("體重", text: $weight)
                          Divider().background(Color("Color1").opacity(0.5))
                        }
                     
                      HStack{
                          
                          Spacer()
//MARK:- 註冊webservice
                          Button(action: {
                            let date = formatter.string(from: birth)
                            let w_newid: String = user
                            let w_newpass: String = pass
                            let w_ID: String = uid
                            //let w_birth: String = date
                            let w_name: String = name
                            let w_sex: String = sex
                            let w_phone: String = phone
                            let w_email: String = email
                            let w_height: String = height
                            let w_weight: String = weight
                            let re = WebService();
                            let w1 = re.SignUp(newid: w_newid, name: w_name, ID: w_ID, birth: date, sex: w_sex, newpass: w_newpass, email: w_email, phone: w_phone, height: w_height, weight: w_weight)//空 防呆________________________
                            if w1 == true
                            {
                                self.isActive2 = true                                    
                            }
                            else if w1 == false
                            {
                                self.showAlert2 = true
                            }
                            }){
                              
                              Text("Sign Up")
                                  .fontWeight(.bold)
                                  .foregroundColor(.white)
                                  .padding(.vertical)
                                  .padding(.horizontal,45)
                                  .background(Color("Color1"))
                                  .clipShape(Capsule())
                            
                          }
                          .alert(isPresented: $showAlert2, content: { self.alert2 })
                          Spacer()
                      }
                      .padding(.top)
                    }
                      Spacer(minLength: 80)
                  }
                  .padding(.top,(UIApplication.shared.windows.first?.safeAreaInsets.top)! + 50)
                  .padding()
                  
              }
              
              .background(Color.white.edgesIgnoringSafeArea(.all))
              // changing user Interface Style...
              .preferredColorScheme(signUp ? .light : .dark)
            }
      
      }


//MARK:- 頁面滑動特效
      
struct CShape : Shape {
    
    func path(in rect: CGRect) -> Path {

        return Path{path in
            
            // starting from bottom...
            
            path.move(to: CGPoint(x: rect.width, y: rect.height - 50))
            path.addLine(to: CGPoint(x: rect.width, y: 0))
            path.addLine(to: CGPoint(x: 0, y: 0))
            path.addLine(to: CGPoint(x: 0, y: rect.height - 50))
            
            // adding curve...
            
            // total raidus of curve = 80
            path.addArc(center: CGPoint(x: rect.width - 40, y: rect.height - 50), radius: 40, startAngle: .zero, endAngle: .init(degrees: 180), clockwise: false)
        }
    }
}
//MARK:- RadioButton
struct RadioButtonField: View {
    let id: String
    let label: String
    let size: CGFloat
    let color: Color
    let textSize: CGFloat
    let isMarked:Bool
    let callback: (String)->()
    
    init(
        id: String,
        label:String,
        size: CGFloat = 20,
        color: Color = Color.black,
        textSize: CGFloat = 14,
        isMarked: Bool = false,
        callback: @escaping (String)->()
        ) {
        self.id = id
        self.label = label
        self.size = size
        self.color = color
        self.textSize = textSize
        self.isMarked = isMarked
        self.callback = callback
    }
    var body: some View {
            Button(action:{
                self.callback(self.id)
            }) {
                HStack(alignment: .center, spacing: 10) {
                    Image(systemName: self.isMarked ? "largecircle.fill.circle" : "circle")
                        .renderingMode(.original)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: self.size, height: self.size)
                    Text(label)
                        .font(Font.system(size: textSize))
                    Spacer()
                }.foregroundColor(self.color)
            }
            .foregroundColor(Color.white)
        }
    }
//MARK:- Group of Radio Buttons
enum Gender: String {
    case male = "男"
    case female = "女"
}

struct RadioButtonGroups: View {
    let callback: (String) -> ()

    @State var selectedId: String = ""
    
    var body: some View {
        HStack {
            radioMaleMajority
            radioFemaleMajority
        }
    }
    
    var radioMaleMajority: some View {
        RadioButtonField(
            id: Gender.male.rawValue,
            label: Gender.male.rawValue,
            isMarked: selectedId == Gender.male.rawValue ? true : false,
            callback: radioGroupCallback
        )
    }
    
    var radioFemaleMajority: some View {
        RadioButtonField(
            id: Gender.female.rawValue,
            label: Gender.female.rawValue,
            isMarked: selectedId == Gender.female.rawValue ? true : false,
            callback: radioGroupCallback
        )
    }
    
    func radioGroupCallback(id: String) {
        selectedId = id
        callback(id)
    }
}

/*struct Home_Previews: PreviewProvider {
    static var previews: some View {
        Home()
    }
}
*/
