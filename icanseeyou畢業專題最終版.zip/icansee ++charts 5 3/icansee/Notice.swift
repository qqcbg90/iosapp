//
//  Notice.swift
//  icansee
//
//  Created by WenLi Lee on 2020/12/8.
//

import SwiftUI
import Combine
import SafariServices
//推播設定


struct Notice: View {
    
    @Binding var user : String
    //
    @State private var a:Bool = false
    @State private var b:Bool = false
    @State private var c:Bool = false
    @State private var d:Bool = false
    @State private var a1:Bool = true
    @State private var b1:Bool = true
    @State private var c1:Bool = true
    @State private var d1:Bool = true

    
    //
    
    @State var showWebView = false
    
    /*
    @ObservedObject var content = settings_()//家屬數值異常提醒
    @ObservedObject var faceid = settings_()//開啟face id
    @ObservedObject var sport = settings_() //運動量是否足夠
    @ObservedObject var screen = settings_()//螢幕使用過長
    @ObservedObject var roomtemp = settings_()//是否開啟冷暖氣
    @ObservedObject var medicine = settings_()//提醒服藥
    @ObservedObject var hightNum = settings_()//數值異常提醒
    @ObservedObject var login = settings_()//數值異常提醒
    */
    
    //
    @State var final = false
    @State private var showAlert = false
    @Environment(\.openURL) var openURL
    //
    
    var body: some View {
        ZStack(alignment: Alignment(horizontal: .center, vertical: .center)){
            VStack(alignment: .leading, spacing: 25) {
                Spacer(minLength: 20)
                VStack(alignment: .leading, spacing: 10){
                    
                    let data = re.profile(uid: user, choose: "push")
                    let ddd = data.components(separatedBy: first)
                    let s = ddd[1]
                    let s2 = ddd[3]
                    let s3 = ddd[5]
                    let s4 = ddd[7]
                    //
                    let d2 = re.profile(uid: user, choose: "line")
                   
                    
                    
                    Section() {
                        
                        
                        if(d2 == "Yes")
                        {
                            Text("已連動LINE  ◡̈").foregroundColor(.blue)
                           .font(.system(size: 20))
                        }
                        else
                        {
                            Text("尚未連動LINE ⍤")
                           .foregroundColor(.red)
                           .font(.system(size: 20))
                        }
                        
                            
                            Button(action: {
                                self.showWebView.toggle()
                            })
                            {
                                Text("連動LINE")
                                    .fontWeight(.bold)
                                    .foregroundColor(Color.white)
                                    .padding(.vertical)
                                    .padding(.horizontal,45)
                                    .background(Color("Color1"))
                                    .clipShape(Capsule())
                            }
                            .sheet(isPresented: $showWebView, content: {
                                    WebView(url: URL(string: "http://120.125.78.213:8080/callback.aspx?id=\(user)")!)
                            })
  
                        Text("連動LINE才能啟動以下功能！").foregroundColor(Color("Color1"))
                    }
                    
                    Divider()
                    
                    Section() {
                        
                        if(d2 == "No")
                        {
                            Toggle(isOn: $a) {
                                Text("三天未運動通知")
                                    .foregroundColor(Color("Color1"))
                                
                            }.toggleStyle(SwitchToggleStyle(tint: .blue))
                            .disabled(true)
                            //
                            Toggle(isOn: $b) {
                                Text("三天未登入通知")
                                    .foregroundColor(Color("Color1"))
                                
                            }.toggleStyle(SwitchToggleStyle(tint: .blue))
                            .disabled(true)
                            //
                            Toggle(isOn: $c) {
                                Text("接收家屬異常通知")
                                    .foregroundColor(Color("Color1"))
                                
                            }.toggleStyle(SwitchToggleStyle(tint: .blue))
                            .disabled(true)
                            //
                            Toggle(isOn: $d) {
                                Text("接收自己異常通知")
                                    .foregroundColor(Color("Color1"))
                                
                            }.toggleStyle(SwitchToggleStyle(tint: .blue))
                            .disabled(true)
                        }
                        else
                        {
                            if(s == "on ")
                            {
                                Toggle(isOn: $a1)
                                {
                                    Text("三天未運動通知")
                                        .foregroundColor(Color("Color1"))
                                
                                }.toggleStyle(SwitchToggleStyle(tint: .blue))
                               
                            }
                            
                            else
                            {
                                Toggle(isOn: $a) {
                                    Text("三天未運動通知")
                                        .foregroundColor(Color("Color1"))
                                }.toggleStyle(SwitchToggleStyle(tint: .blue))
                            }
                            if(s2 == "on ")
                            {
                                Toggle(isOn: $b1) {
                                    Text("三天未登入通知")
                                        .foregroundColor(Color("Color1"))
                                    
                                }.toggleStyle(SwitchToggleStyle(tint: .blue))
                              

                            }
                            else
                            {
                                Toggle(isOn: $b) {
                                    Text("三天未登入通知")
                                        .foregroundColor(Color("Color1"))
                                    
                                }.toggleStyle(SwitchToggleStyle(tint: .blue))
                            }
                            if(s3 == "on ")
                            {
                                Toggle(isOn: $c1) {
                                    Text("接收家屬異常通知")
                                        .foregroundColor(Color("Color1"))
                                    
                                }.toggleStyle(SwitchToggleStyle(tint: .blue))
                            }
                            else
                            {
                                Toggle(isOn: $c) {
                                    Text("接收家屬異常通知")
                                        .foregroundColor(Color("Color1"))
                                    
                                }.toggleStyle(SwitchToggleStyle(tint: .blue))
                            }
                            if(s4 == "on ")
                            {
                                Toggle(isOn: $d1) {
                                    Text("接收自己異常通知")
                                        .foregroundColor(Color("Color1"))
                                    
                                }.toggleStyle(SwitchToggleStyle(tint: .blue))
                            }
                            else
                            {
                                Toggle(isOn: $d) {
                                    Text("接收自己異常通知")
                                        .foregroundColor(Color("Color1"))
                                    
                                }.toggleStyle(SwitchToggleStyle(tint: .blue))
                            }
                        }
                        
                    }
                }
                
                
                
                HStack(){
                    
                    Spacer()
                    
                    //MARK:- webservice
                    Button(action: {
                        var sw1 = ""
                        var sw2 = ""
                        var sw3 = ""
                        var sw4 = ""
                        //
                        let data = re.profile(uid: user, choose: "push")
                        let ddd2 = data.components(separatedBy: first)
                        //
                        let s_2 = ddd2[1]
                        let s2_2 = ddd2[3]
                        let s3_2 = ddd2[5]
                        let s4_2 = ddd2[7]
                        //
                        
                        if(a1 == false && a == false)
                        {
                            sw1 = "off"
                        }
                        else if (a1 == true && a == true)
                        {
                            sw1 = "on"
                        }
                        else{
                            sw1 = s_2
                        }
                        //
                        
                        if(b1 == false && b == false)
                        {
                           sw2 = "off"
                        }
                        else if (b1 == true && b == true)
                        {
                            sw2 = "on"
                        }
                        else{
                            sw2 = s2_2
                        }
                        //
                        
                        if(c1 == false && c == false)
                        {
                           sw3 = "off"
                        }
                        else if (c1 == true && c == true)
                        {
                            sw3 = "on"
                        }
                        else{
                            sw3 = s3_2
                        }
                        //
                        
                        if(d1 == false && d == false)
                        {
                           sw4 = "off"
                        }
                        else if (d1 == true && d == true)
                        {
                            sw4 = "on"
                        }
                        else
                        {
                            sw4 = s4_2
                        }
                        
                        //
                        final = re.update_profile(uid: user, choose: "push", email: "", phone: "", height: "", weight: "", password: "", newpassword: "", onoff1: sw1, onoff2: sw2, onoff3: sw3, onoff4: sw4)
                        
                        self.showAlert = true
                        
                    })
                    {
                        Text("Save")
                            .fontWeight(.bold)
                            .foregroundColor(Color.white)
                            .padding(.vertical)
                            .padding(.horizontal,45)
                            .background(Color("Color1"))
                            .clipShape(Capsule())
                        
                    }
                    .alert(isPresented: $showAlert) { () -> Alert in
                        
                        var title = ""
                        var message = ""
                        if(final == true)
                        {
                            title = "成功"
                            message = "推播修改成功"
                        }
                        else
                        {
                            title = "失敗"
                            message = "推播修改失敗"
                        }
                        
                        return Alert(title: Text(title), message: Text(message), dismissButton: .cancel(Text("OK")))
                    }
                    Spacer()
                }
                
                .padding(.top)
                
                Spacer(minLength: 0)
            }
            .padding()
            
        }.background(Color.white.edgesIgnoringSafeArea(.all))
        .edgesIgnoringSafeArea(.all)
        .statusBar(hidden: true)
        
    }
}


struct WebView: UIViewControllerRepresentable {

    let url: URL

    func makeUIViewController(context: UIViewControllerRepresentableContext<WebView>) -> SFSafariViewController {
        return SFSafariViewController(url: url)
    }

    func updateUIViewController(_ uiViewController: SFSafariViewController, context: UIViewControllerRepresentableContext<WebView>) {
    }

}

struct Notice_Previews: PreviewProvider {
    static var previews: some View {
        Notice(user: .constant(""))
    }
}

public class LINE {
 public var Url:String = "http://120.125.78.213:8080/callback.aspx"
 public var Host:String = "120.125.78.213:8080"
}
