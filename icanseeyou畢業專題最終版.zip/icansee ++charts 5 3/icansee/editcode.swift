//
//  editcode.swift
//  icansee
//
//  Created by WenLi Lee on 2021/2/21.
//

import SwiftUI

struct editcode: View {
    
    class TextLimiter: ObservableObject {
        private let limit: Int
        
        init(limit: Int) {
            self.limit = limit
        }
        
        @Published var hasReachedLimit = false
        @Published var value = "" {
            didSet {
                if value.count > self.limit {
                    value = String(value.prefix(self.limit))
                    self.hasReachedLimit = true
                } else {
                    self.hasReachedLimit = false
                }
            }
        }
    }
    //
    
    @ObservedObject var oldpass = TextLimiter(limit: 10)
    @ObservedObject var pass = TextLimiter(limit: 10)
    @ObservedObject var repass = TextLimiter(limit: 10)
    //
    @Binding var user : String
    //
    
    //@State var oldpass = ""
    //@State var pass = ""
    //@State var repass = ""
    
    //
    @State var final = ""
    @State var d = "no"
    //
    @State private var showAlert = false
    @State var visible1 = false
    @State var visible2 = false
    @State var visible3 = false
    
    
    var body: some View {
        ZStack(alignment:.bottomTrailing){
            VStack(alignment: .leading, spacing: 25) {
                Spacer(minLength: 20)
                Text("修改密碼")
                    .font(.system(size: 35, weight: .bold))
                    .foregroundColor(Color("Color1"))
                ScrollView(.vertical, showsIndicators: false) {
                    
                    Group{
                        
                        VStack(alignment: .leading, spacing: 10){
                            Text("請輸入舊密碼").foregroundColor(Color("Color1"))
                            if self.visible1{
                                TextField("舊密碼", text: $oldpass.value).autocapitalization(.none).keyboardType(.alphabet)
                                    .foregroundColor(Color(.black))
                                    .autocapitalization(.none)
                                Divider().background(Color("Color1").opacity(0.5))
                                // TextField("Paswword", text: $pass).autocapitalization(.none)
                                // Divider().background(Color.white.opacity(0.5))//底線
                            }
                            else{
                                SecureField("舊密碼", text: $oldpass.value)
                                    .foregroundColor(Color(.black))
                                    .autocapitalization(.none)
                                Divider().background(Color("Color1").opacity(0.5))
                                //   SecureField("Paswword", text: $pass).autocapitalization(.none)
                                // Divider().background(Color.white.opacity(0.5))//底線
                            }
                            Button(action: {
                                self.visible1.toggle()
                            }){
                                Image(systemName: self.visible1 ? "eye.fill" : "eye.slash.fill").foregroundColor(Color.black)
                            }
                            .background(Color.white)
                            .offset(x: 350, y: -35)
                            
                            
                            /*           TextField("舊密碼", text: $oldpass)
                             .foregroundColor(Color(.black))
                             .autocapitalization(.none)
                             Divider().background(Color("Color1").opacity(0.5))
                             */
                        }
                        
                        VStack(alignment: .leading, spacing: 10){
                            Text("請輸入新密碼(5-10位英數字)").foregroundColor(Color("Color1"))
                            if self.visible2{
                                TextField("新密碼", text: $pass.value).autocapitalization(.none).keyboardType(.alphabet)
                                    .foregroundColor(Color(.black))
                                    .autocapitalization(.none)
                                Divider().background(Color("Color1").opacity(0.5))
                                // TextField("Paswword", text: $pass).autocapitalization(.none)
                                // Divider().background(Color.white.opacity(0.5))//底線
                            }
                            else{
                                SecureField("新密碼", text: $pass.value)
                                    .foregroundColor(Color(.black))
                                    .autocapitalization(.none)
                                Divider().background(Color("Color1").opacity(0.5))
                                //   SecureField("Paswword", text: $pass).autocapitalization(.none)
                                // Divider().background(Color.white.opacity(0.5))//底線
                            }
                            Button(action: {
                                self.visible2.toggle()
                            }){
                                Image(systemName: self.visible2 ? "eye.fill" : "eye.slash.fill").foregroundColor(Color.black)
                            }
                            .background(Color.white)
                            .offset(x: 350, y: -35)
                            /*   TextField("新密碼", text: $pass)
                             .foregroundColor(Color(.black))
                             .autocapitalization(.none)
                             Divider().background(Color("Color1").opacity(0.5))
                             */
                        }
                        
                        VStack(alignment: .leading, spacing: 10){
                            Text("請再輸入一次新密碼").foregroundColor(Color("Color1"))
                            if self.visible3{
                                TextField("確認密碼", text: $repass.value)
                                    .foregroundColor(Color(.black))
                                    .autocapitalization(.none)
                                Divider().background(Color("Color1").opacity(0.5))
                                // TextField("Paswword", text: $pass).autocapitalization(.none)
                                // Divider().background(Color.white.opacity(0.5))//底線
                            }
                            else{
                                SecureField("確認密碼", text: $repass.value)
                                    .foregroundColor(Color(.black))
                                    .autocapitalization(.none)
                                Divider().background(Color("Color1").opacity(0.5))
                                //   SecureField("Paswword", text: $pass).autocapitalization(.none)
                                // Divider().background(Color.white.opacity(0.5))//底線
                            }
                            Button(action: {
                                self.visible3.toggle()
                            }){
                                Image(systemName: self.visible3 ? "eye.fill" : "eye.slash.fill")
                                    .foregroundColor(Color.black)
                            }
                            .background(Color.white)
                            .offset(x: 350, y: -35)
                            /*      TextField("確認密碼", text: $repass)
                             .foregroundColor(Color(.black))
                             .autocapitalization(.none)
                             Divider().background(Color("Color1").opacity(0.5))
                             */
                        }
                    }
                    
                    HStack{
                        
                        Spacer()
                        //MARK:- webservice
                        Button(action: {
                            
                            if(pass.value == repass.value)
                            {
                                final = re.update_profile2(uid: user, choose: "password", email: "", phone: "", height: "", weight: "", password: oldpass.value, newpassword: repass.value, n1: "", n2: "", n3: "", n4: "")
                                d = "ok"
                            }
                            else
                            {
                                d = "no"
                            }
                            self.showAlert = true
                            
                        }){
                            Text("Save")
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                                .padding(.vertical)
                                .padding(.horizontal,45)
                                .background(Color("Color1"))
                                .clipShape(Capsule())
                            
                        }
                        .alert(isPresented: $showAlert) { () -> Alert in
                            
                            var title = ""
                            var message = ""
                            if(d == "ok")
                            {
                                if(final == "完成")
                                {
                                    title = "成功"
                                    message = "密碼修改成功"
                                }
                                else
                                {
                                    title = "失敗"
                                    message = final
                                }
                            }
                            else
                            {
                                title = "失敗"
                                message = "請確認輸入的兩次新密碼是否相同"
                            }
                            return Alert(title: Text(title), message: Text(message), dismissButton: .cancel(Text("OK")))
                        }
                        
                        Spacer()
                    }
                    .padding(.top)
                }
                Spacer(minLength: 80)
            }
            .padding(.top,(UIApplication.shared.windows.first?.safeAreaInsets.top)! + 50)
            .padding()
            
        }.background(Color.white.edgesIgnoringSafeArea(.all))
        .edgesIgnoringSafeArea(.all)
        .statusBar(hidden: true)
        
    }
}

struct editcode_Previews: PreviewProvider {
    static var previews: some View {
        editcode(user: .constant(""))
    }
}
