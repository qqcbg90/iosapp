//
//  HeartRecord.swift
//  icansee
//
//  Created by WenLi Lee on 2020/11/14.
//

import SwiftUI

struct HeartRecord: View {
    var body: some View {
        NavigationView{
            
            heartRecord()
                .navigationBarHidden(true)
                .edgesIgnoringSafeArea(.all)
                .navigationBarHidden(true)
        }
        
    }
}


struct HeartRecord_Previews: PreviewProvider {
    static var previews: some View {
        HeartRecord()
            
    }
}

struct heartRecord : View {
    
    @State var tab = "Today"
    @State var subTab = "Week"
    @State var tab3 = "Month"
    @Namespace var animation
    @State var dailyNum = [
        
        // Last 7 Days....
            DailySales(day: Calendar.current.date(byAdding: .day, value: -6, to: Date())!, value: 200, show: true),
            DailySales(day: Calendar.current.date(byAdding: .day, value: -5, to: Date())!, value: 710, show: false),
            DailySales(day: Calendar.current.date(byAdding: .day, value: -4, to: Date())!, value: 330, show: false),
            DailySales(day: Calendar.current.date(byAdding: .day, value: -3, to: Date())!, value: 519, show: false),
            DailySales(day: Calendar.current.date(byAdding: .day, value: -2, to: Date())!, value: 150, show: false),
            DailySales(day: Calendar.current.date(byAdding: .day, value: -1, to: Date())!, value: 229, show: false),
            DailySales(day: Date(), value: 669, show: false)
    ]
    
    @State var edges = UIApplication.shared.windows.first?.safeAreaInsets
    
    var body: some View{
        
        VStack{
            
            HStack{
                
                Button(action: {}) {
                    
                    /*Image("menu")
                        .renderingMode(.template)
                        .foregroundColor(.white)*/
                }
                
                Spacer(minLength: 0)
                
                Button(action: {}) {
                    
                    Image("bell")
                        .renderingMode(.template)
                        .foregroundColor(.white)
                }
            }
            .padding()
            
            
            
            HStack(spacing: 0){
                
                tabbutton(selected: $tab, title: "Today", animation: animation)
                
                tabbutton(selected: $tab, title: "Week", animation: animation)
                
                tabbutton(selected: $tab, title: "Month", animation: animation)
            }
            .background(Color.white.opacity(0.08))
            .clipShape(Capsule())
            .padding(.horizontal)
            

            
            // Or YOu can use Foreach Also...
            VStack(spacing: 20){
                
                HStack(spacing: 15){
                    
                    DatasView(data: myData[0])
                    
                    DatasView(data: myData[1])
                }
                
                HStack(spacing: 15){
                    
                    DatasView(data: myData[2])
                    
                    DatasView(data: myData[3])
                    
                    DatasView(data: myData[4])
                }
            }
            .padding(.horizontal)
            
            ZStack{
                
                Color.white
                    .clipShape(CustomCorners(corners: [.topLeft,.topRight], size: 45))
                    .ignoresSafeArea(.all, edges: .bottom)
                
                VStack{
                    
                    HStack{
                        
                        Text("Daily Data")
                            .font(.title2)
                            .foregroundColor(.black)
                        
                        Spacer(minLength: 0)
                    }
                    .padding()
                    .padding(.top,10)
                    
                    HStack(spacing: 10){
                        
                        ForEach(dailyNum.indices,id: \.self){i in
                            
                            // For Toggling Show Button....
                            
                            GraphView(data: dailyNum[i], allData: dailyNum)
                                .onTapGesture {
                                    
                                    withAnimation{
                                        
                                        // toggling all other...
                                        
                                        for index in 0..<dailyNum.count{
                                            
                                            dailyNum[index].show = false
                                        }
                                        
                                        dailyNum[i].show.toggle()
                                    }
                                }
                            
                            // sample Sapcing For Spacing Effect..
                            
                            if dailyNum[i].value != dailyNum.last!.value{
                                
                                Spacer(minLength: 0)
                            }
                        }
                    }
                    .padding(.horizontal,30)
                    .padding(.bottom,edges!.bottom == 0 ? 15 : 0)
                }
            }
            .padding(.top,20)
        }
        .background(Color("lightorang").ignoresSafeArea(.all, edges: .all))
    }
}


struct tabbutton : View {
    
    @Binding var selected : String
    var title : String
    var animation : Namespace.ID
    
    var body: some View{
        
        Button(action: {
            
            withAnimation(.spring()){
                
                selected = title
            }
            
        }) {
            
            ZStack{
                
                // Capsule And Sliding Effect...
                
                Capsule()
                    .fill(Color.clear)
                    .frame(height: 45)
                
                if selected == title{
                    
                    Capsule()
                        .fill(Color.white)
                        .frame(height: 45)
                    // Mathced Geometry Effect...
                        .matchedGeometryEffect(id: "Tab", in: animation)
                }
                
                Text(title)
                    .foregroundColor(selected == title ? .black : .white)
                    .fontWeight(.bold)
            }
        }
    }
}

// Sample Model Data....

struct Datas: Identifiable {
    
    var id = UUID().uuidString
    var title : String
    var value : String
    var color : Color
}

var myData = [

    Datas(title: "心跳", value: "110bmp", color: Color.orange),
    Datas(title: "血氧", value: "100%", color: Color.red),
    Datas(title: "血壓", value: "109mmHg", color: Color.blue),
    Datas(title: "血糖", value: "130mg/dl", color: Color.pink),
    Datas(title: "體溫", value: "36.7  度", color: Color.purple),
]

// Daily Sold Model And Data....

struct DailySales : Identifiable {
    var id = UUID().uuidString
    var day : Date
    var value : CGFloat
    var show : Bool
}
//心跳血氧血壓數值顯示的框框
struct DatasView : View {
    
    var data : Datas
    
    var body: some View{
        
        ZStack{
            
            HStack{
                
                VStack(alignment: .leading, spacing: 22) {
                    
                    Text(data.title)
                        .foregroundColor(.white)
                    
                    Text(data.value)
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                }
                
                Spacer(minLength: 0)
            }
            .padding()
        }
        .background(data.color)
        .cornerRadius(10)
    }
}

// Custom Corners...

struct CustomCorners : Shape {
    
    var corners : UIRectCorner
    var size : CGFloat
    
    func path(in rect: CGRect) -> Path {
        
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: size, height: size))
        
        return Path(path.cgPath)
    }
}
//圖表
struct GraphView : View {
    
    var data : DailySales
    var allData : [DailySales]
    
    var body: some View{
        
        VStack(spacing: 5){
            
            GeometryReader{reader in
                
                VStack(spacing: 0){
                    
                    Spacer(minLength: 0)
                    
                    Text("\(Int(data.value))")
                        .font(.caption)
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                        // default Height For Graph...
                        .frame(height: 20)
                        .opacity(data.show ? 1 : 0)
                    
                    RoundedRectangle(cornerRadius: 5)
                        .fill(Color.red.opacity(data.show ? 1 : 0.4))
                        .frame(height: calulateHeight(value: data.value, height: reader.frame(in: .global).height - 20))
                }
            }
            
            Text(DateStyle(date: data.day))
                .font(.caption2)
                .foregroundColor(.gray)
        }
    }
    //日期
    func DateStyle(date: Date)->String{
        
        let format = DateFormatter()
        format.dateFormat = "MMM dd"
        return format.string(from: date)
    }
    
    //數值高度
    func calulateHeight(value: CGFloat,height: CGFloat)->CGFloat{
        
        let max = allData.max { (max, sale) -> Bool in
            
            if max.value > sale.value{return false}
            else{return true}
        }
        
        let percent = value / max!.value
        
        return percent * height
    }
}
