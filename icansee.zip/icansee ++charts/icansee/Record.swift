//
//  Record.swift
//  icansee
//
//  Created by WenLi Lee on 2020/11/10.
//

import SwiftUI


public struct Record: View {
        
    @Binding var user : String
   
    func getuser()->String{
        return "\(user)"
    }
    public var body: some View {
    
      
        LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 20), count: 2),spacing: 20){
            NavigationLink(destination: Record(user: $user)){
            
            ForEach(records){record in
                
                NavigationLink(destination: DetailView(record: record, user: $user))
                {
                    RecordCardView( record: record, user: $user)
                }
            }
          }
        }
        .padding(.top)
    }
}

public struct Record_Previews: PreviewProvider {
    
    public static var previews: some View {
        Record(user: .constant(""))
    }
}

//MARK:- 一格一格框框裡要顯示的字跟圖
public struct RecordCardView : View {
    //var w1 = Dictionary<String,String>()
    var record : RecordView
   
    @Binding var user : String //>>顯示資料的user
    func getuser()->String{
        return "\(user)"
    }
    
    public var body: some View{
        //每個框框的樣式
        
        ZStack(alignment: Alignment(horizontal: .trailing, vertical: .top)){
            
            VStack(alignment: .leading, spacing: 20) {
                
            //Text(getuser())
              
                Text(record.title)
                    .foregroundColor(.white)
                
                Text(record.data)
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    .padding(.top,10)
                
                HStack{
                    
                    Spacer(minLength: 0)
                    
                    Text(record.suggest)
                        .foregroundColor(.white)
                }
            }
            .padding()
            // image name same as color name
            .background(Color(record.image))
            .cornerRadius(20)
            // shadow
            .shadow(color: Color.black.opacity(0.2), radius: 5, x: 0, y: 5)
            
            // top Image
            
            Image(record.image)
                .renderingMode(.template)
                .foregroundColor(.white)
                .padding()
                .background(Color.white.opacity(0.12))
                .clipShape(Circle())
        }
        
        
    }
    
}

//MARK:- 每個框框裡的型別
struct RecordView : Identifiable {
    var id : Int
    var category: String
    var title : String
    var image : String
    var data: String
    var suggest : String
}

class username {
   
    @Binding var user : String
    init (user: Binding<String>){
        self._user = user
    }
   // var a = Record(user: <#Binding<String>#>).getuser()
}


//@Binding var user : String

//@State let user = Record(user:.constant(""))
//private var user = Record(user:.constant(String)-> Binding<String>)

//先關起乃
let re = WebService()
let first:CharacterSet = ["：",","];

//MARK:-new BP ??????????
//let i = Record().getuser()
///*
let w_BP = re.Test_BP(uid: "Biggg", choose: "new", Startday: "", Endday: "")
let data_BP = String(w_BP[0]!)
let first2 = data_BP.components(separatedBy: first)
let res_BP = first2[1]+" / "+first2[3]

//let i = username.

//MARK:-new HR
let w_HR = re.Test_HR(uid: "Biggg", choose: "new", Startday: "", Endday: "")
let data_HR = String(w_HR[0]!)
let first2_HR = data_HR.components(separatedBy: first)
let res_HR = first2_HR[1]

//MARK:-new SpO2
let w_SpO2 = re.Test_SpO2(uid: "Biggg", choose: "new", Startday: "", Endday: "")
let data_SpO2 = String(w_SpO2[0]!)
let first2_SpO2 = data_SpO2.components(separatedBy: first)
let res_SpO2 = first2_SpO2[1]

//MARK:-new Temp
let w_Temp = re.Test_Temp(uid: "Biggg", choose: "new", Startday: "", Endday: "")
let data_Temp = String(w_Temp[0]!)
let first2_Temp = data_Temp.components(separatedBy: first)
let res_Temp = first2_Temp[1]

//MARK:-new Exercise
let w_Exercise = re.Test_Exercise(uid: "Biggg", choose: "new", Startday: "", Endday: "")
let data_Exercise = String(w_Exercise[0]!)
let first2_Exercise = data_Exercise.components(separatedBy: first)
let res_Exercise = first2_Exercise[1]

//MARK:-new Sleep
let w_Sleep = re.Test_Sleep(uid: "Biggg", choose: "new", Startday: "", Endday: "")
let data_Sleep = String(w_Sleep[0]!)
let first2_Sleep = data_Sleep.components(separatedBy: first)
let res_Sleep = first2_Sleep[1]

//MARK:-new Poo
let w_Poo = re.Test_Poo(uid: "Biggg", choose: "new", Startday: "", Endday: "")
let data_Poo = String(w_Poo[0]!)
let first2_Poo = data_Poo.components(separatedBy: first)
let res_Poo = first2_Poo[1]

//MARK:-new Food
let w_Food = re.Test_Food(uid: "Biggg", choose: "new", Startday: "", Endday: "")
let data_Food = String(w_Food[0]!)
let first2_Food = data_Food.components(separatedBy: first)
let res_Food = first2_Food[1]


//let index舒 = String(w1[0]!.index(w1[0]!.startIndex, offsetBy: 7))
//*/

/*
let start = w1[0]!.index(w1[0]!.startIndex, offsetBy: 7)
let end = w1[0]!.index(w1[0]!.startIndex, offsetBy: 10)
let res = w1[0]![start...end]
*/



//MARK:- 顯示最新一筆資料的陣列
var records = [
    
    //生理數值-----------------------------------------------------------------------
    RecordView(id: 0, category: "生理數值", title: "心跳", image: "heart", data: "\(res_HR) "+"bmp", suggest: "Healthy\n80-120"),
    //RecordView(id: 1, category: "生理數值",title: "血糖", image: "Blood Sugar", data: ""+"mg/dL", suggest: "Healthy\n60~139"),
    RecordView(id: 2, category: "生理數值", title: "血壓", image: "Blood Pressure", data: "\(res_BP) mmHg", suggest: "收縮壓＜120\n舒張壓＜80"),
    RecordView(id: 3, category: "生理數值", title: "血氧", image: "Blood SpO2", data: "\(res_SpO2) "+"％", suggest: "Healthy\n95∼100％"),
    RecordView(id: 4, category: "生理數值", title: "體溫", image: "temp", data: "\(res_Temp) "+" °C", suggest: "\n"+"38°C體溫過高！"),
    //-----------------------------------------------------------------------------
    
    RecordView(id: 5, category: "運動", title: "運動", image: "energy", data: "\(res_Exercise) "+"hrs", suggest: "Daily Goal\n900 kcal"),
    
    RecordView(id: 6, category: "睡眠用眼", title: "睡眠用眼", image: "sleep", data: "\(res_Sleep) "+"hrs", suggest: "eyes: 8hr\nDaily sleep : 8hr"),
    
    RecordView(id: 7, category: "排便", title: "排便", image: "poopoo", data: "\(res_Poo) ", suggest: "正常人每天會排便1到2次"),
    
    RecordView(id: 8, category: "熱量", title: "三餐熱量", image: "food", data: "\(res_Food) "+" kcal", suggest: "Daily Goal\n1500 kcal"),
    
    
]
//MARK:- 新增資料的頁面 - 心跳血氧血壓體溫 運動三餐排便...

struct DetailView : View {
    var alert: Alert {
        
        Alert(title: Text("新增"), message: Text("新增成功"), dismissButton: .cancel(Text("OK")))
        
    }
    var alert2: Alert {
        
        Alert(title: Text("新增"), message: Text("新增失敗"), dismissButton: .cancel(Text("OK")))
        
    }
    
    var record : RecordView
    var strrength = ["費","中","輕","坐"]
    var sport = ["走路", "爬樓梯", "跑步", "騎腳踏車","球類運動"]
    @Binding var user : String
    @State var hourSelection = 0
    @State var minuteSelection = 0
    @State private var sleepTime = Date()
    @State private var getupTime = Date()
    @State private var sportAmount = 0.5
    @State var selectedsport = "走路"
    @State var selectedStr = "費"
    @State var signUp = false
    @State var heart = ""
    @State var sugar = ""
    @State var BP = ""
    @State var BPP = ""
    @State var SpO2 = ""
    @State var temp = ""
    @State var rePass = ""
    @State var breakfast = ""
    @State var lunch = ""
    @State var dinner = ""
    @State var showAlert = false//登入錯
    @State var currentlySelectedId: Int = 0
    @State private var isActive: Bool = false
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    @State var selectedDate = Date()
//選日期-----------------
    func showDatePickerAlert() {
            let alertVC = UIAlertController(title: "\n\n", message: nil, preferredStyle: .actionSheet)
            let datePicker: UIDatePicker = UIDatePicker()
            alertVC.view.addSubview(datePicker)
            
            let okAction = UIAlertAction(title: "OK", style: .default) { _ in
                self.selectedDate = datePicker.date
            }
            alertVC.addAction(okAction)
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)
            alertVC.addAction(cancelAction)

            if let viewController = UIApplication.shared.windows.first?.rootViewController {
                viewController.present(alertVC, animated: true, completion: nil)
            }
        }
    
    static let formatter: DateFormatter = {
            let formatter = DateFormatter()
            formatter.setLocalizedDateFormatFromTemplate("yyMMdd")
            return formatter
        }()
    
    //自製的back按鈕
    var btnBack : some View {
        
        Button(action: {
            self.presentationMode.wrappedValue.dismiss()
        }) {
            HStack {
                Image("back") // set image here
                    .aspectRatio(contentMode: .fit)
                    .foregroundColor(.white)
                
            }
        }
    }
    
    
    var body: some View{
       
        ZStack(alignment: .top){
 //MARK:- 生理數值
            VStack{
                if (record.category == "生理數值"){
                    
                    VStack(alignment: .leading, spacing: 25) {
                        
                        Text("新增"+"\(user)"+"生理數值_"+"\(record.title)")//>>新增資料的user
                            .font(.system(size: 25, weight: .bold))
                            .foregroundColor(Color("Color1"))
                        
                        
                        VStack{
                            
                            if (record.title == "心跳")
                            {
                                TextField("心跳", text: $heart).autocapitalization(.none)
                                    .foregroundColor(Color(.black))
                                    .keyboardType(.numberPad)
                                Divider()
                            }
                            else if (record.title == "血氧")
                            {
                                TextField("血氧", text: $SpO2).autocapitalization(.none)
                                    .foregroundColor(Color(.black))
                                    .keyboardType(.numberPad)
                                Divider()
                            }
                            else if (record.title == "血壓")
                            {
                               
                                Text("收縮壓")//>>新增資料的user
                                    .font(.system(size: 25, weight: .bold))
                                    .foregroundColor(Color("Color1"))
                                    .padding(.top,10)
                                
                                TextField("收縮壓", text: $BP).autocapitalization(.none)
                                    
                                    .foregroundColor(Color(.black))
                                    .keyboardType(.numberPad)
                                Divider()
                                
                                Text("舒張壓")//>>新增資料的user
                                    .font(.system(size: 25, weight: .bold))
                                    .foregroundColor(Color("Color1"))
                                    .padding(.top,10)
                                
                                TextField("舒張壓", text: $BPP).autocapitalization(.none)
                                    .foregroundColor(Color(.black))
                                    .keyboardType(.numberPad)
                                Divider()

                            }
                            else if (record.title == "體溫")
                            {
                                TextField("體溫", text: $temp).autocapitalization(.none)
                                    .foregroundColor(Color(.black))
                                    .keyboardType(.numberPad)
                                Divider()
                            }
                            else
                            {
                                TextField("血糖", text: $sugar).autocapitalization(.none)
                                    .foregroundColor(Color(.black))
                                    .keyboardType(.numberPad)
                                Divider()
                            }
                        }
                        
                        HStack{
                            
                            Spacer()
 //MARK:- 儲存生理數值save
                            NavigationLink(destination: TabBarView(user: $user) , isActive: self.$isActive) {
                                Text("")
                            }
                            Button(action: {
                                if (record.title == "心跳")
                                {
                                    let re = WebService();
                                    let w1 = re.IOS_addHR(uid: user, 脈搏: heart)
                                    if w1 == true
                                    {
                                        
                                        self.isActive = true
                                    }
                                    else if w1 == false
                                    {
                                        self.showAlert = true
                                    }
                                }
                                else if (record.title == "血氧")
                                {
                                    let re = WebService();
                                    let w1 = re.IOS_addSpO2(uid: user, 血氧: SpO2)
                                    if w1 == true
                                    {
                                        self.isActive = true
                                    }
                                    else if w1 == false
                                    {
                                        self.showAlert = true
                                    }
                                }
                                else if (record.title == "血壓")
                                {
                                    let re = WebService();
                                    let w1 = re.IOS_addBP(uid: user, 收縮壓: BP, 舒縮壓: BPP)
                                    if w1 == true
                                    {
                                        self.isActive = true
                                    }
                                    else if w1 == false
                                    {
                                        self.showAlert = true
                                    }
                                }
                                else if (record.title == "體溫")
                                {
                                    let re = WebService();
                                    let w1 = re.IOS_addTemp(uid: user, 體溫: temp)
                                    if w1 == true
                                    {
                                        self.isActive = true
                                    }
                                    else if w1 == false
                                    {
                                        self.showAlert = true
                                    }
                                }
                                else//血糖
                                {
                                    
                                }
                                
                            }) {
                                
                                Text("SAVE")
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding(.vertical)
                                    .padding(.horizontal,45)
                                    .background(Color("Color1"))
                                    .clipShape(Capsule())
                            }
                            .alert(isPresented: $showAlert, content: { self.alert })

                            
                            Spacer()
                        }
                        .padding(.top)
                        
                        Spacer(minLength: 0)
                        
                    }
                    .padding(.top,(UIApplication.shared.windows.first?.safeAreaInsets.top)! + 30)
                    .padding()
                    .background(Color.white.edgesIgnoringSafeArea(.all))
                    
                }
//MARK:- 運動
                else if (record.title == "運動"){
                    
                    VStack(alignment: .leading, spacing: 25) {
                        // show just the date
                       Text(Date().addingTimeInterval(600), style: .date).position(x:80,y:10)
                       //Text(Date().addingTimeInterval(600), style: .time).position(x:80,y:10)
                        //Text("Selected date: \(selectedDate, formatter: Self.formatter)")
                          //          Button("Show action sheet") {
                            //            self.showDatePickerAlert()
                            //        }
                        //選擇強度
                      
                        Section(header:Text("運動強度：\(selectedStr)").font(.headline)){
                            
                            HStack(spacing: 15){
                                
                                ForEach(strrength,id: \.self){i in
                                    
                                    Button(action: {
                                        selectedStr = i
                                    }) {
                                        
                                        Text("\(i)")
                                            .font(UIScreen.main.bounds.height < 750 ? .caption : .body)
                                            .foregroundColor(selectedStr == i ? .white : .black)
                                            .padding(.vertical,8)
                                            .padding(.horizontal,10)
                                            .background(
                                                ZStack{
                                                    RoundedRectangle(cornerRadius: 5)
                                                        .fill(Color("Color1").opacity(selectedStr == i ? 1 : 0))
                                                    
                                                    RoundedRectangle(cornerRadius: 5)
                                                        .stroke(Color("Color1"),lineWidth: 1)
                                                }
                                            )
                                        
                                    }
                                    
                                }
                            }
                        }
                        Spacer()
        //選擇運動-----------------------------------------------------------------------------------
                        Section(header:Text("運動運動：\(selectedsport)").font(.headline)){
                            HStack {
                                    Picker(selection: $selectedsport, label:
                                            Text("選擇運動")
                                    ){
                                       ForEach(sport, id: \.self) { (sport) in
                                        Text(sport)
                                            .foregroundColor(.black)
                                       }
                                    }
                                    
                                 }
                        }
        //運動時長-------------------------------------------------------------------------------------------
                        Section(header:Text("運動時長").font(.headline)) {
                            Stepper(value: $sportAmount, in: 0.5...8, step: 0.5){
                                Text("\(sportAmount,specifier: "%g") hours")
                            }
                        }
         //消耗卡路里-------------------------------------------------------------------------------------------
                        Section(header:
                                    Text("大約消耗的卡路里：1500kcal")
                                    .font(.headline)
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding(.vertical)
                                    .padding(.horizontal,45)
                                    .background(Color("Color1"))
                                    .clipShape(Capsule())
                        ) {
                            
                                
                        }
                       
                        HStack{
                            
                            Spacer()
                            
//MARK:- 儲存運動save
                            Button(action: {
                                
                            }) {
                                
                                Text("SAVE")
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding(.vertical)
                                    .padding(.horizontal,45)
                                    .background(Color("Color1"))
                                    .clipShape(Capsule())
                            }
                            
                            Spacer()
                        }
                        .padding(.top)
                        
                        Spacer(minLength: 0)
                    }
                    .padding(.top,(UIApplication.shared.windows.first?.safeAreaInsets.top)! + 10)
                    .padding()
                    .background(Color.white.edgesIgnoringSafeArea(.all))
                    
                    
                }
//MARK:- 睡眠時間
                else if (record.title == "睡眠用眼"){
                    
                    VStack(alignment: .leading, spacing: 25) {
                        
                        VStack {
                                   
                        DatePicker("起床時間", selection: $getupTime, displayedComponents: .hourAndMinute)
                            .font(.system(size: 25, weight: .bold))
                            .foregroundColor(Color("Color1"))
                        
                            DatePicker("就寢時間", selection: $sleepTime, displayedComponents: .hourAndMinute)
                                .font(.system(size: 25, weight: .bold))
                                .foregroundColor(Color("Color1"))
                        }
                        
                        HStack{
                            
                            Spacer()
                            
 //MARK:- 儲存睡眠時間save
                            Button(action: {
                                
                            }) {
                                
                                Text("SAVE")
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding(.vertical)
                                    .padding(.horizontal,45)
                                    .background(Color("Color1"))
                                    .clipShape(Capsule())
                                
                            }
                            
                            Spacer()
                        }
                        .padding(.top)
                        
                        Spacer(minLength: 0)
                        
                        
                    }
                    .padding(.top,(UIApplication.shared.windows.first?.safeAreaInsets.top)! + 30)
                    .padding()
                    .background(Color.white.edgesIgnoringSafeArea(.all))
                    
                }
 //MARK:- 排便
                else if (record.title == "排便"){
                    
                    VStack(alignment: .center, spacing: 35) {
                        Image("圖:取自肝病防治學術基金會").resizable().scaledToFit()
                                 Text("圖:取自肝病防治學術基金會")
                        
                            HStack(spacing: 70) {
                                
                                PoopoobtnView(id: 1, currentlySelectedId: $currentlySelectedId, text: "1")
                                PoopoobtnView(id: 2, currentlySelectedId: $currentlySelectedId, text: "2")
                                PoopoobtnView(id: 3, currentlySelectedId: $currentlySelectedId, text: "3")
                                PoopoobtnView(id: 4, currentlySelectedId: $currentlySelectedId, text: "4")
                              
                            }
                        HStack(spacing: 70) {
                            
                            PoopoobtnView(id: 5, currentlySelectedId: $currentlySelectedId, text: "5")
                            PoopoobtnView(id: 6, currentlySelectedId: $currentlySelectedId, text: "6")
                            PoopoobtnView(id: 7, currentlySelectedId: $currentlySelectedId, text: "7")
                            
                          
                        }
                        HStack(spacing: 35){
                            
                            
                            Spacer()
                            
 //MARK:- 儲存排便save
                            
                            Button(action: {
                                if(currentlySelectedId == 1){
                                    print("1")
                                }
                                else if(currentlySelectedId == 2){
                                    print("2")
                                }
                                else if(currentlySelectedId == 3){
                                    print("3")
                                }
                                else if(currentlySelectedId == 4){
                                    print("4")
                                }
                                else if(currentlySelectedId == 5){
                                    print("5")
                                }
                                else
                                {
                                    print("6")
                                }
                            }) {
                                
                                Text("SAVE")
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding(.vertical)
                                    .padding(.horizontal,45)
                                    .background(Color("Color1"))
                                    .clipShape(Capsule())
                                
                            }
                            
                            Spacer()
                        }
                        .padding(.top)
                        
                        Spacer(minLength: 0)
                        
                        
                    }
                    .padding(.top,(UIApplication.shared.windows.first?.safeAreaInsets.top)! + 30)
                    .padding()
                    .background(Color.white.edgesIgnoringSafeArea(.all))
                    
                }
 //MARK:- 三餐熱量
                else {
                    
                    VStack(alignment: .leading, spacing: 25) {
                        
                        
                        VStack{
                            
                            Text("早餐")
                                .font(.system(size: 25, weight: .bold))
                                .foregroundColor(Color("Color1"))
                                TextField("早餐", text: $breakfast).autocapitalization(.none)
                                    .foregroundColor(Color(.black))
                                    .keyboardType(.numberPad)
                                Divider()
                            Text("午餐")
                                .font(.system(size: 25, weight: .bold))
                                .foregroundColor(Color("Color1"))
                                TextField("午餐", text: $lunch).autocapitalization(.none)
                                    .foregroundColor(Color(.black))
                                    .keyboardType(.numberPad)
                                Divider()
                           
                            Text("晚餐")
                                .font(.system(size: 25, weight: .bold))
                                .foregroundColor(Color("Color1"))
                                TextField("晚餐", text: $dinner).autocapitalization(.none)
                                    .foregroundColor(Color(.black))
                                    .keyboardType(.numberPad)
                                Divider()
                           
                        }
                        
                        HStack{
                            
                            Spacer()
                            
//MARK:- 儲存三餐熱量save
                            
                            Button(action: {
                                
                            }) {
                                
                                Text("SAVE")
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding(.vertical)
                                    .padding(.horizontal,45)
                                    .background(Color("Color1"))
                                    .clipShape(Capsule())
                            }
                            
                            Spacer()
                        }
                        .padding(.top)
                        
                        Spacer(minLength: 0)
                        
                    }
                    .padding(.top,(UIApplication.shared.windows.first?.safeAreaInsets.top)! + 30)
                    .padding()
                    .background(Color.white.edgesIgnoringSafeArea(.all))
                    
                }
            }
        }
        .edgesIgnoringSafeArea(.all)
        .statusBar(hidden: true)
    }
    
}

struct PoopoobtnView: View {
    
    let id: Int
    @Binding var currentlySelectedId: Int
    
    var text: String
    
    var body: some View {
        Button(action: { self.currentlySelectedId = self.id }, label: { Text(text) })
            .foregroundColor(id == currentlySelectedId ? .white : .orange)
            .background(
                Circle()
                    .fill(id == currentlySelectedId ? Color.orange :  Color.white)
                    .frame(width: 50, height: 50)
                    .overlay(
                        Circle()
                            .stroke(lineWidth: 2)
                            .foregroundColor(.orange)
                            .padding(0)
                )
            
        )
    }
}
