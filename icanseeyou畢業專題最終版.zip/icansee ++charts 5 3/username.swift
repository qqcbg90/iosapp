//
//  username.swift
//  icansee
//
//  Created by WenLi Lee on 2020/12/23.
//

import Foundation
import Combine

public func username() -> String {
    //let id = UUID()
    @Binding var user : String
    
        return user
    
    
}
