//
//  SportRecord.swift
//  icansee
//
//  Created by WenLi Lee on 2020/11/15.
//

import SwiftUI
import Charts

struct SportRecord: View {
    var body: some View {
        NavigationView{
            
            sport() .navigationBarHidden(true)
                
                .background(Color("lightorang").ignoresSafeArea(.all, edges:.all))
        }
    }
}

struct SportRecord_Previews: PreviewProvider {
    static var previews: some View {
        SportRecord()
    }
}


struct sport : View {
    
    @State var tab = "7days"
    @Namespace var animation
    
    
    @State var edges = UIApplication.shared.windows.first?.safeAreaInsets
    
    var body: some View{
        
        VStack{
            
            
            HStack(spacing: 0){
                
                tabbutton(selected: $tab, title: "7days", animation: animation)
                
                tabbutton(selected: $tab, title: "28days", animation: animation)
            }
            .background(Color.white.opacity(0.08))
            .clipShape(Capsule())
            .padding(.horizontal)
            
            HStack(spacing: 20){
                if(tab == "7days"){
                    Sport7()}
                else{
                    Sport28()
                }
                
            }
            .frame(width: 400, height: 500, alignment: .center)
            
            // Or YOu can use Foreach Also...
            VStack(spacing: 20){
                
                HStack(spacing: 15){
                    
                }
                
                HStack(spacing: 15){
                    
                }
            }
            .padding(.horizontal)
            
            ZStack{
                
            }
            .padding(.top,20)
            
            Spacer()
        }
        
        .background(Color("lightorang").ignoresSafeArea(.all, edges:.bottom))
    }
    
}

struct tabb : View {
    @Binding var selected : String
    @State var title : String
    var animation : Namespace.ID
    
    var body: some View{
        
        Button(action: {
            
            withAnimation(.spring()){
                selected = title
                
                
                /*Divider()
                 HeartRecord();
                 heartRecord(title: Binding<String>.constant(""), selected: self.$selected)*/
                
            }
            
        }) {
            
            ZStack{
                
                // Capsule And Sliding Effect...
                
                Capsule()
                    .fill(Color.clear)
                    .frame(height: 45)
                
                if selected == title{
                    
                    Capsule()
                        .fill(Color.white)
                        .frame(height: 45)
                        // Mathced Geometry Effect...
                        .matchedGeometryEffect(id: "Tab", in: animation)
                }
                
                Text(title)
                    .foregroundColor(selected == title ? .black : .white)
                    .fontWeight(.bold)
            }
        }
    }
}

struct Sport7 : UIViewRepresentable {
    
    
    let months = [String]()
    let 早餐 = [21, 24, 26, 23, 22, 26, 24, 28, 22, 24, 25, 24] //數字最小
    
    func makeUIView(context: Context) -> BarChartView {
        return setChart(dataPoints: months, values:早餐 )
    }
    
    func updateUIView(_ uiView: BarChartView, context: UIViewRepresentableContext<Sport7>)
    {
        
    }
    
    typealias UIViewType = BarChartView
    
    //Bar chart accepts data as array of BarChartDataEntry objects
    var myView = BarChartView()
  
    func setChart(dataPoints: [String], values: [Int]) -> BarChartView {
        
        //若沒有資料，顯示的文字
        myView.noDataText = "You need to provide data for the chart."
        
        //存放資料的陣列，型別是BarChartDataEntry.
        
       
        
        //迴圈，來載入每筆資料內容
        var set次數: [BarChartDataEntry] = []
        
        //迴圈，來載入每筆資料內容
        let wfood = re.Test_Exercise(uid: "Biggg", choose: "7day", Startday: "", Endday: "")
        let i = wfood.count
        var 次數 = [Double]()
       
        var 分類 = [String]()
        var k = 0
        let xAxis = myView.xAxis
        let yAxis = myView.leftAxis
        for _ in k...i{
            if(k>=i)
            {
                break;
            }
            else if(wfood[0]=="null")
            {
                次數.append(0)
                
                let data次數 = BarChartDataEntry(x: Double(k), y: Double(次數[k]))
               
                set次數.append(data次數)
            
                break;
            }
            else{
                let data_BP1 = String(wfood[k]!)
                let first:CharacterSet = ["：",","];
                let first2 = data_BP1.components(separatedBy: first)
                次數.append(first2[1].toDouble()!)
              
                let data次數 = BarChartDataEntry(x: Double(k), y: Double(次數[k]))
            
                set次數.append(data次數)
            
                分類.append(first2[3])
                myView.xAxis.valueFormatter = IndexAxisValueFormatter(values: 分類)
                myView.xAxis.granularity = 1
                k+=1
            }
            
        }
        //顯示的資料之內容與名稱（左下角所顯示的）
        let chartData次數 = BarChartDataSet(entries: set次數, label: "小時")
   
        //把dataSet轉換成可顯示的BarChartData
        let chartData = BarChartData(dataSets: [chartData次數])
        
        //指定剛剛連結的myView要顯示的資料為charData
        myView.data = chartData
        
        //改變chartDataSet的顏色
        chartData次數.colors = [UIColor(red: 226/255, green: 137/255, blue: 108/255, alpha: 1)]
      
        myView.data?.setValueFont(UIFont.systemFont(ofSize: 18))//文字字型
        myView.data?.setValueTextColor(UIColor.brown)  //文字顏色
        
        //標籤換到下方
        myView.xAxis.labelPosition = .bottom
        
        //改變barChartView的背景顏色
        // myView.backgroundColor = UIColor(red:0/255, green: 0/255, blue: 0/255, alpha: 1)
        
        //一個一個延遲顯現的特效
       // myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
        
        //彈一下特效
        //myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0, easingOption: .easeInBounce)
        
        //設立界線
        let limit = ChartLimitLine(limit: 50.0, label: "Target")
        
        myView.rightAxis.addLimitLine(limit)
        
        
        //設定X軸文字
        
        xAxis.labelTextColor = UIColor.brown //label文字顏色
        //xAxis.axisLineColor = UIColor.black  // 設定X軸顏色
       // xAxis.drawGridLinesEnabled = false  // 隱藏隔線
        xAxis.labelPosition = .bottom       // 設定文字位置
       // xAxis.spaceMin = 1.5                // X軸左邊間隔距離
     //   xAxis.spaceMax = 1.5                // X軸右邊間隔距離
        xAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        myView.doubleTapToZoomEnabled = false   //取消雙擊縮放
        myView.dragEnabled = true  //啟用拖拽圖表
        myView.dragDecelerationEnabled = false  //拖拽後是否有慣性效果
        myView.dragDecelerationFrictionCoef = 0 //拖拽後慣性效果的摩擦係數(0~1)，數值越小，慣性越不明顯
     
        //設定y軸文字
        myView.rightAxis.enabled = false
        yAxis.drawZeroLineEnabled = true   //從0開始繪製
        yAxis.axisLineColor =  UIColor.black  //Y軸顏色
        
        yAxis.axisMaximum = 10.0
        yAxis.axisMinimum = 0
        
        //設定Y軸上標籤的樣式
        yAxis.labelPosition = .outsideChart   //label位置
        yAxis.labelTextColor = UIColor.brown   //文字顏色
        yAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        //設定Y軸上標籤顯示數字的格式
         //   let  leftFormatter = NumberFormatter()  //自定義格式
         // leftFormatter.positiveSuffix = "kacl"  //數字字尾單位
         //  myView.leftAxis.valueFormatter = DefaultAxisValueFormatter.init(formatter: leftFormatter)
        
        return myView
        
        
    }

    
    
}//7day
struct Sport28 : UIViewRepresentable {
    
    
    let months = [String]()
    let 早餐 = [21, 24, 26, 23, 22, 26, 24, 28, 22, 24, 25, 24] //數字最小
    
    func makeUIView(context: Context) -> BarChartView {
        return setChart(dataPoints: months, values:早餐 )
    }
    
    func updateUIView(_ uiView: BarChartView, context: UIViewRepresentableContext<Sport28>)
    {
        
    }
    
    typealias UIViewType = BarChartView
    
    //Bar chart accepts data as array of BarChartDataEntry objects
    var myView = BarChartView()
  
    func setChart(dataPoints: [String], values: [Int]) -> BarChartView {
        
        //若沒有資料，顯示的文字
        myView.noDataText = "You need to provide data for the chart."
        
        //存放資料的陣列，型別是BarChartDataEntry.
        
       
        
        //迴圈，來載入每筆資料內容
        var set次數: [BarChartDataEntry] = []
        
        //迴圈，來載入每筆資料內容
        let wfood = re.Test_Exercise(uid: "Biggg", choose: "28day", Startday: "", Endday: "")
        let i = wfood.count
        var 次數 = [Double]()
       
        var 分類 = [String]()
        var k = 0
        let xAxis = myView.xAxis
        let yAxis = myView.leftAxis
        for _ in k...i{
            if(k>=i)
            {
                break;
            }
            else if(wfood[0]=="null")
            {
                次數.append(0)
                
                let data次數 = BarChartDataEntry(x: Double(k), y: Double(次數[k]))
               
                set次數.append(data次數)
            
                break;
            }
            else{
                let data_BP1 = String(wfood[k]!)
                let first:CharacterSet = ["：",","];
                let first2 = data_BP1.components(separatedBy: first)
                次數.append(first2[1].toDouble()!)
              
                let data次數 = BarChartDataEntry(x: Double(k), y: Double(次數[k]))
            
                set次數.append(data次數)
            
                分類.append(first2[3])
                myView.xAxis.valueFormatter = IndexAxisValueFormatter(values: 分類)
                myView.xAxis.granularity = 1
                k+=1
            }
            
        }
        //顯示的資料之內容與名稱（左下角所顯示的）
        let chartData次數 = BarChartDataSet(entries: set次數, label: "小時")
   
        //把dataSet轉換成可顯示的BarChartData
        let chartData = BarChartData(dataSets: [chartData次數])
        
        //指定剛剛連結的myView要顯示的資料為charData
        myView.data = chartData
        
        //改變chartDataSet的顏色
        chartData次數.colors = [UIColor(red: 226/255, green: 137/255, blue: 108/255, alpha: 1)]
      
        myView.data?.setValueFont(UIFont.systemFont(ofSize: 18))//文字字型
        myView.data?.setValueTextColor(UIColor.brown)  //文字顏色
        
        //標籤換到下方
        myView.xAxis.labelPosition = .bottom
        
        //改變barChartView的背景顏色
        // myView.backgroundColor = UIColor(red:0/255, green: 0/255, blue: 0/255, alpha: 1)
        
        //一個一個延遲顯現的特效
        //myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
        
        //彈一下特效
       //myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0, easingOption: .easeInBounce)
        
        //設立界線
        let limit = ChartLimitLine(limit: 50.0, label: "Target")
        
        myView.rightAxis.addLimitLine(limit)
        
        
        //設定X軸文字
        
        xAxis.labelTextColor = UIColor.brown //label文字顏色
        //xAxis.axisLineColor = UIColor.black  // 設定X軸顏色
       // xAxis.drawGridLinesEnabled = false  // 隱藏隔線
        xAxis.labelPosition = .bottom       // 設定文字位置
       // xAxis.spaceMin = 1.5                // X軸左邊間隔距離
     //   xAxis.spaceMax = 1.5                // X軸右邊間隔距離
        xAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        myView.doubleTapToZoomEnabled = false   //取消雙擊縮放
        myView.dragEnabled = true  //啟用拖拽圖表
        myView.dragDecelerationEnabled = false  //拖拽後是否有慣性效果
        myView.dragDecelerationFrictionCoef = 0 //拖拽後慣性效果的摩擦係數(0~1)，數值越小，慣性越不明顯
     
        //設定y軸文字
        myView.rightAxis.enabled = false
        yAxis.drawZeroLineEnabled = true   //從0開始繪製
        yAxis.axisLineColor =  UIColor.black  //Y軸顏色
        
        yAxis.axisMaximum = 10.0
        yAxis.axisMinimum = 0
        
        //設定Y軸上標籤的樣式
        yAxis.labelPosition = .outsideChart   //label位置
        yAxis.labelTextColor = UIColor.brown   //文字顏色
        yAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        //設定Y軸上標籤顯示數字的格式
         //   let  leftFormatter = NumberFormatter()  //自定義格式
         // leftFormatter.positiveSuffix = "kacl"  //數字字尾單位
         //  myView.leftAxis.valueFormatter = DefaultAxisValueFormatter.init(formatter: leftFormatter)
        
        return myView
        
        
    }

    
    
}//28day
