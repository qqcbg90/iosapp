//
//  pageone.swift
//  icansee
//
//  Created by WenLi Lee on 2020/12/9.
//

import SwiftUI

struct pageone: View {
    @Binding var user : String
    var body: some View {
        NavigationView{
            
           emergency(user: $user)
            .navigationBarHidden(true)
            .edgesIgnoringSafeArea(.all)
            .navigationBarBackButtonHidden(true)
            
        }.navigationBarHidden(true)
        .edgesIgnoringSafeArea(.all)
        .navigationBarBackButtonHidden(true)
    }
}

struct pageone_Previews: PreviewProvider {
    static var previews: some View {
        pageone(user: .constant(""))
    }
}

struct emergency: View {
    @Binding var user : String
      @State var emercy = ""
    @State private var isActive: Bool = false
    var relationship  = ["媽媽", "爸爸", "姊姊", "妹妹","哥哥","弟弟"]
    @State var selectedrelationship  = "媽媽"
      var body: some View {
            ZStack(alignment: Alignment(horizontal: .center, vertical: .center)){
                VStack(alignment: .leading, spacing: 25) {
                  Spacer(minLength: 20)
                    VStack(alignment: .leading, spacing: 10){
                      Text("請輸入緊急聯絡人帳號").foregroundColor(Color("Color1"))
                      TextField("", text: $emercy).foregroundColor(Color("Color1"))
                      Divider().background(Color("Color1").opacity(0.5))
                    }.padding(10)
                      
                      VStack(alignment: .leading, spacing: 10){
                        Text("此聯絡人是你的：\(selectedrelationship)").foregroundColor(Color("Color1")).padding(10)
                        Section(header:Text("")){
                            HStack {
                                    Picker(selection: $selectedrelationship, label:
                                            Text("")
                                    ){
                                       ForEach(relationship, id: \.self) { (sport) in
                                        Text(sport)
                                            .foregroundColor(Color("Color1"))
                                       }
                                    }
                                    
                                 }
                        }
                        Text("此步驟可以跳過在之後設定").foregroundColor(.blue)
                      }
                    NavigationLink(destination: TabBarView(user: $user) , isActive: self.$isActive) {
                        Text("")}
                    HStack{
                        
                        Spacer()
                      
    //MARK:- webservice
                        
                        Button(action: {
                            self.isActive = true
                        })
                        {
                            Text("Save")
                                .fontWeight(.bold)
                                .foregroundColor(Color.white)
                                .padding(.vertical)
                                .padding(.horizontal,45)
                                .background(Color("Color1"))
                                .clipShape(Capsule())
                          
                        }
                      
                        Spacer()
                    }
                    
                    .padding(.top)
                    
                    Button(action: {
                        self.isActive = true
                        
                    }) {
                        
                        Text("下一步")
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                            .padding(.vertical)
                            .padding(.horizontal,45)
                            .background(Color("Color1"))
                            .clipShape(Capsule())
                       }.position(x: 315, y: 50)

                    Spacer(minLength: 0)
                }
              
                .padding()

            }.background(Color.white.edgesIgnoringSafeArea(.all))
            .edgesIgnoringSafeArea(.all)
            .statusBar(hidden: true)
            .navigationBarHidden(true)
    }
      
    }
        
