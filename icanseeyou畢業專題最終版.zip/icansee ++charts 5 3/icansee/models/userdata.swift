//
//  userdata.swift
//  icansee
//
//  Created by WenLi Lee on 2020/12/29.
//

import Combine
import SwiftUI

final class UserData: ObservableObject {
    @Published var showFavoritesOnly = false
}
