//
//  ChatView.swift
//  icansee
//
//  Created by WenLi Lee on 2020/11/15.
//

import SwiftUI
import Combine


struct ChatView: View {
    
    
    
    @State var edit = false
    @State var show = false
    @State var showchat = false
    @StateObject var obs : chatobser = chatobser()
    @State var selected : type = .init(id: "", title: "", msg: "", day: "", msgre: "")
    @Binding var user : String
    var body: some View{
        ZStack{
            Color.orange.edgesIgnoringSafeArea(.bottom)
            VStack{
                VStack(spacing : 5){
                    HStack{
                        Text("聊天室").font(.largeTitle).fontWeight(.heavy)
                        
                        Spacer()
                        
                        Button(action: {
                            self.edit.toggle()
                        }) {
                            Text(self.edit ? "Done" : "Edit")
                        }
                    }.padding([.leading,.trailing], 15)
                    .padding(.top, 10)
                    
                    Button(action: {
                        self.selected = type(id: "", title: "", msg: "", day: "", msgre: "")
                        self.show.toggle()
                        
                    }) {
                        Image(systemName: "plus").resizable().frame(width: 25, height: 25).padding()
                        
                    }.foregroundColor(.white)
                    .background(Color.red)
                    .clipShape(Circle())
                    .padding(.bottom, -15)
                    .offset(y: 15)
                    
                    
                }
                .background(Rounded().fill(Color.white))
                .sheet(isPresented: $show) {
                    SaveView(show: self.$show, showchat: $showchat, myMsg: true, user: $user, data: self.selected).environmentObject(self.obs)
                }
                
                ScrollView(.vertical, showsIndicators: false) {
                    VStack(spacing: 10){
                        ForEach(self.obs.datas){i in
                            cellview(edit: self.edit, data: i).onTapGesture {
                                self.selected = i
                               showchat.toggle()
                            }.environmentObject(self.obs)
                        }
                    }.padding()
                }.padding(.top, 30)
                .sheet(isPresented: $showchat) {
                    SaveView(show: self.$show, showchat: $showchat, myMsg: true, user: $user, data: self.selected).environmentObject(self.obs)
                }
            }
            
        }
    }
}
struct ChatView_Previews: PreviewProvider {
    
    static var previews: some View {
        ChatView(user: .constant(""))
    }
}



struct Rounded : Shape {
    
    func path(in rect: CGRect) -> Path {
        
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: [.bottomLeft,.bottomRight], cornerRadii: CGSize(width: 25, height: 25))
        
        return Path(path.cgPath)
    }
}

struct cellview : View {
    var edit : Bool
    var data : type
    @StateObject var obs : chatobser = chatobser()
  
    var body : some View{
        HStack{
            if edit{
                Button(action: {
                    if self.data.msgre == ""{
                    }
                    
                }) {
                    Image(systemName: "minus.circle").font(.title)
                }.foregroundColor(.red)
            }
            
            Text(data.title).lineLimit(1)
            
            Spacer()
            
            VStack(alignment: .leading,spacing : 5){
                
                Text(data.day)
                if self.data.msgre == ""
                {
                    Text("未回覆").foregroundColor(.red)
                }
                
            }
        }.padding()
        .background(RoundedRectangle(cornerRadius: 25).fill(Color.white))
        .animation(.spring())
        
    }
}


struct SaveView : View {
    @State var msgre = ""
    @State var msg = ""
    @State var title = ""
    @Binding var show : Bool
    @Binding var showchat : Bool
    var myMsg : Bool
    //@ObservedObject var obs :observer
    @EnvironmentObject var obs : chatobser
    @Binding var user : String
    var data : type
    
    var body : some View{
        if (show == true){
            VStack(spacing : 12){
                
                HStack{
                    
                    Spacer()
                    
                    Button(action: {
                        
                        if self.data.id != ""{
                            
                            self.obs.update()
                        }
                        else{
                           
                             self.obs.add(title: self.title, msg: self.msg, date: Date())
                            
                        }
                       
                        self.show.toggle()
                        self.obs.update()
                    }) {
                        
                        Text("傳送")
                    }
                }
                
                TextField("Title", text: $title)
                
                Divider()
                
                multiline(txt: $msg)
                
            }.padding()
            .onAppear {
                
                self.msg = self.data.msg
                self.title = self.data.title
                    
            }
        }
        //
        else if(showchat)
        {
            VStack(spacing : 12){
                
                HStack{
                    
                    Spacer()
                    
                    Button(action: {
                        
                        if self.data.id != ""{
                            
                            self.obs.update()
                        }
                        else{
                            
                             self.obs.add(title: self.title, msg: self.msg, date: Date())
                        }
                       
                        self.showchat.toggle()
                        
                    }) {
                        
                        Text("")
                    }
                }
                
                Text("\(title)")
                
                Divider()
                Text("Biggg：\n")
                HStack(alignment: .top,spacing: 30){
                    multiline(txt: $msg)

                        .clipShape(BubbleArrow(myMsg: myMsg))
                }.padding()
                Divider()
                Text("醫護人員回覆：\n")
                HStack(alignment: .top,spacing: 30){
                    multiline醫護(txt: $msgre)
                   .clipShape(BubbleArrow右(myMsg: myMsg))
            }.padding()
            .onAppear {
               // self.obs.update()
                self.msg = self.data.msg
                self.title = self.data.title
                self.msgre = self.data.msgre
            }
            }
        }
    }
}

struct multiline : UIViewRepresentable {
    
    
    @Binding var txt : String
    
    func makeCoordinator() -> multiline.Coordinator {
        
        return multiline.Coordinator(parent1: self)
        
    }
    func makeUIView(context: UIViewRepresentableContext<multiline>) -> UITextView{
       
        let textview = UITextView(frame: CGRect(x: 60,y: 60,width: 100,height: 100))
        textview.font = .systemFont(ofSize: 18)
        
        textview.delegate = context.coordinator
        textview.backgroundColor = UIColor(red: 212/255, green: 192/255, blue:226/255, alpha: 1)
        textview.autocapitalizationType = .sentences
        textview.isSelectable = true
        textview.isUserInteractionEnabled = true
        textview.textAlignment = NSTextAlignment.left//左對齊
        
        return textview
    }
    
    func updateUIView(_ uiView: UITextView, context: UIViewRepresentableContext<multiline>) {
        
        uiView.text = txt
    }
    
    class Coordinator : NSObject,UITextViewDelegate{
        
        var parent : multiline
        
        init(parent1 : multiline) {
            
            parent = parent1
        }
        
        func textViewDidChange(_ textView: UITextView) {
            
            self.parent.txt = textView.text
        }
    }
}
struct multiline醫護 : UIViewRepresentable {
    
    
    @Binding var txt : String
    
    func makeCoordinator() -> multiline醫護.Coordinator {
        
        return multiline醫護.Coordinator(parent2: self)
        
    }
    func makeUIView(context: UIViewRepresentableContext<multiline醫護>) -> UITextView{
        
        let textview = UITextView(frame: CGRect(x: 60,y: 60,width: 100,height: 100))
        textview.font = .systemFont(ofSize: 18)
        textview.delegate = context.coordinator
        
        textview.backgroundColor = UIColor(red: 203/255, green: 220/255, blue:231/255, alpha: 1)
        textview.textAlignment = NSTextAlignment.right//左對齊
        
       
        return textview
    }
    
    func updateUIView(_ uiView: UITextView, context: UIViewRepresentableContext<multiline醫護>) {
        
        uiView.text = txt
    }
    
    class Coordinator : NSObject,UITextViewDelegate{
        
        var parent : multiline醫護
        
        init(parent2 : multiline醫護) {
            
            parent = parent2
        }
        
        func textViewDidChange(_ textView: UITextView) {
            
            self.parent.txt = textView.text
        }
    }
}

struct type : Identifiable {
    
    var id : String
    var title : String
    var msg : String
    var day : String
    var msgre : String
   
}

    



struct BubbleArrow : Shape {

    var myMsg : Bool
    
    func path(in rect: CGRect) -> Path {
        
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: myMsg ?  [.topRight,.bottomLeft,.bottomRight] : [.topLeft,.bottomLeft,.bottomRight] , cornerRadii: CGSize(width: 0, height: 0))
        
        return Path(path.cgPath)
    }
}
struct BubbleArrow右 : Shape {

    var myMsg : Bool
    
    func path(in rect: CGRect) -> Path {
        
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: myMsg ?  [.topLeft,.bottomLeft,.bottomRight] : [.topRight,.bottomLeft,.bottomRight], cornerRadii: CGSize(width: 0, height: 0))
        
        return Path(path.cgPath)
    }
}





class chatobser : ObservableObject{
    @Published var datas = [type]()
    
    init() {//初始
            let re = WebService()
            let w1 = re.All_chat(num: "Biggg")
            var k = 0
            let i = w1.count
            for _ in k...i{
                if(k>=i)
                {
                    break;
                }
                else if(w1[0]=="null")
                {
                    break;
                }
                else{
                    let data_BP1 = String(w1[k]!)
                    let first:CharacterSet = ["：",","];
                    let first2 = data_BP1.components(separatedBy: first)
                    self.datas.append(type(id: first2[1], title: first2[3], msg: first2[5], day: first2[7], msgre: first2[9]))
                    
                    k+=1
                }
            }
    }
    func add(title : String,msg: String,date: Date){
        
        let re = WebService()
        let w1 = re.Insert_chat(num: "Biggg", topic: title, body: msg)
    
    }
    func update(){
        let re = WebService()
        
        let w1 = re.All_chat(num: "Biggg")
        let k = 0
        let data_BP1 = String(w1[k]!)
        let first:CharacterSet = ["：",","];
        let first2 = data_BP1.components(separatedBy: first)
        self.datas.append(type(id: first2[1], title: first2[3], msg: first2[5], day: first2[7], msgre: first2[9]))
}
    
}
