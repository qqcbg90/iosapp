//
//  pagetwo.swift
//  icansee
//
//  Created by WenLi Lee on 2020/12/9.
//

import SwiftUI

struct pagetwo: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct pagetwo_Previews: PreviewProvider {
    static var previews: some View {
        pagetwo()
    }
}
