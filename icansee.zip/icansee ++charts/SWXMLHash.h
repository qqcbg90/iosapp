﻿//
//  SWXMLHash.h
//  SWXMLHash
//
//  Created by David Mohundro on 7/8/14.
//
//

#import <Foundation/Foundation.h>

//! Project version number for SWXMLHash.
FOUNDATION_EXPORT double SWXMLHashVersionNumber;

//! Project version string for SWXMLHash.
FOUNDATION_EXPORT const unsigned char SWXMLHashVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SWXMLHash/PublicHeader.h>


