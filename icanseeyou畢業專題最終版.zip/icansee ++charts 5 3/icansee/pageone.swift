//
//  pageone.swift
//  icansee
//
//  Created by WenLi Lee on 2020/12/9.
//

import SwiftUI

struct pageone: View {
    @Binding var user : String
    var body: some View {
       Text("")
    }
}

struct pageone_Previews: PreviewProvider {
    static var previews: some View {
        pageone(user: .constant(""))
    }
}

        
