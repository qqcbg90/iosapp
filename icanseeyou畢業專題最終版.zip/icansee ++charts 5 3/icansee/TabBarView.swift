//
//  ContentView.swift
//  icansee
//
//  Created by WenLi Lee on 2020/11/3.
//

import SwiftUI

struct TabBarView: View {
    
    @Binding var user : String
  
    var body: some View {
        NavigationView{
            TabbarItemView(user: .constant(user))//將user傳入TabbarItemView
        }.navigationBarHidden(true)
        .edgesIgnoringSafeArea(.bottom)
        .navigationBarBackButtonHidden(false)
        
    }
}

struct TabBarView_Previews: PreviewProvider {
    static var previews: some View {
        TabBarView(user: .constant(""))
    }
}



//MARK:- 導覽列設計
struct TabbarItemView : View {
    
    @State var selectedTab = "home"
    @State var edge = UIApplication.shared.windows.first?.safeAreaInsets

    //
    @Binding var user : String
    var body: some View{
        
        ZStack(alignment: Alignment(horizontal: .center, vertical: .bottom)) {
            
            //導覽列 頁面下面的四個icon
            TabView(selection: $selectedTab) {
                
                PersonalRecordView(user: $user)
                    .tag("home") //紀錄
                
                ChatView(user: $user)
                    .tag("chat") //聊天室
                
                InfoVIew()
                    .tag("info") //衛教資訊
                
                SettingVIew(user: $user)
                    .tag("set") //設定
            }
            .foregroundColor(Color.black)
            .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
            .edgesIgnoringSafeArea(.all)
            .background(Color.white.edgesIgnoringSafeArea(.all))
            .edgesIgnoringSafeArea(.all)
            .navigationBarHidden(true)
            .statusBar(hidden: true)
            .navigationBarBackButtonHidden(true)
              
            // 導覽列位置
            
            HStack(spacing: 0){
                
                ForEach(tabs,id: \.self){image in
                    
                    TabButton(image: image, selectedTab: $selectedTab)
                    
                    if image != tabs.last{
                        Spacer(minLength: 0)
                    }
                }
            }
            .padding(.horizontal,25)
            .padding(.vertical,5)
            .background(Color.white)
            .clipShape(Capsule())
            .shadow(color: Color.black.opacity(0.15), radius: 5, x: 5, y: 5)
            .shadow(color: Color.black.opacity(0.15), radius: 5, x: -5, y: -5)
            .padding(.horizontal)
            .padding(.bottom,edge!.bottom == 0 ? 20 : 0)
        }
        .ignoresSafeArea(.keyboard, edges: .bottom)
        .background(Color(.white).ignoresSafeArea(.all, edges: .all))
    }
}

// tabs...
// Image Names...
var tabs = ["home","chat","info","set"]

struct TabButton : View {
    
    var image : String
    @Binding var selectedTab : String
    
    var body: some View{
        
        Button(action: {selectedTab = image}) {
            
            Image(image)
            .renderingMode(.template)
            .foregroundColor(selectedTab == image ? Color(.orange) : Color.black.opacity(0.4))
            .background(Color(.white).ignoresSafeArea(.all, edges: .all))
            .padding()
        }
    }
}
//MARK:- 首頁（個人健康資料的部分）
struct PersonalRecordView : View {
    
    
    @State var txt = ""
    @State var edge = UIApplication.shared.windows.first?.safeAreaInsets
    @State var index = 0
    @State var show = false
    @Binding var user : String
    @StateObject var obs : chatobser = chatobser()
    @State private var selection: String? = nil
    
    var body: some View {
        NavigationView{
            Record(user: .constant(user))
        VStack{
            
            ScrollView(.vertical, showsIndicators: false) {
                
                VStack{
                    Text("\(user)你的健康，我看得見！")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(Color.black)
                    HStack(){
                        
      //換頁_______________________
                        NavigationLink(destination: HeartRecord(user: .constant(user)), tag: "Heart", selection: $selection) { EmptyView() }
                        NavigationLink(destination: CalRecord(), tag: "Cal", selection: $selection) { EmptyView() }
                        NavigationLink(destination: SportRecord(), tag: "Sport", selection: $selection) { EmptyView() }
                        NavigationLink(destination: EyesRecord(), tag: "Eyes", selection: $selection) { EmptyView() }
                        NavigationLink(destination: PoopooRecord(), tag: "Poopoo", selection: $selection) { EmptyView() }
                        NavigationLink(destination: Totalchart(), tag: "total", selection: $selection) { EmptyView() }
                        NavigationLink(destination: RedLine(), tag: "紅外線", selection: $selection) { EmptyView() }
                        NavigationLink(destination: GpsView(), tag: "GPS", selection: $selection){}
                            
      //History_______________________
                        Menu("View History"){
                                Section{
                                    Button(action: {
                                        self.selection = "Heart"
                                        
                                    }){Label("生理紀錄", image:"生理數值")}
                                    Button(action: {
                                        self.selection = "Cal"
                                        
                                    }){Label("熱量紀錄", image:"三餐熱量")}
                                    Button(action: {
                                        self.selection = "Sport"
                                        
                                    }){Label("運動紀錄", image:"運動")}
                                    Button(action: {
                                        self.selection = "Eyes"
                                        
                                    }){Label("睡眠紀錄", image:"睡眠用眼")}
                                    Button(action: {
                                        self.selection = "Poopoo"
                                        
                                    }){Label("排便紀錄", image:"排便")}
                                    Button(action: {
                                       
                                        self.selection = "total"
                                        
                                    }){Label("生理統計圖", image:"chart")}
                                    Button(action: {
                                       
                                        self.selection = "紅外線"
                                        
                                    }){Label("早期失智偵測", image:"record")}
                                    Button(action: {
                                       
                                        self.selection = "GPS"
                                        
                                    }){Label("GPS", image:"gps")}
                                }
                        }.foregroundColor(Color(.white))
                        
                    }.frame(width: 150, height: 20)
                    .padding(.vertical,10)
                    .padding(.horizontal,5)
                    .background(Color(.orange))
                    .clipShape(Capsule())
                    .position(x: 300, y: 20)
                    
                    Spacer()
                    
                    VStack(alignment: .leading, spacing:10){
                        let f = re.Test_air(uid: user)//取資料
                        if (f == "null"){//當無資料時顯示
                            HStack(){
                                Text("𖤣𖥧濕度：無資料")
                                         .foregroundColor(.blue)
                                    .font(.system(size: 20))
                                    .multilineTextAlignment(.leading)
                                Text("      𖤣𖥧室溫：無資料")
                                         .foregroundColor(.blue)
                                    .font(.system(size: 20))
                                    .multilineTextAlignment(.leading)
                            }
                            HStack(){
                                Text("𖤣𖥧  CO ：無資料")
                                         .foregroundColor(.blue)
                                    .font(.system(size: 20))
                                    .multilineTextAlignment(.leading)
                                Text("      𖤣𖥧PM2.5：無資料")
                                         .foregroundColor(.blue)
                                    .font(.system(size: 20))
                                    .multilineTextAlignment(.leading)
                            }
                        }
                        else
                        {
                            let d = f.components(separatedBy: first)//取資料
                            let co = d[5].trimmingCharacters(in: .whitespaces)
                            HStack(){
                                Text("𖤣𖥧濕度：\(d[3])%")
                                         .foregroundColor(.blue)
                                    .font(.system(size: 20))
                                    .multilineTextAlignment(.leading)
                                Text("            𖤣𖥧室溫：\(d[1])°C")
                                         .foregroundColor(.blue)
                                    .font(.system(size: 20))
                                    .multilineTextAlignment(.leading)
                            }
                            HStack(){
                                Text("𖤣𖥧CO：\(co)ppm")
                                         .foregroundColor(.blue)
                                    .font(.system(size: 20))
                                  //  .lineSpacing(15)
                                    .multilineTextAlignment(.leading)
                                Text("        𖤣𖥧PM2.5：\(d[7])μg/m3")
                                         .foregroundColor(.blue)
                                    .font(.system(size: 20))
                                    .multilineTextAlignment(.leading)
                            }
                        }
                    }//濕度溫度空氣品質那些
                    
                    
                    
                     
                    
//MARK:- 首頁 一格一格的框框
              
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 20), count: 2),spacing: 20){
                        
                        ForEach(records){record in
                            NavigationLink(destination: Record(user: $user)){

                                NavigationLink(destination: DetailView(record: record, user: $user)) {
                                 
                                    RecordCardView(record: record, user: $user)
                                
                            }
                        }.navigationBarBackButtonHidden(true)
                            .edgesIgnoringSafeArea(.all)
                      }
                    }
                    .navigationBarBackButtonHidden(true)
                    .padding(.top)
                    
                }
                .padding()
                .padding(.bottom,edge!.bottom + 70)
                .navigationBarBackButtonHidden(true)
            }
            
        }
        .background(Color.white.edgesIgnoringSafeArea(.all))
        .edgesIgnoringSafeArea(.all)
        .navigationBarHidden(true)
        .statusBar(hidden: true)
        .navigationBarBackButtonHidden(true)
      }
   
    }
}



// TabViews...

struct Chat : View {
    
    var body: some View{
       Text("")
    }
}

struct Info : View {
    
    var body: some View{
     Text("")
           
        }
    }


struct Settings : View {
    
    var body: some View{
    
        Text("")
    }
}


