//
//  test.swift
//  icansee
//
//  Created by WenLi Lee on 2020/11/15.
//

import SwiftUI

struct test: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct test_Previews: PreviewProvider {
    static var previews: some View {
        test()
    }
}
