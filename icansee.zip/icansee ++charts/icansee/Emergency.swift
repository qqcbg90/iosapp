//
//  Emergency.swift
//  icansee
//
//  Created by WenLi Lee on 2020/12/8.
//

import SwiftUI
import Combine
//緊急聯絡人
struct Emergency: View {
    var relationship  = ["媽媽", "爸爸", "姊姊", "妹妹","哥哥","弟弟"]
    @State var selectedrelationship  = "媽媽"
    @ObservedObject var bluetooth = settings_()
    //@ObservedObject var bluetooth: settings_
    @State var emercy = ""
    
    var body: some View {
        ZStack(alignment: Alignment(horizontal: .center, vertical: .center)){
            VStack(alignment: .leading, spacing: 25) {
              Spacer(minLength: 20)
                VStack(alignment: .leading, spacing: 10){
                  Text("請輸入緊急聯絡人帳號").foregroundColor(Color("Color1"))
                  TextField("緊急聯絡人帳號", text: $emercy)
                  Divider().background(Color("Color1").opacity(0.5))
                }
                  
                  VStack(alignment: .leading, spacing: 10){
                    Text("此聯絡人是你的：\(selectedrelationship)").foregroundColor(Color("Color1"))
                    Section(header:Text("")){
                        HStack {
                                Picker(selection: $selectedrelationship, label:
                                        Text("選擇運動")
                                ){
                                   ForEach(relationship, id: \.self) { (sport) in
                                    Text(sport)
                                        .foregroundColor(Color("Color1"))
                                   }
                                }
                                
                             }
                    }
                  }
     
                HStack{
                    
                    Spacer()
                  
//MARK:- webservice
                    Button(action: {

                    })
                    {
                        Text("Save")
                            .fontWeight(.bold)
                            .foregroundColor(Color.white)
                            .padding(.vertical)
                            .padding(.horizontal,45)
                            .background(Color("Color1"))
                            .clipShape(Capsule())
                      
                    }
                  
                    Spacer()
                }
                
                .padding(.top)
                
                Spacer(minLength: 0)
            }
          
            .padding()

        }.background(Color.white.edgesIgnoringSafeArea(.all))
        .edgesIgnoringSafeArea(.all)
        .statusBar(hidden: true)
    
}
}
struct Emergency_Previews: PreviewProvider {
    static var previews: some View {
        Emergency()
    }
}


