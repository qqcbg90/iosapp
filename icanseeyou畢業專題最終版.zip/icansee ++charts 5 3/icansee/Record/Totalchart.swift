//
//  Totalchart.swift
//  icansee
//
//  Created by WenLi Lee on 2021/3/10.
//

import SwiftUI
import Charts

struct Totalchart: View {
    var body: some View {
        NavigationView{
            
            totalRecord(title: Binding<String>.constant("28day"))
                .navigationBarHidden(true)
                .edgesIgnoringSafeArea(.all)
                .navigationBarHidden(true)
        }
        
    }
}

struct Totalchart_Previews: PreviewProvider {
    static var previews: some View {
        Totalchart()
    }
}

struct totalRecord : View {
    //var dataa : Datas
    @State var tab = "Today"
    @State var subTab = "7day"
    @State var tab3 = "28day"
    @Binding var title : String
    @State private var show_HR: Bool = false
    @State private var show_SpO2: Bool = false
    @State private var show_BP: Bool = false
    @State private var show_Temp: Bool = false
    @Namespace var animation
    
    
    // var qqq :tabbutton
    @State var edges = UIApplication.shared.windows.first?.safeAreaInsets
    
    var body: some View{
        
        VStack{
            
            // Or YOu can use Foreach Also...
            VStack(spacing: 20){
                Text("𖥧⌂ 生理紀錄統計圖 𖥧⌂")
                    .font(.title2)
                
                HStack(spacing: 15){
                    Button(action: {
                        show_HR = true
                        show_SpO2 = false
                        show_BP = false
                        show_Temp = false
                    }) {
                        DatasViews(data: myDatas[0])
                    }
                    
                    Button(action: {
                        show_SpO2 = true
                        show_HR = false
                        show_BP = false
                        show_Temp = false
                        
                    }) {
                       DatasViews(data: myDatas[1])
                    }
                }
                
                HStack(spacing: 15){
                    
                    Button(action: {
                        show_BP = true
                        show_HR = false
                        show_Temp = false
                        show_SpO2 = false
                    }) {
                        DatasViews(data: myDatas[2])
                    }
                    Button(action: {
                        show_Temp = true
                        show_HR = false
                        show_BP = false
                        show_SpO2 = false
                    }) {
                        DatasViews(data: myDatas[3])
                    }
                    
                }
            }
            .padding(.horizontal)
            
            HStack(spacing: 10){
                tabbutton(selected: $tab, title: "7days", animation: animation)
                
                tabbutton(selected: $tab, title: "28days", animation: animation)
                
                tabbutton(selected: $tab, title: "All", animation: animation)
            }
            .background(Color.white.opacity(0.08))
            .clipShape(Capsule())
            
            
            ZStack{
                
                Color("lightorang")
                    //.clipShape(CustomCorners(corners: [.topLeft,.topRight], size: 45))
                    .ignoresSafeArea(.all, edges: .bottom)
                
                VStack{
                    
                    HStack{
                        if(show_HR==true){
                            if (tab == "7days")
                            {
                                GeometryReader { p in
                                    VStack {
                                        TotalHR7()
                                      
                                    }
                                }
                            }
                            else if (tab == "28days")
                            {
                                GeometryReader { p in
                                    VStack {
                                        TotalHR28()
                                        
                                    }
                                }
                            }
                            else if (tab == "All")
                            {
                                GeometryReader { p in
                                    VStack {
                                        TotalHRall()
                                       
                                    }
                                }
                            }
                            Spacer(minLength: 0)
                            
                        }
                        
                        else if(show_SpO2==true){
                            if (tab == "7days")
                            {
                                GeometryReader { p in
                                    VStack {
                                        TotalSpO2_7()
                                        
                                    }
                                }
                            }
                            else if (tab == "28days")
                            {
                                GeometryReader { p in
                                    VStack {
                                        TotalSpO2_28()
                                       
                                    }
                                }
                            }
                            else if (tab == "All")
                            {
                                GeometryReader { p in
                                    VStack {
                                        TotalSpO2_all()
                                       
                                    }
                                }
                            }
                            Spacer(minLength: 0)
                        }
                        
                        else if(show_BP==true){
                            if (tab == "7days")
                            {
                                GeometryReader { p in
                                    VStack {
                                        TotalBP7()
                                       
                                    }
                                }
                            }
                            else if (tab == "28days")
                            {
                                GeometryReader { p in
                                    VStack {
                                        TotalBP28()
                                        
                                    }
                                }
                            }
                            else if (tab == "All")
                            {
                                GeometryReader { p in
                                    VStack {
                                        TotalBPall()
                                       
                                    }
                                }
                            }
                            Spacer(minLength: 0)
                        }
                        
                        else if(show_Temp==true){
                            if (tab == "7days")
                            {
                                GeometryReader { p in
                                    VStack {
                                        TotalTemp_7()
                                       
                                    }
                                }
                            }
                            else if (tab == "28days")
                            {
                                GeometryReader { p in
                                    VStack {
                                        TotalTemp_28()
                                    }
                                }
                            }
                            else if (tab == "All")
                            {
                                GeometryReader { p in
                                    VStack {
                                        TotalTemp_all()
                                       
                                    }
                                }
                            }
                            Spacer(minLength: 0)
                        }
                    } .padding()
                    .padding(.top,10)
                    VStack(spacing: 10){
                    }
                    .padding(.horizontal,20)
                    .padding(.bottom,130)
                    
                }
            }
            .padding(.top,20)
        }
        .background(Color("lightorang").ignoresSafeArea(.all, edges: .bottom))
        
    }
    
}

struct Datass: Identifiable {
    
    var id = UUID().uuidString
    var value : String
    var color : Color
}

var myDatas = [
    
    Datass(value: "心跳", color: Color.orange),
    Datass(value: "血氧", color: Color.red),
    Datass(value: "血壓", color: Color.blue),
    // Datas(title: "血糖", value: "130mg/dl", color: Color.pink),
    Datass(value: "體溫", color: Color.purple),
]

struct DatasViews : View {
    
    var data : Datass
    
    var body: some View{
        
        ZStack{
            
            HStack{
                
                VStack(alignment: .leading, spacing: 15) {
                    
                    Text(data.value)
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                }
                
                Spacer(minLength: 0)
            }
            .padding()
        }
        .background(data.color)
        .cornerRadius(10)
    }
}


//
struct TotalBP7 : UIViewRepresentable {
    
    
    let months = [String]()
    let 早餐 = [21, 24, 26, 23, 22, 26, 24, 28, 22, 24, 25, 24] //數字最小
    
    func makeUIView(context: Context) -> BarChartView {
        return setChart(dataPoints: months, values:早餐 )
    }
    
    func updateUIView(_ uiView: BarChartView, context: UIViewRepresentableContext<TotalBP7>)
    {
        
    }
    
    typealias UIViewType = BarChartView
    
    //Bar chart accepts data as array of BarChartDataEntry objects
    var myView = BarChartView()
  
    func setChart(dataPoints: [String], values: [Int]) -> BarChartView {
        
        //若沒有資料，顯示的文字
        myView.noDataText = "You need to provide data for the chart."
        
        //存放資料的陣列，型別是BarChartDataEntry.
        
       
        
        //迴圈，來載入每筆資料內容
        var set次數: [BarChartDataEntry] = []
        
        //迴圈，來載入每筆資料內容
        let w = re.Total_BP(uid: "Biggg", choose: "7day", StartTime: "", EndTime: "")
        let i = w.count
        var 次數 = [Int]()
       
        var 分類 = [String]()
        var k = 0
        let xAxis = myView.xAxis
        let yAxis = myView.leftAxis
        for _ in k...i{
            if(k>=i)
            {
                break;
            }
            else{
                let data_BP1 = String(w[k]!)
                let first:CharacterSet = [",",","];
                let first2 = data_BP1.components(separatedBy: first)
                次數.append(first2[1].toInt()!)
              
                let data次數 = BarChartDataEntry(x: Double(k), y: Double(次數[k]))
            
                set次數.append(data次數)
            
                分類.append(first2[0])
                myView.xAxis.valueFormatter = IndexAxisValueFormatter(values: 分類)
                myView.xAxis.granularity = 1
                k+=1
            }
            
        }
        //顯示的資料之內容與名稱（左下角所顯示的）
        let chartData次數 = BarChartDataSet(entries: set次數, label: "血壓狀況")
   
        //把dataSet轉換成可顯示的BarChartData
        let chartData = BarChartData(dataSets: [chartData次數])
        
        //指定剛剛連結的myView要顯示的資料為charData
        myView.data = chartData
        
        //改變chartDataSet的顏色
        chartData次數.colors = [UIColor(red: 172/255, green: 195/255, blue: 209/255, alpha: 1)]
       // chartData次數.colors = ChartColorTemplates.colorful()
        myView.data?.setValueFont(UIFont.systemFont(ofSize: 18))//文字字型
        myView.data?.setValueTextColor(UIColor.brown)  //文字顏色
        
        //標籤換到下方
        myView.xAxis.labelPosition = .bottom
        
        //改變barChartView的背景顏色
        // myView.backgroundColor = UIColor(red:0/255, green: 0/255, blue: 0/255, alpha: 1)
        
        //一個一個延遲顯現的特效
       // myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
        
        //彈一下特效
     //myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0, easingOption: .easeInBounce)
        
        //設立界線

        
        
        //設定X軸文字
        
        xAxis.labelTextColor = UIColor.brown //label文字顏色
        //xAxis.axisLineColor = UIColor.black  // 設定X軸顏色
       // xAxis.drawGridLinesEnabled = false  // 隱藏隔線
        xAxis.labelPosition = .bottom       // 設定文字位置
       // xAxis.spaceMin = 1.5                // X軸左邊間隔距離
     //   xAxis.spaceMax = 1.5                // X軸右邊間隔距離
        xAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        myView.doubleTapToZoomEnabled = false   //取消雙擊縮放
        myView.dragEnabled = true  //啟用拖拽圖表
        myView.dragDecelerationEnabled = false  //拖拽後是否有慣性效果
        myView.dragDecelerationFrictionCoef = 0 //拖拽後慣性效果的摩擦係數(0~1)，數值越小，慣性越不明顯
     
        //設定y軸文字
        myView.rightAxis.enabled = false
        yAxis.drawZeroLineEnabled = true   //從0開始繪製
        yAxis.axisLineColor =  UIColor.black  //Y軸顏色
        
        yAxis.axisMaximum = 10
        yAxis.axisMinimum = 0
        
        //設定Y軸上標籤的樣式
        yAxis.labelPosition = .outsideChart   //label位置
        yAxis.labelTextColor = UIColor.brown   //文字顏色
        yAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        //設定Y軸上標籤顯示數字的格式
         //   let  leftFormatter = NumberFormatter()  //自定義格式
         // leftFormatter.positiveSuffix = "kacl"  //數字字尾單位
         //  myView.leftAxis.valueFormatter = DefaultAxisValueFormatter.init(formatter: leftFormatter)
        
        return myView
        
        
    }

    
    
}//7day

struct TotalBP28 : UIViewRepresentable {
    
    
    let months = [String]()
    let 早餐 = [21, 24, 26, 23, 22, 26, 24, 28, 22, 24, 25, 24] //數字最小
    
    func makeUIView(context: Context) -> BarChartView {
        return setChart(dataPoints: months, values:早餐 )
    }
    
    func updateUIView(_ uiView: BarChartView, context: UIViewRepresentableContext<TotalBP28>)
    {
        
    }
    
    typealias UIViewType = BarChartView
    
    //Bar chart accepts data as array of BarChartDataEntry objects
    var myView = BarChartView()
  
    func setChart(dataPoints: [String], values: [Int]) -> BarChartView {
        
        //若沒有資料，顯示的文字
        myView.noDataText = "You need to provide data for the chart."
        
        //存放資料的陣列，型別是BarChartDataEntry.
        
       
        
        //迴圈，來載入每筆資料內容
        var set次數: [BarChartDataEntry] = []
        
        //迴圈，來載入每筆資料內容
        let w = re.Total_BP(uid: "Biggg", choose: "28day", StartTime: "", EndTime: "")
        let i = w.count
        var 次數 = [Int]()
       
        var 分類 = [String]()
        var k = 0
        let xAxis = myView.xAxis
        let yAxis = myView.leftAxis
        for _ in k...i{
            if(k>=i)
            {
                break;
            }
            else{
                let data_BP1 = String(w[k]!)
                let first:CharacterSet = [",",","];
                let first2 = data_BP1.components(separatedBy: first)
                次數.append(first2[1].toInt()!)
              
                let data次數 = BarChartDataEntry(x: Double(k), y: Double(次數[k]))
            
                set次數.append(data次數)
            
                分類.append(first2[0])
                myView.xAxis.valueFormatter = IndexAxisValueFormatter(values: 分類)
                myView.xAxis.granularity = 1
                k+=1
            }
            
        }
        //顯示的資料之內容與名稱（左下角所顯示的）
        let chartData次數 = BarChartDataSet(entries: set次數, label: "血壓狀況")
   
        //把dataSet轉換成可顯示的BarChartData
        let chartData = BarChartData(dataSets: [chartData次數])
        
        //指定剛剛連結的myView要顯示的資料為charData
        myView.data = chartData
        
        //改變chartDataSet的顏色
        chartData次數.colors = [UIColor(red: 172/255, green: 195/255, blue: 209/255, alpha: 1)]
      
        myView.data?.setValueFont(UIFont.systemFont(ofSize: 18))//文字字型
        myView.data?.setValueTextColor(UIColor.brown)  //文字顏色
        
        //標籤換到下方
        myView.xAxis.labelPosition = .bottom
        
        //改變barChartView的背景顏色
        // myView.backgroundColor = UIColor(red:0/255, green: 0/255, blue: 0/255, alpha: 1)
        
        //一個一個延遲顯現的特效
       // myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
        
        //彈一下特效
     //myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0, easingOption: .easeInBounce)
        
        //設立界線

        
        
        //設定X軸文字
        
        xAxis.labelTextColor = UIColor.brown //label文字顏色
        //xAxis.axisLineColor = UIColor.black  // 設定X軸顏色
       // xAxis.drawGridLinesEnabled = false  // 隱藏隔線
        xAxis.labelPosition = .bottom       // 設定文字位置
       // xAxis.spaceMin = 1.5                // X軸左邊間隔距離
     //   xAxis.spaceMax = 1.5                // X軸右邊間隔距離
        xAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        myView.doubleTapToZoomEnabled = false   //取消雙擊縮放
        myView.dragEnabled = true  //啟用拖拽圖表
        myView.dragDecelerationEnabled = false  //拖拽後是否有慣性效果
        myView.dragDecelerationFrictionCoef = 0 //拖拽後慣性效果的摩擦係數(0~1)，數值越小，慣性越不明顯
     
        //設定y軸文字
        myView.rightAxis.enabled = false
        yAxis.drawZeroLineEnabled = true   //從0開始繪製
        yAxis.axisLineColor =  UIColor.black  //Y軸顏色
        
        yAxis.axisMaximum = 30
        yAxis.axisMinimum = 0
        
        //設定Y軸上標籤的樣式
        yAxis.labelPosition = .outsideChart   //label位置
        yAxis.labelTextColor = UIColor.brown   //文字顏色
        yAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        //設定Y軸上標籤顯示數字的格式
         //   let  leftFormatter = NumberFormatter()  //自定義格式
         // leftFormatter.positiveSuffix = "kacl"  //數字字尾單位
         //  myView.leftAxis.valueFormatter = DefaultAxisValueFormatter.init(formatter: leftFormatter)
        
        return myView
        
        
    }

    
    
}//28day

struct TotalBPall : UIViewRepresentable {
    
    
    let months = [String]()
    let 早餐 = [21, 24, 26, 23, 22, 26, 24, 28, 22, 24, 25, 24] //數字最小
    
    func makeUIView(context: Context) -> BarChartView {
        return setChart(dataPoints: months, values:早餐 )
    }
    
    func updateUIView(_ uiView: BarChartView, context: UIViewRepresentableContext<TotalBPall>)
    {
        
    }
    
    typealias UIViewType = BarChartView
    
    //Bar chart accepts data as array of BarChartDataEntry objects
    var myView = BarChartView()
  
    func setChart(dataPoints: [String], values: [Int]) -> BarChartView {
        
        //若沒有資料，顯示的文字
        myView.noDataText = "You need to provide data for the chart."
        
        //存放資料的陣列，型別是BarChartDataEntry.
        
       
        
        //迴圈，來載入每筆資料內容
        var set次數: [BarChartDataEntry] = []
        
        //迴圈，來載入每筆資料內容
        let w = re.Total_BP(uid: "Biggg", choose: "all", StartTime: "", EndTime: "")
        let i = w.count
        var 次數 = [Int]()
       
        var 分類 = [String]()
        var k = 0
        let xAxis = myView.xAxis
        let yAxis = myView.leftAxis
        for _ in k...i{
            if(k>=i)
            {
                break;
            }
            else{
                let data_BP1 = String(w[k]!)
                let first:CharacterSet = [",",","];
                let first2 = data_BP1.components(separatedBy: first)
                次數.append(first2[1].toInt()!)
              
                let data次數 = BarChartDataEntry(x: Double(k), y: Double(次數[k]))
            
                set次數.append(data次數)
            
                分類.append(first2[0])
                myView.xAxis.valueFormatter = IndexAxisValueFormatter(values: 分類)
                myView.xAxis.granularity = 1
                k+=1
            }
            
        }
        //顯示的資料之內容與名稱（左下角所顯示的）
        let chartData次數 = BarChartDataSet(entries: set次數, label: "血壓狀況")
   
        //把dataSet轉換成可顯示的BarChartData
        let chartData = BarChartData(dataSets: [chartData次數])
        
        //指定剛剛連結的myView要顯示的資料為charData
        myView.data = chartData
        
        //改變chartDataSet的顏色
        chartData次數.colors = [UIColor(red: 172/255, green: 195/255, blue: 209/255, alpha: 1)]
      
        myView.data?.setValueFont(UIFont.systemFont(ofSize: 18))//文字字型
        myView.data?.setValueTextColor(UIColor.brown)  //文字顏色
        
        //標籤換到下方
        myView.xAxis.labelPosition = .bottom
        
        //改變barChartView的背景顏色
        // myView.backgroundColor = UIColor(red:0/255, green: 0/255, blue: 0/255, alpha: 1)
        
        //一個一個延遲顯現的特效
       // myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
        
        //彈一下特效
     //myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0, easingOption: .easeInBounce)
        
        //設立界線

        
        
        //設定X軸文字
        
        xAxis.labelTextColor = UIColor.brown //label文字顏色
        //xAxis.axisLineColor = UIColor.black  // 設定X軸顏色
       // xAxis.drawGridLinesEnabled = false  // 隱藏隔線
        xAxis.labelPosition = .bottom       // 設定文字位置
       // xAxis.spaceMin = 1.5                // X軸左邊間隔距離
     //   xAxis.spaceMax = 1.5                // X軸右邊間隔距離
        xAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        myView.doubleTapToZoomEnabled = false   //取消雙擊縮放
        myView.dragEnabled = true  //啟用拖拽圖表
        myView.dragDecelerationEnabled = false  //拖拽後是否有慣性效果
        myView.dragDecelerationFrictionCoef = 0 //拖拽後慣性效果的摩擦係數(0~1)，數值越小，慣性越不明顯
     
        //設定y軸文字
        myView.rightAxis.enabled = false
        yAxis.drawZeroLineEnabled = true   //從0開始繪製
        yAxis.axisLineColor =  UIColor.black  //Y軸顏色
        
        yAxis.axisMaximum = 50
        yAxis.axisMinimum = 0
        
        //設定Y軸上標籤的樣式
        yAxis.labelPosition = .outsideChart   //label位置
        yAxis.labelTextColor = UIColor.brown   //文字顏色
        yAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        //設定Y軸上標籤顯示數字的格式
         //   let  leftFormatter = NumberFormatter()  //自定義格式
         // leftFormatter.positiveSuffix = "kacl"  //數字字尾單位
         //  myView.leftAxis.valueFormatter = DefaultAxisValueFormatter.init(formatter: leftFormatter)
        
        return myView
        
        
    }

    
    
}//all
//

struct TotalHR7 : UIViewRepresentable {
    
    
    let months = [String]()
    let 早餐 = [21, 24, 26, 23, 22, 26, 24, 28, 22, 24, 25, 24] //數字最小
    
    func makeUIView(context: Context) -> BarChartView {
        return setChart(dataPoints: months, values:早餐 )
    }
    
    func updateUIView(_ uiView: BarChartView, context: UIViewRepresentableContext<TotalHR7>)
    {
        
    }
    
    typealias UIViewType = BarChartView
    
    //Bar chart accepts data as array of BarChartDataEntry objects
    var myView = BarChartView()
  
    func setChart(dataPoints: [String], values: [Int]) -> BarChartView {
        
        //若沒有資料，顯示的文字
        myView.noDataText = "You need to provide data for the chart."
        
        //存放資料的陣列，型別是BarChartDataEntry.
        
       
        
        //迴圈，來載入每筆資料內容
        var set次數: [BarChartDataEntry] = []
        
        //迴圈，來載入每筆資料內容
        let w = re.Total_HR(uid: "Biggg", choose: "7day", StartTime: "", EndTime: "")
        let i = w.count
        var 次數 = [Int]()
       
        var 分類 = [String]()
        var k = 0
        let xAxis = myView.xAxis
        let yAxis = myView.leftAxis
        for _ in k...i{
            if(k>=i)
            {
                break;
            }
            else{
                let data_BP1 = String(w[k]!)
                let first:CharacterSet = [",",","];
                let first2 = data_BP1.components(separatedBy: first)
                次數.append(first2[1].toInt()!)
              
                let data次數 = BarChartDataEntry(x: Double(k), y: Double(次數[k]))
            
                set次數.append(data次數)
            
                分類.append(first2[0])
                myView.xAxis.valueFormatter = IndexAxisValueFormatter(values: 分類)
                myView.xAxis.granularity = 1
                k+=1
            }
            
        }
        //顯示的資料之內容與名稱（左下角所顯示的）
        let chartData次數 = BarChartDataSet(entries: set次數, label: "血壓狀況")
   
        //把dataSet轉換成可顯示的BarChartData
        let chartData = BarChartData(dataSets: [chartData次數])
        
        //指定剛剛連結的myView要顯示的資料為charData
        myView.data = chartData
        
        //改變chartDataSet的顏色
        chartData次數.colors = [UIColor(red: 198/255, green: 110/255, blue: 78/255, alpha: 1)]
      
        myView.data?.setValueFont(UIFont.systemFont(ofSize: 18))//文字字型
        myView.data?.setValueTextColor(UIColor.brown)  //文字顏色
        
        //標籤換到下方
        myView.xAxis.labelPosition = .bottom
        
        //改變barChartView的背景顏色
        // myView.backgroundColor = UIColor(red:0/255, green: 0/255, blue: 0/255, alpha: 1)
        
        //一個一個延遲顯現的特效
       // myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
        
        //彈一下特效
     //myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0, easingOption: .easeInBounce)
        
        //設立界線

        
        
        //設定X軸文字
        
        xAxis.labelTextColor = UIColor.brown //label文字顏色
        //xAxis.axisLineColor = UIColor.black  // 設定X軸顏色
       // xAxis.drawGridLinesEnabled = false  // 隱藏隔線
        xAxis.labelPosition = .bottom       // 設定文字位置
       // xAxis.spaceMin = 1.5                // X軸左邊間隔距離
     //   xAxis.spaceMax = 1.5                // X軸右邊間隔距離
        xAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        myView.doubleTapToZoomEnabled = false   //取消雙擊縮放
        myView.dragEnabled = true  //啟用拖拽圖表
        myView.dragDecelerationEnabled = false  //拖拽後是否有慣性效果
        myView.dragDecelerationFrictionCoef = 0 //拖拽後慣性效果的摩擦係數(0~1)，數值越小，慣性越不明顯
     
        //設定y軸文字
        myView.rightAxis.enabled = false
        yAxis.drawZeroLineEnabled = true   //從0開始繪製
        yAxis.axisLineColor =  UIColor.black  //Y軸顏色
        
        yAxis.axisMaximum = 10
        yAxis.axisMinimum = 0
        
        //設定Y軸上標籤的樣式
        yAxis.labelPosition = .outsideChart   //label位置
        yAxis.labelTextColor = UIColor.brown   //文字顏色
        yAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        //設定Y軸上標籤顯示數字的格式
         //   let  leftFormatter = NumberFormatter()  //自定義格式
         // leftFormatter.positiveSuffix = "kacl"  //數字字尾單位
         //  myView.leftAxis.valueFormatter = DefaultAxisValueFormatter.init(formatter: leftFormatter)
        
        return myView
        
        
    }

    
    
}//7day

struct TotalHR28 : UIViewRepresentable {
    
    
    let months = [String]()
    let 早餐 = [21, 24, 26, 23, 22, 26, 24, 28, 22, 24, 25, 24] //數字最小
    
    func makeUIView(context: Context) -> BarChartView {
        return setChart(dataPoints: months, values:早餐 )
    }
    
    func updateUIView(_ uiView: BarChartView, context: UIViewRepresentableContext<TotalHR28>)
    {
        
    }
    
    typealias UIViewType = BarChartView
    
    //Bar chart accepts data as array of BarChartDataEntry objects
    var myView = BarChartView()
  
    func setChart(dataPoints: [String], values: [Int]) -> BarChartView {
        
        //若沒有資料，顯示的文字
        myView.noDataText = "You need to provide data for the chart."
        
        //存放資料的陣列，型別是BarChartDataEntry.
        
       
        
        //迴圈，來載入每筆資料內容
        var set次數: [BarChartDataEntry] = []
        
        //迴圈，來載入每筆資料內容
        let w = re.Total_HR(uid: "Biggg", choose: "28day", StartTime: "", EndTime: "")
        let i = w.count
        var 次數 = [Int]()
       
        var 分類 = [String]()
        var k = 0
        let xAxis = myView.xAxis
        let yAxis = myView.leftAxis
        for _ in k...i{
            if(k>=i)
            {
                break;
            }
            else{
                let data_BP1 = String(w[k]!)
                let first:CharacterSet = [",",","];
                let first2 = data_BP1.components(separatedBy: first)
                次數.append(first2[1].toInt()!)
              
                let data次數 = BarChartDataEntry(x: Double(k), y: Double(次數[k]))
            
                set次數.append(data次數)
            
                分類.append(first2[0])
                myView.xAxis.valueFormatter = IndexAxisValueFormatter(values: 分類)
                myView.xAxis.granularity = 1
                k+=1
            }
            
        }
        //顯示的資料之內容與名稱（左下角所顯示的）
        let chartData次數 = BarChartDataSet(entries: set次數, label: "血壓狀況")
   
        //把dataSet轉換成可顯示的BarChartData
        let chartData = BarChartData(dataSets: [chartData次數])
        
        //指定剛剛連結的myView要顯示的資料為charData
        myView.data = chartData
        
        //改變chartDataSet的顏色
        chartData次數.colors = [UIColor(red: 198/255, green: 110/255, blue: 78/255, alpha: 1)]
      
        myView.data?.setValueFont(UIFont.systemFont(ofSize: 18))//文字字型
        myView.data?.setValueTextColor(UIColor.brown)  //文字顏色
        
        //標籤換到下方
        myView.xAxis.labelPosition = .bottom
        
        //改變barChartView的背景顏色
        // myView.backgroundColor = UIColor(red:0/255, green: 0/255, blue: 0/255, alpha: 1)
        
        //一個一個延遲顯現的特效
       // myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
        
        //彈一下特效
     //myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0, easingOption: .easeInBounce)
        
        //設立界線

        
        
        //設定X軸文字
        
        xAxis.labelTextColor = UIColor.brown //label文字顏色
        //xAxis.axisLineColor = UIColor.black  // 設定X軸顏色
       // xAxis.drawGridLinesEnabled = false  // 隱藏隔線
        xAxis.labelPosition = .bottom       // 設定文字位置
       // xAxis.spaceMin = 1.5                // X軸左邊間隔距離
     //   xAxis.spaceMax = 1.5                // X軸右邊間隔距離
        xAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        myView.doubleTapToZoomEnabled = false   //取消雙擊縮放
        myView.dragEnabled = true  //啟用拖拽圖表
        myView.dragDecelerationEnabled = false  //拖拽後是否有慣性效果
        myView.dragDecelerationFrictionCoef = 0 //拖拽後慣性效果的摩擦係數(0~1)，數值越小，慣性越不明顯
     
        //設定y軸文字
        myView.rightAxis.enabled = false
        yAxis.drawZeroLineEnabled = true   //從0開始繪製
        yAxis.axisLineColor =  UIColor.black  //Y軸顏色
        
        yAxis.axisMaximum = 30
        yAxis.axisMinimum = 0
        
        //設定Y軸上標籤的樣式
        yAxis.labelPosition = .outsideChart   //label位置
        yAxis.labelTextColor = UIColor.brown   //文字顏色
        yAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        //設定Y軸上標籤顯示數字的格式
         //   let  leftFormatter = NumberFormatter()  //自定義格式
         // leftFormatter.positiveSuffix = "kacl"  //數字字尾單位
         //  myView.leftAxis.valueFormatter = DefaultAxisValueFormatter.init(formatter: leftFormatter)
        
        return myView
        
        
    }

    
    
}//28day

struct TotalHRall : UIViewRepresentable {
    
    
    let months = [String]()
    let 早餐 = [21, 24, 26, 23, 22, 26, 24, 28, 22, 24, 25, 24] //數字最小
    
    func makeUIView(context: Context) -> BarChartView {
        return setChart(dataPoints: months, values:早餐 )
    }
    
    func updateUIView(_ uiView: BarChartView, context: UIViewRepresentableContext<TotalHRall>)
    {
        
    }
    
    typealias UIViewType = BarChartView
    
    //Bar chart accepts data as array of BarChartDataEntry objects
    var myView = BarChartView()
  
    func setChart(dataPoints: [String], values: [Int]) -> BarChartView {
        
        //若沒有資料，顯示的文字
        myView.noDataText = "You need to provide data for the chart."
        
        //存放資料的陣列，型別是BarChartDataEntry.
        
       
        
        //迴圈，來載入每筆資料內容
        var set次數: [BarChartDataEntry] = []
        
        //迴圈，來載入每筆資料內容
        let w = re.Total_HR(uid: "Biggg", choose: "all", StartTime: "", EndTime: "")
        let i = w.count
        var 次數 = [Int]()
       
        var 分類 = [String]()
        var k = 0
        let xAxis = myView.xAxis
        let yAxis = myView.leftAxis
        for _ in k...i{
            if(k>=i)
            {
                break;
            }
            else{
                let data_BP1 = String(w[k]!)
                let first:CharacterSet = [",",","];
                let first2 = data_BP1.components(separatedBy: first)
                次數.append(first2[1].toInt()!)
              
                let data次數 = BarChartDataEntry(x: Double(k), y: Double(次數[k]))
            
                set次數.append(data次數)
            
                分類.append(first2[0])
                myView.xAxis.valueFormatter = IndexAxisValueFormatter(values: 分類)
                myView.xAxis.granularity = 1
                k+=1
            }
            
        }
        //顯示的資料之內容與名稱（左下角所顯示的）
        let chartData次數 = BarChartDataSet(entries: set次數, label: "血壓狀況")
   
        //把dataSet轉換成可顯示的BarChartData
        let chartData = BarChartData(dataSets: [chartData次數])
        
        //指定剛剛連結的myView要顯示的資料為charData
        myView.data = chartData
        
        //改變chartDataSet的顏色
        chartData次數.colors = [UIColor(red: 198/255, green: 110/255, blue: 78/255, alpha: 1)]
      
        myView.data?.setValueFont(UIFont.systemFont(ofSize: 18))//文字字型
        myView.data?.setValueTextColor(UIColor.brown)  //文字顏色
        
        //標籤換到下方
        myView.xAxis.labelPosition = .bottom
        
        //改變barChartView的背景顏色
        // myView.backgroundColor = UIColor(red:0/255, green: 0/255, blue: 0/255, alpha: 1)
        
        //一個一個延遲顯現的特效
       // myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
        
        //彈一下特效
     //myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0, easingOption: .easeInBounce)
        
        //設立界線

        
        
        //設定X軸文字
        
        xAxis.labelTextColor = UIColor.brown //label文字顏色
        //xAxis.axisLineColor = UIColor.black  // 設定X軸顏色
       // xAxis.drawGridLinesEnabled = false  // 隱藏隔線
        xAxis.labelPosition = .bottom       // 設定文字位置
       // xAxis.spaceMin = 1.5                // X軸左邊間隔距離
     //   xAxis.spaceMax = 1.5                // X軸右邊間隔距離
        xAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        myView.doubleTapToZoomEnabled = false   //取消雙擊縮放
        myView.dragEnabled = true  //啟用拖拽圖表
        myView.dragDecelerationEnabled = false  //拖拽後是否有慣性效果
        myView.dragDecelerationFrictionCoef = 0 //拖拽後慣性效果的摩擦係數(0~1)，數值越小，慣性越不明顯
     
        //設定y軸文字
        myView.rightAxis.enabled = false
        yAxis.drawZeroLineEnabled = true   //從0開始繪製
        yAxis.axisLineColor =  UIColor.black  //Y軸顏色
        
        yAxis.axisMaximum = 50
        yAxis.axisMinimum = 0
        
        //設定Y軸上標籤的樣式
        yAxis.labelPosition = .outsideChart   //label位置
        yAxis.labelTextColor = UIColor.brown   //文字顏色
        yAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        //設定Y軸上標籤顯示數字的格式
         //   let  leftFormatter = NumberFormatter()  //自定義格式
         // leftFormatter.positiveSuffix = "kacl"  //數字字尾單位
         //  myView.leftAxis.valueFormatter = DefaultAxisValueFormatter.init(formatter: leftFormatter)
        
        return myView
        
        
    }

    
    
}//all
//

struct TotalSpO2_7 : UIViewRepresentable {
    
    
    let months = [String]()
    let 早餐 = [21, 24, 26, 23, 22, 26, 24, 28, 22, 24, 25, 24] //數字最小
    
    func makeUIView(context: Context) -> BarChartView {
        return setChart(dataPoints: months, values:早餐 )
    }
    
    func updateUIView(_ uiView: BarChartView, context: UIViewRepresentableContext<TotalSpO2_7>)
    {
        
    }
    
    typealias UIViewType = BarChartView
    
    //Bar chart accepts data as array of BarChartDataEntry objects
    var myView = BarChartView()
  
    func setChart(dataPoints: [String], values: [Int]) -> BarChartView {
        
        //若沒有資料，顯示的文字
        myView.noDataText = "You need to provide data for the chart."
        
        //存放資料的陣列，型別是BarChartDataEntry.
        
       
        
        //迴圈，來載入每筆資料內容
        var set次數: [BarChartDataEntry] = []
        
        //迴圈，來載入每筆資料內容
        let w = re.Total_SpO2(uid: "Biggg", choose: "7day", StartTime: "", EndTime: "")
        let i = w.count
        var 次數 = [Int]()
       
        var 分類 = [String]()
        var k = 0
        let xAxis = myView.xAxis
        let yAxis = myView.leftAxis
        for _ in k...i{
            if(k>=i)
            {
                break;
            }
            else{
                let data_BP1 = String(w[k]!)
                let first:CharacterSet = [",",","];
                let first2 = data_BP1.components(separatedBy: first)
                次數.append(first2[1].toInt()!)
              
                let data次數 = BarChartDataEntry(x: Double(k), y: Double(次數[k]))
            
                set次數.append(data次數)
            
                分類.append(first2[0])
                myView.xAxis.valueFormatter = IndexAxisValueFormatter(values: 分類)
                myView.xAxis.granularity = 1
                k+=1
            }
            
        }
        //顯示的資料之內容與名稱（左下角所顯示的）
        let chartData次數 = BarChartDataSet(entries: set次數, label: "血壓狀況")
   
        //把dataSet轉換成可顯示的BarChartData
        let chartData = BarChartData(dataSets: [chartData次數])
        
        //指定剛剛連結的myView要顯示的資料為charData
        myView.data = chartData
        
        //改變chartDataSet的顏色
        chartData次數.colors = [UIColor(red: 192/255, green: 88/255, blue: 88/255, alpha: 1)]
      
        myView.data?.setValueFont(UIFont.systemFont(ofSize: 18))//文字字型
        myView.data?.setValueTextColor(UIColor.brown)  //文字顏色
        
        //標籤換到下方
        myView.xAxis.labelPosition = .bottom
        
        //改變barChartView的背景顏色
        // myView.backgroundColor = UIColor(red:0/255, green: 0/255, blue: 0/255, alpha: 1)
        
        //一個一個延遲顯現的特效
       // myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
        
        //彈一下特效
     //myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0, easingOption: .easeInBounce)
        
        //設立界線

        
        
        //設定X軸文字
        
        xAxis.labelTextColor = UIColor.brown //label文字顏色
        //xAxis.axisLineColor = UIColor.black  // 設定X軸顏色
       // xAxis.drawGridLinesEnabled = false  // 隱藏隔線
        xAxis.labelPosition = .bottom       // 設定文字位置
       // xAxis.spaceMin = 1.5                // X軸左邊間隔距離
     //   xAxis.spaceMax = 1.5                // X軸右邊間隔距離
        xAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        myView.doubleTapToZoomEnabled = false   //取消雙擊縮放
        myView.dragEnabled = true  //啟用拖拽圖表
        myView.dragDecelerationEnabled = false  //拖拽後是否有慣性效果
        myView.dragDecelerationFrictionCoef = 0 //拖拽後慣性效果的摩擦係數(0~1)，數值越小，慣性越不明顯
     
        //設定y軸文字
        myView.rightAxis.enabled = false
        yAxis.drawZeroLineEnabled = true   //從0開始繪製
        yAxis.axisLineColor =  UIColor.black  //Y軸顏色
        
        yAxis.axisMaximum = 10
        yAxis.axisMinimum = 0
        
        //設定Y軸上標籤的樣式
        yAxis.labelPosition = .outsideChart   //label位置
        yAxis.labelTextColor = UIColor.brown   //文字顏色
        yAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        //設定Y軸上標籤顯示數字的格式
         //   let  leftFormatter = NumberFormatter()  //自定義格式
         // leftFormatter.positiveSuffix = "kacl"  //數字字尾單位
         //  myView.leftAxis.valueFormatter = DefaultAxisValueFormatter.init(formatter: leftFormatter)
        
        return myView
        
        
    }

    
    
}//7day

struct TotalSpO2_28 : UIViewRepresentable {
    
    
    let months = [String]()
    let 早餐 = [21, 24, 26, 23, 22, 26, 24, 28, 22, 24, 25, 24] //數字最小
    
    func makeUIView(context: Context) -> BarChartView {
        return setChart(dataPoints: months, values:早餐 )
    }
    func updateUIView(_ uiView: BarChartView, context: UIViewRepresentableContext<TotalSpO2_28>)
    { }
    
    typealias UIViewType = BarChartView
    var myView = BarChartView()
  
    func setChart(dataPoints: [String], values: [Int]) -> BarChartView {
        
        //若沒有資料，顯示的文字
        myView.noDataText = "You need to provide data for the chart."
        
        //存放資料的陣列，型別是BarChartDataEntry.
        
        //迴圈，來載入每筆資料內容
        var set次數: [BarChartDataEntry] = []
        
        //迴圈，來載入每筆資料內容
        let w = re.Total_SpO2(uid: "Biggg", choose: "28day", StartTime: "", EndTime: "")
        let i = w.count
        var 次數 = [Int]()
        var 分類 = [String]()
        var k = 0
        let xAxis = myView.xAxis
        let yAxis = myView.leftAxis
        for _ in k...i{
            if(k>=i)
            {
                break;
            }
            else{
                let data_BP1 = String(w[k]!)
                let first:CharacterSet = [",",","];
                let first2 = data_BP1.components(separatedBy: first)
                次數.append(first2[1].toInt()!)
              
                let data次數 = BarChartDataEntry(x: Double(k), y: Double(次數[k]))
            
                set次數.append(data次數)
            
                分類.append(first2[0])
                myView.xAxis.valueFormatter = IndexAxisValueFormatter(values: 分類)
                myView.xAxis.granularity = 1
                k+=1
            }
            
        }
        //顯示的資料之內容與名稱（左下角所顯示的）
        let chartData次數 = BarChartDataSet(entries: set次數, label: "血壓狀況")
        //把dataSet轉換成可顯示的BarChartData
        let chartData = BarChartData(dataSets: [chartData次數])
        //指定剛剛連結的myView要顯示的資料為charData
        myView.data = chartData
        //改變chartDataSet的顏色
        chartData次數.colors = [UIColor(red: 192/255, green: 88/255, blue: 88/255, alpha: 1)]
      
        myView.data?.setValueFont(UIFont.systemFont(ofSize: 18))//文字字型
        myView.data?.setValueTextColor(UIColor.brown)  //文字顏色
        
        //標籤換到下方
        myView.xAxis.labelPosition = .bottom
        
        //改變barChartView的背景顏色
        // myView.backgroundColor = UIColor(red:0/255, green: 0/255, blue: 0/255, alpha: 1)
        
        //一個一個延遲顯現的特效
       // myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
        
        //彈一下特效
        //myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0, easingOption: .easeInBounce)
        
        //設立界線

        //設定X軸文字
        
        xAxis.labelTextColor = UIColor.brown //label文字顏色
        //xAxis.axisLineColor = UIColor.black  // 設定X軸顏色
       // xAxis.drawGridLinesEnabled = false  // 隱藏隔線
        xAxis.labelPosition = .bottom       // 設定文字位置
       // xAxis.spaceMin = 1.5                // X軸左邊間隔距離
      //  xAxis.spaceMax = 1.5                // X軸右邊間隔距離
        xAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        myView.doubleTapToZoomEnabled = false   //取消雙擊縮放
        myView.dragEnabled = true  //啟用拖拽圖表
        myView.dragDecelerationEnabled = false  //拖拽後是否有慣性效果
        myView.dragDecelerationFrictionCoef = 0 //拖拽後慣性效果的摩擦係數(0~1)，數值越小，慣性越不明顯
     
        //設定y軸文字
        myView.rightAxis.enabled = false
        yAxis.drawZeroLineEnabled = true   //從0開始繪製
        yAxis.axisLineColor =  UIColor.black  //Y軸顏色
        
        yAxis.axisMaximum = 30
        yAxis.axisMinimum = 0
        
        //設定Y軸上標籤的樣式
        yAxis.labelPosition = .outsideChart   //label位置
        yAxis.labelTextColor = UIColor.brown   //文字顏色
        yAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        //設定Y軸上標籤顯示數字的格式
         //   let  leftFormatter = NumberFormatter()  //自定義格式
         // leftFormatter.positiveSuffix = "kacl"  //數字字尾單位
         //  myView.leftAxis.valueFormatter = DefaultAxisValueFormatter.init(formatter: leftFormatter)
        return myView
        
    }

    
    
}//28day

struct TotalSpO2_all : UIViewRepresentable {
    
    
    let months = [String]()
    let 早餐 = [21, 24, 26, 23, 22, 26, 24, 28, 22, 24, 25, 24] //數字最小
    
    func makeUIView(context: Context) -> BarChartView {
        return setChart(dataPoints: months, values:早餐 )
    }
    
    func updateUIView(_ uiView: BarChartView, context: UIViewRepresentableContext<TotalSpO2_all>)
    {
        
    }
    
    typealias UIViewType = BarChartView
    
    //Bar chart accepts data as array of BarChartDataEntry objects
    var myView = BarChartView()
  
    func setChart(dataPoints: [String], values: [Int]) -> BarChartView {
        
        //若沒有資料，顯示的文字
        myView.noDataText = "You need to provide data for the chart."
        
        //存放資料的陣列，型別是BarChartDataEntry.
        
       
        
        //迴圈，來載入每筆資料內容
        var set次數: [BarChartDataEntry] = []
        
        //迴圈，來載入每筆資料內容
        let w = re.Total_SpO2(uid: "Biggg", choose: "all", StartTime: "", EndTime: "")
        let i = w.count
        var 次數 = [Int]()
       
        var 分類 = [String]()
        var k = 0
        let xAxis = myView.xAxis
        let yAxis = myView.leftAxis
        for _ in k...i{
            if(k>=i)
            {
                break;
            }
            else{
                let data_BP1 = String(w[k]!)
                let first:CharacterSet = [",",","];
                let first2 = data_BP1.components(separatedBy: first)
                次數.append(first2[1].toInt()!)
              
                let data次數 = BarChartDataEntry(x: Double(k), y: Double(次數[k]))
            
                set次數.append(data次數)
            
                分類.append(first2[0])
                myView.xAxis.valueFormatter = IndexAxisValueFormatter(values: 分類)
                myView.xAxis.granularity = 1
                k+=1
            }
            
        }
        //顯示的資料之內容與名稱（左下角所顯示的）
        let chartData次數 = BarChartDataSet(entries: set次數, label: "血壓狀況")
   
        //把dataSet轉換成可顯示的BarChartData
        let chartData = BarChartData(dataSets: [chartData次數])
        
        //指定剛剛連結的myView要顯示的資料為charData
        myView.data = chartData
        
        //改變chartDataSet的顏色
        chartData次數.colors = [UIColor(red: 192/255, green: 88/255, blue: 88/255, alpha: 1)]
      
        myView.data?.setValueFont(UIFont.systemFont(ofSize: 18))//文字字型
        myView.data?.setValueTextColor(UIColor.brown)  //文字顏色
        
        //標籤換到下方
        myView.xAxis.labelPosition = .bottom
        
        //改變barChartView的背景顏色
        // myView.backgroundColor = UIColor(red:0/255, green: 0/255, blue: 0/255, alpha: 1)
        
        //一個一個延遲顯現的特效
       // myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
        
        //彈一下特效
     //myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0, easingOption: .easeInBounce)
        
        //設立界線

        
        
        //設定X軸文字
        
        xAxis.labelTextColor = UIColor.brown //label文字顏色
        //xAxis.axisLineColor = UIColor.black  // 設定X軸顏色
       // xAxis.drawGridLinesEnabled = false  // 隱藏隔線
        xAxis.labelPosition = .bottom       // 設定文字位置
       // xAxis.spaceMin = 1.5                // X軸左邊間隔距離
     //   xAxis.spaceMax = 1.5                // X軸右邊間隔距離
        xAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        myView.doubleTapToZoomEnabled = false   //取消雙擊縮放
        myView.dragEnabled = true  //啟用拖拽圖表
        myView.dragDecelerationEnabled = false  //拖拽後是否有慣性效果
        myView.dragDecelerationFrictionCoef = 0 //拖拽後慣性效果的摩擦係數(0~1)，數值越小，慣性越不明顯
     
        //設定y軸文字
        myView.rightAxis.enabled = false
        yAxis.drawZeroLineEnabled = true   //從0開始繪製
        yAxis.axisLineColor =  UIColor.black  //Y軸顏色
        
        yAxis.axisMaximum = 50
        yAxis.axisMinimum = 0
        
        //設定Y軸上標籤的樣式
        yAxis.labelPosition = .outsideChart   //label位置
        yAxis.labelTextColor = UIColor.brown   //文字顏色
        yAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        //設定Y軸上標籤顯示數字的格式
         //   let  leftFormatter = NumberFormatter()  //自定義格式
         // leftFormatter.positiveSuffix = "kacl"  //數字字尾單位
         //  myView.leftAxis.valueFormatter = DefaultAxisValueFormatter.init(formatter: leftFormatter)
        
        return myView
        
        
    }

    
    
}//all
//

struct TotalTemp_7 : UIViewRepresentable {
    
    
    let months = [String]()
    let 早餐 = [21, 24, 26, 23, 22, 26, 24, 28, 22, 24, 25, 24] //數字最小
    
    func makeUIView(context: Context) -> BarChartView {
        return setChart(dataPoints: months, values:早餐 )
    }
    
    func updateUIView(_ uiView: BarChartView, context: UIViewRepresentableContext<TotalTemp_7>)
    {
        
    }
    
    typealias UIViewType = BarChartView
    
    //Bar chart accepts data as array of BarChartDataEntry objects
    var myView = BarChartView()
  
    func setChart(dataPoints: [String], values: [Int]) -> BarChartView {
        
        //若沒有資料，顯示的文字
        myView.noDataText = "You need to provide data for the chart."
        
        //存放資料的陣列，型別是BarChartDataEntry.
        
       
        
        //迴圈，來載入每筆資料內容
        var set次數: [BarChartDataEntry] = []
        
        //迴圈，來載入每筆資料內容
        let w = re.Total_Temp(uid: "Biggg", choose: "7day", StartTime: "", EndTime: "")
        let i = w.count
        var 次數 = [Int]()
       
        var 分類 = [String]()
        var k = 0
        let xAxis = myView.xAxis
        let yAxis = myView.leftAxis
        for _ in k...i{
            if(k>=i)
            {
                break;
            }
            else{
                let data_BP1 = String(w[k]!)
                let first:CharacterSet = [",",","];
                let first2 = data_BP1.components(separatedBy: first)
                次數.append(first2[1].toInt()!)
              
                let data次數 = BarChartDataEntry(x: Double(k), y: Double(次數[k]))
            
                set次數.append(data次數)
            
                分類.append(first2[0])
                myView.xAxis.valueFormatter = IndexAxisValueFormatter(values: 分類)
                myView.xAxis.granularity = 1
                k+=1
            }
            
        }
        //顯示的資料之內容與名稱（左下角所顯示的）
        let chartData次數 = BarChartDataSet(entries: set次數, label: "血壓狀況")
   
        //把dataSet轉換成可顯示的BarChartData
        let chartData = BarChartData(dataSets: [chartData次數])
        
        //指定剛剛連結的myView要顯示的資料為charData
        myView.data = chartData
        
        //改變chartDataSet的顏色
        chartData次數.colors = [UIColor(red: 124/255, green: 94/255, blue: 141/255, alpha: 1)]
      
        myView.data?.setValueFont(UIFont.systemFont(ofSize: 18))//文字字型
        myView.data?.setValueTextColor(UIColor.brown)  //文字顏色
        
        //標籤換到下方
        myView.xAxis.labelPosition = .bottom
        
        //改變barChartView的背景顏色
        // myView.backgroundColor = UIColor(red:0/255, green: 0/255, blue: 0/255, alpha: 1)
        
        //一個一個延遲顯現的特效
       // myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
        
        //彈一下特效
     //myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0, easingOption: .easeInBounce)
        
        //設立界線

        
        
        //設定X軸文字
        
        xAxis.labelTextColor = UIColor.brown //label文字顏色
        //xAxis.axisLineColor = UIColor.black  // 設定X軸顏色
       // xAxis.drawGridLinesEnabled = false  // 隱藏隔線
        xAxis.labelPosition = .bottom       // 設定文字位置
       // xAxis.spaceMin = 1.5                // X軸左邊間隔距離
     //   xAxis.spaceMax = 1.5                // X軸右邊間隔距離
        xAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        myView.doubleTapToZoomEnabled = false   //取消雙擊縮放
        myView.dragEnabled = true  //啟用拖拽圖表
        myView.dragDecelerationEnabled = false  //拖拽後是否有慣性效果
        myView.dragDecelerationFrictionCoef = 0 //拖拽後慣性效果的摩擦係數(0~1)，數值越小，慣性越不明顯
     
        //設定y軸文字
        myView.rightAxis.enabled = false
        yAxis.drawZeroLineEnabled = true   //從0開始繪製
        yAxis.axisLineColor =  UIColor.black  //Y軸顏色
        
        yAxis.axisMaximum = 10
        yAxis.axisMinimum = 0
        
        //設定Y軸上標籤的樣式
        yAxis.labelPosition = .outsideChart   //label位置
        yAxis.labelTextColor = UIColor.brown   //文字顏色
        yAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        //設定Y軸上標籤顯示數字的格式
         //   let  leftFormatter = NumberFormatter()  //自定義格式
         // leftFormatter.positiveSuffix = "kacl"  //數字字尾單位
         //  myView.leftAxis.valueFormatter = DefaultAxisValueFormatter.init(formatter: leftFormatter)
        
        return myView
        
        
    }

    
    
}//7day

struct TotalTemp_28 : UIViewRepresentable {
    
    
    let months = [String]()
    let 早餐 = [21, 24, 26, 23, 22, 26, 24, 28, 22, 24, 25, 24] //數字最小
    
    func makeUIView(context: Context) -> BarChartView {
        return setChart(dataPoints: months, values:早餐 )
    }
    
    func updateUIView(_ uiView: BarChartView, context: UIViewRepresentableContext<TotalTemp_28>)
    {
        
    }
    
    typealias UIViewType = BarChartView
    
    //Bar chart accepts data as array of BarChartDataEntry objects
    var myView = BarChartView()
  
    func setChart(dataPoints: [String], values: [Int]) -> BarChartView {
        
        //若沒有資料，顯示的文字
        myView.noDataText = "You need to provide data for the chart."
        
        //存放資料的陣列，型別是BarChartDataEntry.
        
       
        
        //迴圈，來載入每筆資料內容
        var set次數: [BarChartDataEntry] = []
        
        //迴圈，來載入每筆資料內容
        let w = re.Total_Temp(uid: "Biggg", choose: "28day", StartTime: "", EndTime: "")
        let i = w.count
        var 次數 = [Int]()
       
        var 分類 = [String]()
        var k = 0
        let xAxis = myView.xAxis
        let yAxis = myView.leftAxis
        for _ in k...i{
            if(k>=i)
            {
                break;
            }
            else{
                let data_BP1 = String(w[k]!)
                let first:CharacterSet = [",",","];
                let first2 = data_BP1.components(separatedBy: first)
                次數.append(first2[1].toInt()!)
              
                let data次數 = BarChartDataEntry(x: Double(k), y: Double(次數[k]))
            
                set次數.append(data次數)
            
                分類.append(first2[0])
                myView.xAxis.valueFormatter = IndexAxisValueFormatter(values: 分類)
                myView.xAxis.granularity = 1
                k+=1
            }
            
        }
        //顯示的資料之內容與名稱（左下角所顯示的）
        let chartData次數 = BarChartDataSet(entries: set次數, label: "血壓狀況")
   
        //把dataSet轉換成可顯示的BarChartData
        let chartData = BarChartData(dataSets: [chartData次數])
        
        //指定剛剛連結的myView要顯示的資料為charData
        myView.data = chartData
        
        //改變chartDataSet的顏色
        chartData次數.colors = [UIColor(red: 124/255, green: 94/255, blue: 141/255, alpha: 1)]
      
        myView.data?.setValueFont(UIFont.systemFont(ofSize: 18))//文字字型
        myView.data?.setValueTextColor(UIColor.brown)  //文字顏色
        
        //標籤換到下方
        myView.xAxis.labelPosition = .bottom
        
        //改變barChartView的背景顏色
        // myView.backgroundColor = UIColor(red:0/255, green: 0/255, blue: 0/255, alpha: 1)
        
        //一個一個延遲顯現的特效
       // myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
        
        //彈一下特效
     //myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0, easingOption: .easeInBounce)
        
        //設立界線

        
        
        //設定X軸文字
        
        xAxis.labelTextColor = UIColor.brown //label文字顏色
        //xAxis.axisLineColor = UIColor.black  // 設定X軸顏色
       // xAxis.drawGridLinesEnabled = false  // 隱藏隔線
        xAxis.labelPosition = .bottom       // 設定文字位置
       // xAxis.spaceMin = 1.5                // X軸左邊間隔距離
     //   xAxis.spaceMax = 1.5                // X軸右邊間隔距離
        xAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        myView.doubleTapToZoomEnabled = false   //取消雙擊縮放
        myView.dragEnabled = true  //啟用拖拽圖表
        myView.dragDecelerationEnabled = false  //拖拽後是否有慣性效果
        myView.dragDecelerationFrictionCoef = 0 //拖拽後慣性效果的摩擦係數(0~1)，數值越小，慣性越不明顯
     
        //設定y軸文字
        myView.rightAxis.enabled = false
        yAxis.drawZeroLineEnabled = true   //從0開始繪製
        yAxis.axisLineColor =  UIColor.black  //Y軸顏色
        
        yAxis.axisMaximum = 30
        yAxis.axisMinimum = 0
        
        //設定Y軸上標籤的樣式
        yAxis.labelPosition = .outsideChart   //label位置
        yAxis.labelTextColor = UIColor.brown   //文字顏色
        yAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        //設定Y軸上標籤顯示數字的格式
         //   let  leftFormatter = NumberFormatter()  //自定義格式
         // leftFormatter.positiveSuffix = "kacl"  //數字字尾單位
         //  myView.leftAxis.valueFormatter = DefaultAxisValueFormatter.init(formatter: leftFormatter)
        
        return myView
        
        
    }

    
    
}//28day

struct TotalTemp_all : UIViewRepresentable {
    
    
    let months = [String]()
    let 早餐 = [21, 24, 26, 23, 22, 26, 24, 28, 22, 24, 25, 24] //數字最小
    
    func makeUIView(context: Context) -> BarChartView {
        return setChart(dataPoints: months, values:早餐 )
    }
    
    func updateUIView(_ uiView: BarChartView, context: UIViewRepresentableContext<TotalTemp_all>)
    {
        
    }
    
    typealias UIViewType = BarChartView
    
    //Bar chart accepts data as array of BarChartDataEntry objects
    var myView = BarChartView()
  
    func setChart(dataPoints: [String], values: [Int]) -> BarChartView {
        
        //若沒有資料，顯示的文字
        myView.noDataText = "You need to provide data for the chart."
        
        //存放資料的陣列，型別是BarChartDataEntry.
        
       
        
        //迴圈，來載入每筆資料內容
        var set次數: [BarChartDataEntry] = []
        
        //迴圈，來載入每筆資料內容
        let w = re.Total_Temp(uid: "Biggg", choose: "all", StartTime: "", EndTime: "")
        let i = w.count
        var 次數 = [Int]()
       
        var 分類 = [String]()
        var k = 0
        let xAxis = myView.xAxis
        let yAxis = myView.leftAxis
        for _ in k...i{
            if(k>=i)
            {
                break;
            }
            else{
                let data_BP1 = String(w[k]!)
                let first:CharacterSet = [",",","];
                let first2 = data_BP1.components(separatedBy: first)
                次數.append(first2[1].toInt()!)
              
                let data次數 = BarChartDataEntry(x: Double(k), y: Double(次數[k]))
            
                set次數.append(data次數)
            
                分類.append(first2[0])
                myView.xAxis.valueFormatter = IndexAxisValueFormatter(values: 分類)
                myView.xAxis.granularity = 1
                k+=1
            }
            
        }
        //顯示的資料之內容與名稱（左下角所顯示的）
        let chartData次數 = BarChartDataSet(entries: set次數, label: "血壓狀況")
   
        //把dataSet轉換成可顯示的BarChartData
        let chartData = BarChartData(dataSets: [chartData次數])
        
        //指定剛剛連結的myView要顯示的資料為charData
        myView.data = chartData
        
        //改變chartDataSet的顏色
        chartData次數.colors = [UIColor(red: 124/255, green: 94/255, blue: 141/255, alpha: 1)]
      
        myView.data?.setValueFont(UIFont.systemFont(ofSize: 18))//文字字型
        myView.data?.setValueTextColor(UIColor.brown)  //文字顏色
        
        //標籤換到下方
        myView.xAxis.labelPosition = .bottom
        
        //改變barChartView的背景顏色
        // myView.backgroundColor = UIColor(red:0/255, green: 0/255, blue: 0/255, alpha: 1)
        
        //一個一個延遲顯現的特效
       // myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
        
        //彈一下特效
     //myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0, easingOption: .easeInBounce)
        
        //設立界線

        
        
        //設定X軸文字
        
        xAxis.labelTextColor = UIColor.brown //label文字顏色
        //xAxis.axisLineColor = UIColor.black  // 設定X軸顏色
       // xAxis.drawGridLinesEnabled = false  // 隱藏隔線
        xAxis.labelPosition = .bottom       // 設定文字位置
       // xAxis.spaceMin = 1.5                // X軸左邊間隔距離
     //   xAxis.spaceMax = 1.5                // X軸右邊間隔距離
        xAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        myView.doubleTapToZoomEnabled = false   //取消雙擊縮放
        myView.dragEnabled = true  //啟用拖拽圖表
        myView.dragDecelerationEnabled = false  //拖拽後是否有慣性效果
        myView.dragDecelerationFrictionCoef = 0 //拖拽後慣性效果的摩擦係數(0~1)，數值越小，慣性越不明顯
     
        //設定y軸文字
        myView.rightAxis.enabled = false
        yAxis.drawZeroLineEnabled = true   //從0開始繪製
        yAxis.axisLineColor =  UIColor.black  //Y軸顏色
        
        yAxis.axisMaximum = 50
        yAxis.axisMinimum = 0
        
        //設定Y軸上標籤的樣式
        yAxis.labelPosition = .outsideChart   //label位置
        yAxis.labelTextColor = UIColor.brown   //文字顏色
        yAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        //設定Y軸上標籤顯示數字的格式
         //   let  leftFormatter = NumberFormatter()  //自定義格式
         // leftFormatter.positiveSuffix = "kacl"  //數字字尾單位
         //  myView.leftAxis.valueFormatter = DefaultAxisValueFormatter.init(formatter: leftFormatter)
        
        return myView
        
        
    }

    
    
}//all
