//
//  SettingVIew.swift
//  icansee
//
//  Created by WenLi Lee on 2020/11/15.
//

import SwiftUI
import Combine

struct SettingVIew: View {
    @Binding var user : String
    @ObservedObject var setting = settings_()
    @State private var showSheet: Bool = false
    @State private var showImagePicker: Bool = false
    @State private var sourceType: UIImagePickerController.SourceType = .camera
    @State private var image: UIImage?
    
    var body: some View {
        VStack{
            VStack(alignment:.leading){
                Spacer()
                 Image(uiImage: image ?? UIImage(named: "p1")!)
                     .resizable()
                     .clipShape(Circle())
                     .shadow(radius: 20)
                    .frame(width: 150, height: 150)
                }
            VStack(alignment: .center){
                  Text("\(user)")
                         .bold()
                         .font(.title)
                    .foregroundColor(Color.black)
                 Button("編輯個人圖像") {
                     self.showSheet = true
                 }.foregroundColor(.blue)
                 .padding()
                     .actionSheet(isPresented: $showSheet) {
                         ActionSheet(title: Text("Select Photo"), message: Text("Choose"), buttons: [
                             .default(Text("Photo Library")) {
                                 self.showImagePicker = true
                                 self.sourceType = .photoLibrary
                             },
                             .default(Text("Camera")) {
                                 self.showImagePicker = true
                                 self.sourceType = .camera
                             },
                             .cancel()
                         ])
                   }
                }
                
                VStack(alignment: .center){
                       Account()
                    }
                    
               
        }.navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
        .background(Color.white.edgesIgnoringSafeArea(.all))
        .sheet(isPresented: $showImagePicker) {
            pickerimage(image: self.$image, isShown: self.$showImagePicker, sourceType: self.sourceType)
          }
    
    }
}
   
         
    

struct Account : View {
    @State  var isActive: Bool = false
    @State  var isActive2: Bool = false
    @State  var isActive3: Bool = false
    var body : some View{
        NavigationLink(destination: EditMy() , isActive: self.$isActive) {
            Text("")
        }
        NavigationLink(destination: Emergency() , isActive: self.$isActive2) {
            Text("")
        }
        NavigationLink(destination: Notice() , isActive: self.$isActive3) {
            Text("")
        }
        VStack(spacing: 10){
            
            Color.white.edgesIgnoringSafeArea(.all)
            Button(action: {
                self.isActive = true
            }) {
                
                HStack(spacing: 15){
                    
                    Image("my")
                        .renderingMode(.original)
                        .padding()
                        .background(Color("Color1"))
                        .clipShape(Circle())
                    
                    Text("修改個人資料")
                    
                    Spacer()
                    
                    Image("arrow").renderingMode(.original)
                    
                }.padding()
                .background(Color.white)
                .foregroundColor(.black)
                
            }.cornerRadius(15)
            .padding(.top)
            
            Button(action: {
                self.isActive2 = true
            }) {
                
                HStack(spacing: 15){
                    
                    Image("emergency")
                        .renderingMode(.original)
                        .padding()
                        .background(Color("Color1"))
                        .clipShape(Circle())
                    
                    Text("設定緊急聯絡人")
                    
                    Spacer()
                    
                    Image("arrow").renderingMode(.original)
                    
                }.padding()
                .background(Color.white)
                .foregroundColor(.black)
                
            }.cornerRadius(15)
            
            Button(action: {
                self.isActive3 = true
            }) {
                
                HStack(spacing: 15){
                    
                    Image("notice")
                        .renderingMode(.original)
                        .padding()
                        .background(Color("Color1"))
                        .clipShape(Circle())
                    
                    Text("推播設定")
                    
                    Spacer()
                    
                    Image("arrow").renderingMode(.original)
                    
                }.padding()
                .background(Color.white)
                .foregroundColor(.black)
                
            }.cornerRadius(15)
            
            Spacer()
            
        }.padding()
        .padding(.bottom,120)
    }
}
struct SettingVIew_Previews: PreviewProvider {
    static var previews: some View {
        SettingVIew(user: .constant(""))
    }
}

