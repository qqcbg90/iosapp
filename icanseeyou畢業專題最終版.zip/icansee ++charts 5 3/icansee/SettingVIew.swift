//
//  SettingVIew.swift
//  icansee
//
//  Created by WenLi Lee on 2020/11/15.
//

import SwiftUI
import Combine

struct SettingVIew: View {
    @Binding var user : String
    @ObservedObject var setting = settings_()
    @State private var showSheet: Bool = false
    @State private var showImagePicker: Bool = false
    @State private var sourceType: UIImagePickerController.SourceType = .camera
    @State private var image: UIImage?
    
    var body: some View {
        VStack(alignment: .center){
            Spacer()
            Image(uiImage: image ?? UIImage(named: "p1")!)
                .resizable()
                .scaledToFit()
                .clipShape(Circle())
                .shadow(radius: 20)
                .frame(width: 100, height: 100)
            Text("\(user)")
                .bold()
                .font(.title)
                .foregroundColor(Color.black)
            
            Button("編輯個人圖像") {
                self.showSheet = true
            }.foregroundColor(.blue)
            .actionSheet(isPresented: $showSheet) {
                ActionSheet(title: Text("Select Photo"), message: Text("Choose"), buttons: [
                    .default(Text("Photo Library")) {
                        self.showImagePicker = true
                        self.sourceType = .photoLibrary
                    },
                    .default(Text("Camera")) {
                        self.showImagePicker = true
                        self.sourceType = .camera
                    },
                    .cancel()
                ])
            }
            Account(user: .constant(user))
        }.navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
        .background(Color.white.edgesIgnoringSafeArea(.all))
        .sheet(isPresented: $showImagePicker) {
            pickerimage(image: self.$image, isShown: self.$showImagePicker, sourceType: self.sourceType)
        }
      
    }
 
    
}


struct Account : View {
    @State  var isActive: Bool = false
    @State  var isActive2: Bool = false
    @State  var isActive3: Bool = false
    @State  var isActive4: Bool = false
    
    
    @Binding var user : String
    
    
    var body : some View{
        NavigationLink(destination: EditMy(user: .constant(user)) , isActive: self.$isActive) {
            Text("")
        }
        NavigationLink(destination: Emergency(user: .constant(user)) , isActive: self.$isActive2) {
            Text("")
        }
        NavigationLink(destination: Notice(user: .constant(user)) , isActive: self.$isActive3) {
            Text("")
        }
        NavigationLink(destination: editcode(user: .constant(user)) , isActive: self.$isActive4) {
            Text("")
        }
        
        
        ZStack{
            Color.white.edgesIgnoringSafeArea(.all)
            VStack(alignment: .leading, spacing:10){
                HStack(alignment: .center, spacing:10){
                    Button(action: {
                        self.isActive = true
                    }) {
                        
                        Image("my")
                            .renderingMode(.original)
                            .padding()
                            .background(Color("Color1"))
                            .clipShape(Circle())
                        
                        Text("修改個人資料")
                        
                        Spacer()
                        
                        Image("arrow").renderingMode(.original)
                    }
                }.padding()
                .background(Color.white)
                .foregroundColor(.black)
                HStack(alignment: .center, spacing:10){
                    Button(action: {
                        self.isActive2 = true
                    }) {
                        
                        Image("emergency")
                            .renderingMode(.original)
                            .padding()
                            .background(Color("Color1"))
                            .clipShape(Circle())
                        
                        Text("設定緊急聯絡人")
                        
                        Spacer()
                        
                        Image("arrow").renderingMode(.original)
                    }
                }.padding()
                .background(Color.white)
                .foregroundColor(.black)
                HStack(alignment: .center, spacing:10){
                    Button(action: {
                        self.isActive4 = true
                    }) {
                        
                        Image("password")
                            .renderingMode(.original)
                            .padding()
                            .background(Color("Color1"))
                            .clipShape(Circle())
                        
                        Text("修改密碼")
                        
                        Spacer()
                        
                        Image("arrow").renderingMode(.original)
                    }
                }.padding()
                .background(Color.white)
                .foregroundColor(.black)
                HStack(alignment: .center, spacing:10){
                    Button(action: {
                        self.isActive3 = true
                    }) {
                        
                        Image("notice")
                            .renderingMode(.original)
                            .padding()
                            .background(Color("Color1"))
                            .clipShape(Circle())
                        
                        Text("推播設定")
                        
                        Spacer()
                        
                        Image("arrow").renderingMode(.original)
                    }
                }.padding()
                .background(Color.white)
                .foregroundColor(.black)

            }.cornerRadius(15)
            .padding(.top)
     
        }.padding(.bottom,100)
        
    }
}
struct SettingVIew_Previews: PreviewProvider {
    static var previews: some View {
        SettingVIew(user: .constant(""))
    }
}



