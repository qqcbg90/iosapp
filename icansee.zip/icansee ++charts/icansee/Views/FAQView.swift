//
//  FAQView.swift
//  LeftSlidingMenu-SwiftUI
//
//  Created by Hasan, MdAdit on 4/9/20.
//  Copyright © 2020 FirstAlert. All rights reserved.
//

import SwiftUI

struct FAQView: View {
    var body: some View {
        Text("FAQ") 
    }
}

struct FAQView_Previews: PreviewProvider {
    static var previews: some View {
        FAQView()
    }
}
