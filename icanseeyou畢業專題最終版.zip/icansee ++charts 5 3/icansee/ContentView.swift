//
//  ContentView.swift
//  icansee
//
//  Created by WenLi Lee on 2020/11/1.
//
import SwiftUI
import Foundation
import LocalAuthentication

extension UIApplication{
    func endEditing(){
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}//按空白處鍵盤收起

struct ContentView: View {//主畫面
    
    var body: some View {
        NavigationView{
            Home()//主畫面跳轉到Home()
                .edgesIgnoringSafeArea(.all)
                .statusBar(hidden: true)
        }
        .navigationBarHidden(true)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


struct Home : View {
    
    class TextLimiter: ObservableObject {
        private let limit: Int
        
        init(limit: Int) {
            self.limit = limit
        }
        
        @Published var hasReachedLimit = false
        @Published var value = "" {
            didSet {
                if value.count > self.limit {
                    value = String(value.prefix(self.limit))
                    self.hasReachedLimit = true
                } else {
                    self.hasReachedLimit = false
                }
            }
        }
    }//限制字數
    
    @ObservedObject var user = TextLimiter(limit: 10)
    @ObservedObject var pass = TextLimiter(limit: 10)
    @ObservedObject var phone = TextLimiter(limit: 10)
    @ObservedObject var uid = TextLimiter(limit: 10)
    @ObservedObject var height = TextLimiter(limit: 5)
    @ObservedObject var weight = TextLimiter(limit: 5)
    //
    @ObservedObject var bluetooth = settings_()//faceid
    //
    @State var a = ""
    @State var w1 = ""

    @State var  birth = Date()
    
    //
    @EnvironmentObject var obs : chatobser
    @State var BIR = ""
    @State var signUp = false
    @ObservedObject var N = settings_()
    @State var name = ""
    @State var sex = ""
    @State var email = ""
    @State var visible = false
    @State var showAlert = false//登入錯
    @State var showAlert2 = false//註冊錯
    var color = Color(red: 255/255, green: 148/255, blue: 101/255)
    @State private var isActive: Bool = false
    @State private var isActive2: Bool = false//登入畫面
    @State var BP = ""
    private  var formatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy/MM/dd"
        return formatter
        
    }()//設定日期的方法
    var alert: Alert {
        Alert(title: Text("登入失敗"), message: Text("請檢查帳號密碼是否輸入錯誤"), dismissButton: .cancel(Text("OK")))
    } //ＬＯＧＩＮ防呆
    
    //以上是設定變數！
    //MARK:-開始設計畫面(框架分為Zstack,Vstack,Htack)
    var body: some View{
  
        ZStack(alignment: Alignment(horizontal: .center, vertical: .center)){
            
            ZStack{
                
                ZStack(alignment: Alignment(horizontal: .trailing, vertical: .bottom)) {
                    
                    Color("Color1")
                        .clipShape(CShape())
                    
                    // adding another Curve...
                    
                    Path{path in
                        
                        // adding 40 for center...
                        
                        path.addArc(center: CGPoint(x: UIScreen.main.bounds.width - 120 , y: UIScreen.main.bounds.height - 50), radius: 40, startAngle: .zero, endAngle: .init(degrees: 180), clockwise: true)
                    }
                    .fill(Color.white)
                    
                    // adding Buttons...
                    
                    Button(action: {
                        
                        withAnimation(.easeIn){
                            
                            self.signUp = false
                        }
                        
                    }) {
                        
                        Image(systemName: signUp ? "xmark" : "person.fill")
                            .font(.system(size: 25, weight: .bold))
                            .foregroundColor(Color("Color1"))
                    }
                    .offset(x: -110, y: -50)
                    .disabled(signUp ? false : true)
                    
                    Button(action: {
                        
                        withAnimation(.easeOut){
                            
                            self.signUp = true
                        }
                        
                    }) {
                        
                        Image(systemName: signUp ? "person.badge.plus.fill" : "xmark")
                            .font(.system(size: signUp ? 26 : 25, weight: .bold))
                            .foregroundColor(.white)
                    }
                    .offset(x: -30, y: -40)
                    .disabled(signUp ? true : false)
                }
                // Moving View 切換登入＆註冊 ((用sigup是否等於true判斷
                
                
                //MARK:- 登入
                
                VStack(alignment: .leading, spacing: 25) {
                    Spacer(minLength: 20)
                    Text("Login")
                        .font(.system(size: 35, weight: .bold))
                        .foregroundColor(.white)
                    
                    Text("Username")
                        .foregroundColor(.white)
                        .padding(.top,10)
                    
                    VStack{
                        
                        TextField("Useraname", text: $user.value).keyboardType(.alphabet)
                        
                        Divider().background(Color.white.opacity(0.5))//底線
                    }
                    
                    Text("Password")
                        .foregroundColor(.white)
                        .padding(.top,10)
                    
                    VStack{
                        
                        if self.visible{
                            TextField("Paswword", text: $pass.value).autocapitalization(.none).keyboardType(.alphabet)
                            Divider().background(Color.white.opacity(0.5))//底線
                        }
                        else{
                            SecureField("Paswword", text: $pass.value).autocapitalization(.none)
                            Divider().background(Color.white.opacity(0.5))//底線
                        }
                    }
                    //password eyes
                    Button(action: {
                        self.visible.toggle()
                    }){
                        Image(systemName: self.visible ? "eye.fill" : "eye.slash.fill").foregroundColor(Color.white)
                    }
                    .padding()
                    .background(Color("Color1"))
                    .offset(x: 330, y: -80)
                    
                    HStack{
                        
                        Spacer()//空格(後面可加數字代表要空多少)
                        
                        NavigationLink(destination:TabBarView(user: .constant(user.value)) , isActive: self.$isActive) {Text("")}//頁面跳轉至TabBarView
                        NavigationLink(destination: ContentView() , isActive: self.$isActive2) {Text("")}//頁面跳轉至ContentView
                        
                        //MARK:- 登入webservice
                        Button(action: {
                            //face id----------------------------------------------
                            /*
                             if(bluetooth.bluetooth == true)
                             {
                             user="Biggg"
                             let context:LAContext = LAContext()
                             if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: nil)
                             {
                             context.evaluatePolicy(LAPolicy.deviceOwnerAuthenticationWithBiometrics, localizedReason: "Message") {(good, errpr) in
                             if good{
                             self.isActive = true
                             }
                             else
                             {
                             print("tryagain")
                             }
                             }
                             }
                             }*/
                            
                            //webservice----------------------------------------------
                            
                            let re = WebService();
                            let w1 = re.Login(userid: user.value, userpass: pass.value)
                            
                            if w1 == "1"
                            {
                                self.isActive = true
                            }
                            else if w1 == "0"
                            {
                                self.showAlert = true
                            }
                        })
                        {
                            Text("Login")
                                .fontWeight(.bold)
                                .foregroundColor(Color("Color1"))
                                .padding(.vertical)
                                .padding(.horizontal,45)
                                .background(Color.white)
                                .clipShape(Capsule())
                            
                        }
                        .alert(isPresented: $showAlert, content: { self.alert })
                        Spacer()
                    }
                    .padding(.top)
                    
                    Spacer(minLength: 0)
                }
                .padding(.top,(UIApplication.shared.windows.first?.safeAreaInsets.top)! + 25)//login字的位置
                .padding()
                
                
            }
            .offset(y: signUp ? -UIScreen.main.bounds.height + (UIScreen.main.bounds.height < 750 ? 100 : 200) : 0)
            .zIndex(1)
            // Moving View Front In Stack...
            
            
            
            
            //MARK:- 註冊
            
            VStack(alignment: .leading, spacing: 25) {
                Spacer(minLength: 20)
                Text("Sign Up")
                    .font(.system(size: 35, weight: .bold))
                    .foregroundColor(Color("Color1"))
                //可滑動的View
                ScrollView(.vertical, showsIndicators: false) {
                    
                    Group{
                        VStack(alignment: .leading, spacing: 10){
                            Text("帳號").foregroundColor(Color("Color1"))
                            TextField("帳號(5-10位英數字)", text: $user.value).keyboardType(.alphabet)
                            Divider().background(Color("Color1").opacity(0.5))//底線
                        }
                        
                        VStack(alignment: .leading, spacing: 10){
                            Text("密碼").foregroundColor(Color("Color1"))
                            if self.visible{
                                TextField("密碼(5-10位英數字)", text: $pass.value).autocapitalization(.none).keyboardType(.alphabet)
                                Divider().background(Color.white.opacity(0.5))//底線
                            }
                            else{
                                SecureField("密碼(5-10位英數字)", text: $pass.value).autocapitalization(.none)
                                Divider().background(Color.white.opacity(0.5))//底線
                            }
                        }
                        
                        //pssword eyes
                        Button(action: {
                            self.visible.toggle()
                        }){
                            Image(systemName: self.visible ? "eye.fill" : "eye.slash.fill").foregroundColor(Color.black)
                        }
                        .background(Color.white)
                        .offset(x: 170, y: -30)
                        
                        
                        VStack(alignment: .leading, spacing: 10){
                            Text("姓名").foregroundColor(Color("Color1"))
                            TextField("姓名", text: $name)
                            Divider().background(Color("Color1").opacity(0.5))
                        }
                        
                        
                        VStack(alignment: .leading, spacing: 10){
                            
                            DatePicker("生日", selection: $birth,in: ...Date(),displayedComponents: .date).foregroundColor(Color("Color1"))
                            Text("\(birth, formatter: formatter)")
                            
                            
                            //TextField(date, text: $BIR)
                            //.padding(.top,10)
                            
                            Divider().background(Color("Color1").opacity(0.5))
                        }
                    }
                    
                    VStack(alignment: .leading, spacing: 10){
                        Text("性別").foregroundColor(Color("Color1"))
                        RadioButtonGroups { selected in
                            print("Selected Gender is: \(selected)")
                            if(selected=="男"){
                                sex = "1"
                            }
                            else{
                                sex = "2"
                            }}
                        Divider().background(Color("Color1").opacity(0.5))
                    }
                    VStack(alignment: .leading, spacing: 10){
                        Text("身分證字號").foregroundColor(Color("Color1"))
                        TextField("身分證字號", text: $uid.value).keyboardType(.alphabet)
                        Divider().background(Color("Color1").opacity(0.5))
                    }
                    VStack(alignment: .leading, spacing: 10){
                        Text("手機電話").foregroundColor(Color("Color1"))
                        TextField("09xxxxxxxx", text: $phone.value).textContentType(.telephoneNumber)
                        Divider().background(Color("Color1").opacity(0.5))
                        
                    }
                    .keyboardType(.numberPad)
                    .onTapGesture {
                        UIApplication.shared.endEditing()
                    }//按空白處收起鍵盤
                    
                    VStack(alignment: .leading, spacing: 10){
                        Text("信箱").foregroundColor(Color("Color1"))
                        TextField("信箱", text: $email).textContentType(.emailAddress).keyboardType(.alphabet)
                        Divider().background(Color("Color1").opacity(0.5))
                    }
                    VStack(alignment: .leading, spacing: 10){
                        Text("身高").foregroundColor(Color("Color1"))
                        TextField("身高(不可以小於0)", text: $height.value)
                        Divider().background(Color("Color1").opacity(0.5))
                    }
                    .keyboardType(.decimalPad)
                    .onTapGesture {
                        UIApplication.shared.endEditing()
                    }
                    
                    VStack(alignment: .leading, spacing: 10){
                        Text("體重").foregroundColor(Color("Color1"))
                        TextField("體重(不可以小於0)", text: $weight.value)
                        Divider().background(Color("Color1").opacity(0.5))
                    }
                    .keyboardType(.decimalPad)
                    .onTapGesture {
                        UIApplication.shared.endEditing()
                    }
                    //MARK:- 註冊webservice
                    HStack{
                        Spacer()
                        Button(action: {
                            let date = formatter.string(from: birth)
                            let re = WebService();
                            w1 = re.SignUp2(newid: user.value, name: name, ID: uid.value, birth: date, sex: sex, newpass: pass.value, email: email, phone: phone.value, height: height.value, weight: weight.value)
                            if w1 == "註冊成功"
                            {
                                self.isActive2 = true
                            }
                            else
                            {
                                self.showAlert2 = true
                            }
                        }){
                            
                            Text("Sign Up")
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                                .padding(.vertical)
                                .padding(.horizontal,45)
                                .background(Color("Color1"))
                                .clipShape(Capsule())
                        }
                        .alert(isPresented: $showAlert2) { () -> Alert in
                            var title = ""
                            var message = ""
                            title = "註冊失敗"
                            message = w1
                            
                            return Alert(title: Text(title), message: Text(message), dismissButton: .cancel(Text("OK")))
                        }
                        Spacer()
                    }
                    .padding(.top)
                    
                }
                Spacer(minLength: 80)
            }
            .padding(.top,(UIApplication.shared.windows.first?.safeAreaInsets.top)! + 50)
            .padding()
        
        }
        .background(Color.white.edgesIgnoringSafeArea(.all))
        .preferredColorScheme(signUp ? .light : .dark)
    }
    
}


//MARK:- 頁面滑動特效方法func

struct CShape : Shape {
    
    func path(in rect: CGRect) -> Path {
        
        return Path{path in
            
            // starting from bottom...
            
            path.move(to: CGPoint(x: rect.width, y: rect.height - 50))
            path.addLine(to: CGPoint(x: rect.width, y: 0))
            path.addLine(to: CGPoint(x: 0, y: 0))
            path.addLine(to: CGPoint(x: 0, y: rect.height - 50))
            
            // adding curve...
            
            // total raidus of curve = 80
            path.addArc(center: CGPoint(x: rect.width - 40, y: rect.height - 50),
                        radius: 40, startAngle: .zero, endAngle: .init(degrees: 180), clockwise: false)
        }
    }
}
//MARK:- RadioButton
struct RadioButtonField: View {
    let id: String
    let label: String
    let size: CGFloat
    let color: Color
    let textSize: CGFloat
    let isMarked:Bool
    let callback: (String)->()
    
    init(
        id: String,
        label:String,
        size: CGFloat = 20,
        color: Color = Color.black,
        textSize: CGFloat = 14,
        isMarked: Bool = false,
        callback: @escaping (String)->()
    ) {
        self.id = id
        self.label = label
        self.size = size
        self.color = color
        self.textSize = textSize
        self.isMarked = isMarked
        self.callback = callback
    }
    var body: some View {
        Button(action:{
            self.callback(self.id)
        }) {
            HStack(alignment: .center, spacing: 10) {
                Image(systemName: self.isMarked ? "largecircle.fill.circle" : "circle")
                    .renderingMode(.original)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: self.size, height: self.size)
                Text(label)
                    .font(Font.system(size: textSize))
                Spacer()
            }.foregroundColor(self.color)
        }
        .foregroundColor(Color.white)
    }
}
//MARK:- Group of Radio Buttons
enum Gender: String {
    case male = "男"
    case female = "女"
}

struct RadioButtonGroups: View {
    let callback: (String) -> ()
    
    @State var selectedId: String = ""
    
    var body: some View {
        HStack {
            radioMaleMajority
            radioFemaleMajority
        }
    }
    
    var radioMaleMajority: some View {
        RadioButtonField(
            id: Gender.male.rawValue,
            label: Gender.male.rawValue,
            isMarked: selectedId == Gender.male.rawValue ? true : false,
            callback: radioGroupCallback
        )
    }
    
    var radioFemaleMajority: some View {
        RadioButtonField(
            id: Gender.female.rawValue,
            label: Gender.female.rawValue,
            isMarked: selectedId == Gender.female.rawValue ? true : false,
            callback: radioGroupCallback
        )
    }
    
    func radioGroupCallback(id: String) {
        selectedId = id
        callback(id)
    }
}




