//
//  CalRecord.swift
//  icansee
//
//  Created by WenLi Lee on 2020/11/15.
//

import SwiftUI
import Charts

struct CalRecord: View {
    
    var body: some View {
        NavigationView{
            
            calview() .navigationBarHidden(true)
                
                .background(Color("lightorang").ignoresSafeArea(.all, edges:.all))
        }
        
    }
}

struct CalRecord_Previews: PreviewProvider {
    static var previews: some View {
        CalRecord()
    }
}

struct calview: View{
    
    @State var tab = "7days"
    @Namespace var animation
    
    
    @State var edges = UIApplication.shared.windows.first?.safeAreaInsets
    
    var body: some View{
        
        VStack{
            
            
            HStack(spacing: 0){
                
                tabbutton(selected: $tab, title: "7days", animation: animation)
                
                tabbutton(selected: $tab, title: "28days", animation: animation)
            }
            .background(Color.white.opacity(0.08))
            .clipShape(Capsule())
            .padding(.horizontal)
            
            HStack(spacing: 20){
                if(tab == "7days"){
                    Bar()}
                else{
                    Bar_28()
                }
                
            }
            .frame(width: 400, height: 500, alignment: .center)
            
            // Or YOu can use Foreach Also...
            VStack(spacing: 20){
                
                HStack(spacing: 15){
                    
                }
                
                HStack(spacing: 15){
                    
                }
            }
            .padding(.horizontal)
            
            ZStack{
                
            }
            .padding(.top,20)
            
            Spacer()
        }
        
        .background(Color("lightorang").ignoresSafeArea(.all, edges:.bottom))
    }
    
}


struct Buttontab : View {
    @Binding var selected : String
    @State var title : String
    var animation : Namespace.ID
    
    var body: some View{
        
        Button(action: {
            
            withAnimation(.spring()){
                selected = title
                
                
                /*Divider()
                 HeartRecord();
                 heartRecord(title: Binding<String>.constant(""), selected: self.$selected)*/
                
            }
            
        }) {
            
            ZStack{
                
                // Capsule And Sliding Effect...
                
                Capsule()
                    .fill(Color.clear)
                    .frame(height: 45)
                
                if selected == title{
                    
                    Capsule()
                        .fill(Color.white)
                        .frame(height: 45)
                        // Mathced Geometry Effect...
                        .matchedGeometryEffect(id: "Tab", in: animation)
                }
                
                Text(title)
                    .foregroundColor(selected == title ? .black : .white)
                    .fontWeight(.bold)
            }
        }
    }
    
}


struct Bar : UIViewRepresentable {
    
    
    let months = [String]()
    let 早餐 = [21, 24, 26, 23, 22, 26, 24, 28, 22, 24, 25, 24] //數字最小
    let 午餐 = [32, 33, 34, 31, 32, 35, 36, 38, 30, 34, 35, 31]
    let 晚餐 = [88, 66, 44, 53, 77, 99, 55, 77, 88, 66, 49, 66]
    func makeUIView(context: Context) -> BarChartView {
        return setChart(dataPoints: months, values:早餐 )
    }
    
    func updateUIView(_ uiView: BarChartView, context: UIViewRepresentableContext<Bar>)
    {
        
    }
    
    typealias UIViewType = BarChartView
    
    //Bar chart accepts data as array of BarChartDataEntry objects
    var myView = BarChartView()
  
    func setChart(dataPoints: [String], values: [Int]) -> BarChartView {
        
        //若沒有資料，顯示的文字
        myView.noDataText = "You need to provide data for the chart."
        
        //存放資料的陣列，型別是BarChartDataEntry.
        
        var set早: [BarChartDataEntry] = []
        var set午 : [BarChartDataEntry] = [] //午餐
        var set晚 : [BarChartDataEntry] = [] //晚餐
        //迴圈，來載入每筆資料內容
        let wfood = re.Test_Food(uid: "Biggg", choose: "7day", Startday: "", Endday: "")
        let i = wfood.count
        var 早 = [Int]()
        var 午 = [Int]()
        var 晚 = [Int]()
        var 日期 = [String]()
        var k = 0
        let xAxis = myView.xAxis
        let yAxis = myView.leftAxis
        for _ in k...i{
            if(k>=i)
            {
                break;
            }
            else if(wfood[0]=="null")
            {
                早.append(0)
                午.append(0)
                晚.append(0)
                
                let data早 = BarChartDataEntry(x: Double(k), y: Double(早[k]))
                let data午 = BarChartDataEntry(x: Double(k), y: Double(午[k]))
                let data晚 = BarChartDataEntry(x: Double(k), y: Double(晚[k]))
                set早.append(data早)
                set午.append(data午)
                set晚.append(data晚)
                break;
            }
            else{
                let data_BP1 = String(wfood[k]!)
                let first:CharacterSet = ["：",","];
                let first2 = data_BP1.components(separatedBy: first)
                早.append(first2[1].toInt()!)
                午.append(first2[1].toInt()!+first2[3].toInt()!)
                晚.append(first2[1].toInt()!+first2[3].toInt()!+first2[5].toInt()!)
                
                
                let data早 = BarChartDataEntry(x: Double(k), y: Double(早[k]))
                let data午 = BarChartDataEntry(x: Double(k), y: Double(午[k]))
                let data晚 = BarChartDataEntry(x: Double(k), y: Double(晚[k]))
                set早.append(data早)
                set午.append(data午)
                set晚.append(data晚)
                日期.append(first2[9])
                myView.xAxis.valueFormatter = IndexAxisValueFormatter(values: 日期)
                myView.xAxis.granularity = 1
                k+=1
            }
            
        }
        //顯示的資料之內容與名稱（左下角所顯示的）
        let chartData早 = BarChartDataSet(entries: set早, label: "早餐")
        let chartData午 = BarChartDataSet(entries: set午, label: "午餐")
        let chartData晚 = BarChartDataSet(entries: set晚, label: "晚餐")
        //把dataSet轉換成可顯示的BarChartData
        let chartData = BarChartData(dataSets: [chartData晚,chartData午,chartData早])
        
        //指定剛剛連結的myView要顯示的資料為charData
        myView.data = chartData
        
        //改變chartDataSet的顏色
        chartData早.colors = [UIColor(red: 255/255, green: 226/255, blue: 164/255, alpha: 1)]
        chartData午.colors = [UIColor(red: 226/255, green: 137/255, blue: 108/255, alpha: 1)]
        chartData晚.colors = [UIColor(red: 12/255, green: 117/255, blue: 176/255, alpha: 1)]
        myView.data?.setValueFont(UIFont.systemFont(ofSize: 18))//文字字型
        myView.data?.setValueTextColor(UIColor.brown)  //文字顏色
      
        //改變chartDataSet為彩色
        //chartDataSet.colors = ChartColorTemplates.colorful()
        
        //標籤換到下方
        myView.xAxis.labelPosition = .bottom
        
        //改變barChartView的背景顏色
        // myView.backgroundColor = UIColor(red:0/255, green: 0/255, blue: 0/255, alpha: 1)
        
        //一個一個延遲顯現的特效
        //myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
        
        //彈一下特效
        //myView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0, easingOption: .easeInBounce)
        
        //設立界線
        let limit = ChartLimitLine(limit: 50.0, label: "Target")
        
        myView.rightAxis.addLimitLine(limit)
        
        
        //設定X軸文字
        
        xAxis.labelTextColor = UIColor.brown //label文字顏色
        //xAxis.axisLineColor = UIColor.black  // 設定X軸顏色
       // xAxis.drawGridLinesEnabled = false  // 隱藏隔線
        xAxis.labelPosition = .bottom       // 設定文字位置
       // xAxis.spaceMin = 1.5                // X軸左邊間隔距離
     //   xAxis.spaceMax = 1.5                // X軸右邊間隔距離
        xAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        myView.doubleTapToZoomEnabled = false   //取消雙擊縮放
        myView.dragEnabled = true  //啟用拖拽圖表
        myView.dragDecelerationEnabled = false  //拖拽後是否有慣性效果
        myView.dragDecelerationFrictionCoef = 0 //拖拽後慣性效果的摩擦係數(0~1)，數值越小，慣性越不明顯
     
        //設定y軸文字
        myView.rightAxis.enabled = false
        yAxis.drawZeroLineEnabled = true   //從0開始繪製
        yAxis.axisLineColor =  UIColor.black  //Y軸顏色
        
        yAxis.axisMaximum = 2400
        yAxis.axisMinimum = 0
        
        //設定Y軸上標籤的樣式
        yAxis.labelPosition = .outsideChart   //label位置
        yAxis.labelTextColor = UIColor.brown   //文字顏色
        yAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        //設定Y軸上標籤顯示數字的格式
         //   let  leftFormatter = NumberFormatter()  //自定義格式
         // leftFormatter.positiveSuffix = "kacl"  //數字字尾單位
         //  myView.leftAxis.valueFormatter = DefaultAxisValueFormatter.init(formatter: leftFormatter)
        
        return myView
        
        
    }

    
    
}

struct Bar_28 : UIViewRepresentable {
    let months = [String]()
    let 早餐 = [21, 24, 26, 23, 22, 26, 24, 28, 22, 24, 25, 24] //數字最小
    let 午餐 = [32, 33, 34, 31, 32, 35, 36, 38, 30, 34, 35, 31]
    let 晚餐 = [88, 66, 44, 53, 77, 99, 55, 77, 88, 66, 49, 66]
   
    func makeUIView(context: Context) -> BarChartView {
        return setChart(dataPoints: months, values: 早餐)
        
    }
    
    func updateUIView(_ uiView: BarChartView, context: UIViewRepresentableContext<Bar_28>)
    {
        
    }
    
    typealias UIViewType = BarChartView
    
    //Bar chart accepts data as array of BarChartDataEntry objects
    var myView28 = BarChartView()
    
    /*var entries : [BarChartDataEntry] //早餐
     var entries2 : [BarChartDataEntry] //午餐
     var entries3 : [BarChartDataEntry] //晚餐*/
    func setChart(dataPoints: [String], values: [Int]) -> BarChartView {
        
        //若沒有資料，顯示的文字
        myView28.drawValueAboveBarEnabled = false
        myView28.noDataText = "You need to provide data for the chart."
        //存放資料的陣列，型別是BarChartDataEntry.
        var set早 : [BarChartDataEntry] = []
        var set午 : [BarChartDataEntry] = [] //午餐
        var set晚 : [BarChartDataEntry] = [] //晚餐
        //迴圈，來載入每筆資料內容
        let wfood = re.Test_Food(uid: "Biggg", choose: "28day", Startday: "", Endday: "")
        let i = wfood.count
        var 早 = [Int]()
        var 午 = [Int]()
        var 晚 = [Int]()
        var 日期 = [String]()
        var k = 0
        
        for _ in k...i{
            if(k>=i)
            {
                break;
            }
            else if(wfood[0]=="null")
            {
                早.append(0)
                午.append(0)
                晚.append(0)
                日期.append("0")
                
                let data早 = BarChartDataEntry(x: Double(k), y: Double(早[k]))
                let data午 = BarChartDataEntry(x: Double(k), y: Double(午[k]))
                let data晚 = BarChartDataEntry(x: Double(k), y: Double(晚[k]))
                set早.append(data早)
                set午.append(data午)
                set晚.append(data晚)
                break;
            }
            else{
                let data_BP1 = String(wfood[k]!)
                let first:CharacterSet = ["：",","];
               
                let first2 = data_BP1.components(separatedBy: first)
                早.append(first2[1].toInt()!)
                午.append(first2[1].toInt()!+first2[3].toInt()!)
                晚.append(first2[1].toInt()!+first2[3].toInt()!+first2[5].toInt()!)
                
                
                let data早 = BarChartDataEntry(x: Double(k), y: Double(早[k]))
                let data午 = BarChartDataEntry(x: Double(k), y: Double(午[k]))
                let data晚 = BarChartDataEntry(x: Double(k), y: Double(晚[k]))
                set早.append(data早)
                set午.append(data午)
                set晚.append(data晚)
                日期.append(first2[9])
                myView28.xAxis.valueFormatter = IndexAxisValueFormatter(values: 日期)
            
                k+=1
            }
           
        }
        
        //顯示的資料之內容與名稱（左下角所顯示的）
        let chartData早 = BarChartDataSet(entries: set早, label: "早餐")
        let chartData午 = BarChartDataSet(entries: set午, label: "午餐")
        let chartData晚 = BarChartDataSet(entries: set晚, label: "晚餐")
        //把dataSet轉換成可顯示的BarChartData
        let chartData = BarChartData(dataSets: [chartData晚,chartData午,chartData早])
      
        //指定剛剛連結的myView要顯示的資料為charData
        myView28.data = chartData
        
        //改變chartDataSet的顏色
        chartData早.colors = [UIColor(red: 255/255, green: 226/255, blue: 164/255, alpha: 1)]
        chartData午.colors = [UIColor(red: 226/255, green: 137/255, blue: 108/255, alpha: 1)]
        chartData晚.colors = [UIColor(red: 12/255, green: 117/255, blue: 176/255, alpha: 1)]
        myView28.data?.setValueFont(UIFont.systemFont(ofSize: 18))//文字字型
        myView28.data?.setValueTextColor(UIColor.brown)  //文字顏色
        myView28.xAxis.axisRange = 0
        //改變chartDataSet為彩色
        //chartDataSet.colors = ChartColorTemplates.colorful()
        
        
        
        //改變barChartView的背景顏色
        // myView.backgroundColor = UIColor(red:0/255, green: 0/255, blue: 0/255, alpha: 1)
        
        //一個一個延遲顯現的特效
         //myView28.animate(xAxisDuration: 2.0, yAxisDuration: 2.0)
        
        //彈一下特效
         //myView28.animate(xAxisDuration: 2.0, yAxisDuration: 2.0, easingOption: .easeInBounce)
        
        //設立界線
        let limit = ChartLimitLine(limit: 50.0, label: "Target")
        
        myView28.rightAxis.addLimitLine(limit)
        
        //標籤換到下方
        myView28.xAxis.labelPosition = .bottom
        
        //設定X軸文字
        
        myView28.xAxis.labelTextColor = UIColor.brown //label文字顏色
        //xAxis.axisLineColor = UIColor.black  // 設定X軸顏色
       // xAxis.drawGridLinesEnabled = false  // 隱藏隔線
        myView28.xAxis.labelPosition = .bottom       // 設定文字位置
       // xAxis.spaceMin = 1.5                // X軸左邊間隔距離
     //   xAxis.spaceMax = 1.5                // X軸右邊間隔距離
        myView28.xAxis.labelFont = UIFont.systemFont(ofSize: 8)  //文字字型
        myView28.doubleTapToZoomEnabled = false   //取消雙擊縮放
        myView28.dragEnabled = true  //啟用拖拽圖表
        myView28.dragDecelerationEnabled = false  //拖拽後是否有慣性效果
        myView28.dragDecelerationFrictionCoef = 0 //拖拽後慣性效果的摩擦係數(0~1)，數值越小，慣性越不明顯
     
        //設定y軸文字
        myView28.rightAxis.enabled = false
        myView28.leftAxis.drawZeroLineEnabled = true   //從0開始繪製
        myView28.leftAxis.axisLineColor =  UIColor.black  //Y軸顏色
        
        myView28.leftAxis.axisMaximum=2400
        myView28.leftAxis.axisMinimum=0
        
        //設定Y軸上標籤的樣式
        myView28.leftAxis.labelPosition = .outsideChart   //label位置
        myView28.leftAxis.labelTextColor = UIColor.brown   //文字顏色
        myView28.leftAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        //設定Y軸上標籤顯示數字的格式
           // let  leftFormatter = NumberFormatter()  //自定義格式
          //  leftFormatter.positiveSuffix = "kacl"  //數字字尾單位
          // myView.leftAxis.valueFormatter = DefaultAxisValueFormatter.init(formatter: leftFormatter)
        return myView28
        
        
    }

    
}
