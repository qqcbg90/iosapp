//
//  EditMy.swift
//  icansee
//
//  Created by WenLi Lee on 2020/12/8.
//

import SwiftUI
import Combine

struct EditMy: View {
     
    
    @Binding var user : String
    //
    
    
    @State var  birth = Date()
    
    var formatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy/MM/dd"
        return formatter
    }()
    
    class TextLimiter: ObservableObject {
        private let limit: Int
        
        init(limit: Int) {
            self.limit = limit
        }
        
        @Published var hasReachedLimit = false
        @Published var value = "" {
            didSet {
                if value.count > self.limit {
                    value = String(value.prefix(self.limit))
                    self.hasReachedLimit = true
                } else {
                    self.hasReachedLimit = false
                }
            }
        }
    }
    
    
    @ObservedObject var phone = TextLimiter(limit: 10)
    @ObservedObject var height = TextLimiter(limit: 5)
    @ObservedObject var weight = TextLimiter(limit: 5)
    
    //
    
    @State var signUp = false
    @State var pass = ""
    @State var uid = ""
    @State var name = ""
    @State var sex = ""
    @State var email = ""
    //
    @State var final = ""
    @State private var showAlert = false
    //
    
    @State private var username: String = ""
    @State private var isEditing = false
    //
    
    
    var body: some View {
        ZStack(alignment: Alignment(horizontal: .center, vertical: .center)){
            VStack(alignment: .leading, spacing: 25) {
                Spacer(minLength: 20)
                Text("修改個人資料")
                    .font(.system(size: 35, weight: .bold))
                    .foregroundColor(Color("Color1"))
                ScrollView(.vertical, showsIndicators: false) {
                    
                    let data = re.profile(uid: user, choose: "profile")
                    let ddd = data.components(separatedBy: first)
                    let sex = (ddd[5] == "1") ? "男" : "女";
                 
                    Group{                     
                            VStack(alignment: .leading, spacing: 10){
                            Text("姓名").foregroundColor(Color("Color1"))
                            Text("\(ddd[1])").foregroundColor(Color("Color1"))
                            Divider().background(Color("Color1").opacity(0.5))
                        }
                        
                        VStack(alignment: .leading, spacing: 10){
                            Text("帳號").foregroundColor(Color("Color1"))
                            Text(user).foregroundColor(Color("Color1"))
                            Divider().background(Color("Color1").opacity(0.5))
                        }
                        VStack(alignment: .leading, spacing: 10){
                            Text("生日").foregroundColor(Color("Color1"))
                            Text("\(ddd[3])").foregroundColor(Color("Color1"))
                            Divider().background(Color("Color1").opacity(0.5))
                        }
                        VStack(alignment: .leading, spacing: 10){
                            Text("性別").foregroundColor(Color("Color1"))
                            Text(sex).foregroundColor(Color("Color1"))
                            Divider().background(Color("Color1").opacity(0.5))
                        }
                        
                        VStack(alignment: .leading, spacing: 10){

                            Text("信箱").foregroundColor(Color("Color1"))
                            TextField("\(ddd[9])", text: $email).textContentType(.emailAddress).keyboardType(.alphabet)
                                .foregroundColor(.black)
                            Divider().background(Color("Color1").opacity(0.5))
                        }
                        VStack(alignment: .leading, spacing: 10){
                            Text("手機電話").foregroundColor(Color("Color1"))
                            TextField("09xxxxxxxx", text: $phone.value).textContentType(.telephoneNumber)
                                .foregroundColor(Color(.black))
                            Divider().background(Color("Color1").opacity(0.5))
                        }
                        .keyboardType(.numberPad)
                        .onTapGesture {
                            UIApplication.shared.endEditing()
                        }
                        VStack(alignment: .leading, spacing: 10){
                            Text("身高").foregroundColor(Color("Color1"))
                            TextField("身高", text: $height.value)
                                .foregroundColor(Color(.black))
                            Divider().background(Color("Color1").opacity(0.5))
                        }
                        .keyboardType(.decimalPad)
                        .onTapGesture {
                            UIApplication.shared.endEditing()
                        }
                        VStack(alignment: .leading, spacing: 10){
                            Text("體重").foregroundColor(Color("Color1"))
                            TextField("體重", text: $weight.value)
                                .foregroundColor(Color(.black))
                            Divider().background(Color("Color1").opacity(0.5))
                        }
                        .keyboardType(.decimalPad)
                        .onTapGesture {
                            UIApplication.shared.endEditing()
                        }
                        
                        
                    }
                              
                    HStack{
                        
                        Spacer()
                        //MARK:- webservice
                        Button(action: {
                            final = re.update_profile2(uid: user, choose: "profile", email: email, phone: phone.value, height: height.value, weight: weight.value, password: "", newpassword: "", n1: "", n2: "", n3: "", n4: "")
                            self.showAlert = true
                        }){
                            
                            Text("Save")
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                                .padding(.vertical)
                                .padding(.horizontal,45)
                                .background(Color("Color1"))
                                .clipShape(Capsule())
                            
                        }
                        .alert(isPresented: $showAlert) { () -> Alert in
                            
                            var title = ""
                            var message = ""
                            if(final == "完成")
                            {
                                title = "成功"
                                message = "個人資料修改成功"
                            }
                            else
                            {
                                title = "失敗"
                                message = final;
                            }
                            
                            return Alert(title: Text(title), message: Text(message), dismissButton: .cancel(Text("OK")))
                        }
                        
                        Spacer()
                    }
                    .padding(.top)
                }
                Spacer(minLength: 80)
            }
            .padding(.top,(UIApplication.shared.windows.first?.safeAreaInsets.top)! + 50)
            .padding()
            
        }.background(Color.white.edgesIgnoringSafeArea(.all))
        .edgesIgnoringSafeArea(.all)
        .statusBar(hidden: true)
    }
    
}


struct EditMy_Previews: PreviewProvider {
    static var previews: some View {
        EditMy(user: .constant(""))
    }
}
