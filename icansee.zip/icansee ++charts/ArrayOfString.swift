﻿import Foundation
public class ArrayOfString{
     public var stringArr : [String?] = [] 
}
