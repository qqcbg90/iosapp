//
//  settings_.swift
//  icansee
//
//  Created by WenLi Lee on 2020/12/8.
//

import SwiftUI
import Combine

class settings_: ObservableObject {
 
    var didChange = PassthroughSubject<Void, Never>()
    
    @Published var sport = false { didSet { update() } }//運動量是否足夠
    @Published var screen = false { didSet { update() } }//螢幕使用過長
    @Published var roomtemp = false { didSet { update() } }//是否開啟冷暖氣
    @Published var medicine = false { didSet { update() } }//提醒服藥
    @Published var hightNum = false { didSet { update() } }//數值異常提醒
    @Published var bluetooth = false { didSet { update() } }//是否開藍芽
    @Published var faceid = false { didSet { update() } }//開啟face id
    
    @Published var types = ["Off","On"]
    @Published var type = 0 { didSet { update() } }
    
    @Published var isToggleOn = false { didSet { update() } }
    
    func update() {
        didChange.send(())
    }
}
