//
//  AccountView.swift
//  LeftSlidingMenu-SwiftUI
//
//  Created by Hasan, MdAdit on 4/9/20.
//  Copyright © 2020 FirstAlert. All rights reserved.
//

import SwiftUI

struct AccountView: View {
    var body: some View {
        Text("AccountView") 
    }
}

struct AccountView_Previews: PreviewProvider {
    static var previews: some View {
        AccountView()
    }
}
