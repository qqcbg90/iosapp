//
//  ContentView.swift
//  LeftSlidingMenu-SwiftUI
//
//  Created by Hasan, MdAdit on 4/9/20.
//  Copyright © 2020 FirstAlert. All rights reserved.
//

import SwiftUI

struct HomeView: View {
    var body: some View {
        Text("HomeView") 
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
