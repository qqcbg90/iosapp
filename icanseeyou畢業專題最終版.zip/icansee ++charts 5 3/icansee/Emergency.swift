//
//  Emergency.swift
//  icansee
//
//  Created by WenLi Lee on 2020/12/8.
//

import SwiftUI
import Combine
//緊急聯絡人

struct Emergency: View {
    
    @Binding var user : String
    //
    
    @State private var showAlert = false
    //
    
    @State var relationship  = ["請先查詢關係"]
    @State var selectedrelationship  = "請先查詢關係"
    @ObservedObject var bluetooth = settings_()
    //@ObservedObject var bluetooth: settings_
    @State var emercy = ""
    @State var content = ""
    
    
    @State private var User1性別 = 0
    @State private var User2性別 = 0
    //
    @State private var User1年齡 = 0
    @State private var User2年齡 = 0
    //
    @State var User1身份 = ""
    @State var User2身份 = ""
    //
    @State var final = false
    
    
    var body: some View {
        ZStack(alignment: Alignment(horizontal: .center, vertical: .center)){
            VStack(alignment: .leading, spacing: 25) {
                Spacer(minLength: 20)
                VStack(alignment: .leading, spacing: 10){
                    Text("請輸入緊急聯絡人帳號").foregroundColor(Color("Color1"))
                    TextField("緊急聯絡人帳號", text: $emercy)
                        .foregroundColor(Color(.black))
                    
                    
                    Divider().background(Color("Color1").opacity(0.5))
                }
                
                HStack{
                    
                    Spacer()
                    
                    //MARK:- webservice
                    Button(action: {
                        
                        
                        let con = re.set_Content(User1: user, User2: emercy)
                        
                        if(emercy == user)
                        {
                            selectedrelationship = "與自己無法建立關係"
                            relationship = ["與自己無法建立關係"]
                        }
                        else
                        {
                            
                            if(con.prefix(1) == "：")
                            {
                                selectedrelationship = "請選擇與您的關係"
                                let first:CharacterSet = ["：",","];
                                let first2 = con.components(separatedBy: first)
                                User1性別 = first2[3].toInt()!
                                User1年齡 = first2[5].toInt()!
                                //
                                User2性別 = first2[9].toInt()!
                                User1年齡 = first2[11].toInt()!
                                //家屬關係的if else
                                if(first2[9] == "0")
                                {
                                    selectedrelationship = "查無此帳號"
                                    relationship  = ["查無此帳號"]
                                }
                                
                                else if (User2性別 == 1)
                                {
                                    if (User1年齡 < User2年齡) //User2是比User1大的男生
                                    {
                                        relationship  = ["祖父", "父親", "伴侶","妹妹","哥哥","其他"]
                                    }
                                    else if (User1年齡 == User2年齡) //User2是跟User1同年齡的男生
                                    {
                                        relationship  = ["伴侶", "哥哥","弟弟","其他"]
                                    }
                                    else //User2是比User1小的男生
                                    {
                                        relationship  = ["伴侶", "弟弟","兒子","孫子","其他"]
                                    }
                                }
                                else
                                {
                                    if (User1年齡 < User2年齡) //User2是比User1大的女生
                                    {
                                        relationship  = ["祖母", "母親","伴侶","姐姐","其他"]
                                    }
                                    else if (User1年齡 == User2年齡) //User2是跟User1同年齡的女生
                                    {
                                        relationship  = ["伴侶", "姐姐","妹妹","其他"]
                                    }
                                    else //User2是比User1小的女生
                                    {
                                        relationship  = ["伴侶", "妹妹","女兒","孫女","其他"]
                                    }
                                }
                            }
                            else
                            {
                                selectedrelationship = con
                                relationship  = [con]
                                
                            }
                        }
                        
                    })
                    {
                        Text("查詢關係")
                            .fontWeight(.bold)
                            .foregroundColor(Color.white)
                            .padding(.vertical)
                            .padding(.horizontal,45)
                            .background(Color("Color1"))
                            .clipShape(Capsule())
                        
                    }
                    
                    Spacer()
                }
                
                
                
                VStack(alignment: .leading, spacing: 10){
                    Text("此聯絡人與你的關係：\(selectedrelationship)").foregroundColor(Color("Color1"))
                    Section(header:Text("")){
                        HStack {
                            Picker(selection: $selectedrelationship, label:
                                    Text("選擇運動")
                            ){
                                ForEach(relationship, id: \.self) { (sport) in
                                    Text(sport)
                                        .foregroundColor(Color("Color1"))
                                }
                            }
                            
                        }
                    }
                }
                
                HStack{
                    
                    Spacer()
                    
                    //MARK:- webservice
                    Button(action: {
                        
                        
                        User2身份 = selectedrelationship;
                        
                        if (selectedrelationship == "祖父" || selectedrelationship == "祖母")
                        {
                            User1身份 = (User1性別 == 1) ? "孫子" : "孫女";
                        }
                        else if (selectedrelationship == "父親" || selectedrelationship == "母親")
                        {
                            User1身份 = (User1性別 == 1) ? "兒子" : "女兒";
                            
                        }
                        else if (selectedrelationship == "伴侶")
                        {
                            User1身份 = "伴侶";
                        }
                        else if (selectedrelationship == "哥哥" || selectedrelationship == "姐姐")
                        {
                            User1身份 = (User1性別 == 1) ? "弟弟" : "妹妹";
                        }
                        else if (selectedrelationship == "弟弟" || selectedrelationship == "妹妹")
                        {
                            User1身份 = (User1性別 == 1) ? "哥哥" : "姐姐";
                        }
                        else if (selectedrelationship == "兒子" || selectedrelationship == "女兒")
                        {
                            User1身份 = (User1性別 == 1) ? "父親" : "母親";
                        }
                        else if (selectedrelationship == "孫子" || selectedrelationship == "孫女")
                        {
                            User1身份 = (User1性別 == 1) ? "祖父" : "祖母";
                        }
                        else
                        {
                            User1身份 = "其他";
                        }
                        
                        final = re.Insert_Content(User1: user, User2: emercy, User1身分: User1身份, User2身分: User2身份)
                        self.showAlert = true
                    })
                    {
                        Text("Save")
                            .fontWeight(.bold)
                            .foregroundColor(Color.white)
                            .padding(.vertical)
                            .padding(.horizontal,45)
                            .background(Color("Color1"))
                            .clipShape(Capsule())
                        
                        
                    } .alert(isPresented: $showAlert) { () -> Alert in
                        
                        var title = ""
                        var message = ""
                        
                        if(final == true){
                            title = "成功"
                            message = "建立關係成功"
                        }
                        else
                        {
                            title = "失敗"
                            message = "建立關係失敗"
                        }
                        return Alert(title: Text(title), message: Text(message), dismissButton: .cancel(Text("OK")))
                    }
                    
                    
                    
                    Spacer()
                }
                
                .padding(.top)
                
                Spacer(minLength: 0)
            }
            
            .padding()
            
        }.background(Color.white.edgesIgnoringSafeArea(.all))
        .edgesIgnoringSafeArea(.all)
        .statusBar(hidden: true)
        
    }
    
}
struct Emergency_Previews: PreviewProvider {
    static var previews: some View {
        Emergency(user: .constant(""))
    }
}



