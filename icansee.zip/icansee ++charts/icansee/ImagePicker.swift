//
//  ImagePicker.swift
//  icansee
//
//  Created by WenLi Lee on 2020/12/8.
//

import SwiftUI

struct ImagePicker: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct ImagePicker_Previews: PreviewProvider {
    static var previews: some View {
        ImagePicker()
    }
}
