//
//  InfoVIew.swift
//  icansee
//
//  Created by WenLi Lee on 2020/11/15.
//
import Foundation
import SwiftUI

struct InfoVIew: View {
    @State var showDetails = false
    @State var selectedAbout = AboutData[0]
    @Namespace var animation
    
    var body: some View {
        ZStack {
            ListView(showDetails: self.$showDetails, selectedAbout: self.$selectedAbout, animation: animation)
            
            if showDetails {
                DetailsView(showDetails: self.$showDetails, selectedAbout: self.$selectedAbout, animation: animation)
            }
        }
    }
}

struct InfoVIew_Previews: PreviewProvider {
    static var previews: some View {
        InfoVIew(showDetails: false, selectedAbout: AboutData[0])
            
    }
}

struct DetailsView: View {
    @Binding var showDetails: Bool
    @Binding var selectedAbout: About
    var animation: Namespace.ID
    
    var body: some View {
        ZStack {
            selectedAbout.backgroundColor.edgesIgnoringSafeArea(.all)
                
            VStack(alignment: .leading) {
                HStack {
                    Button(action: {
                        withAnimation {
                            self.showDetails.toggle()
                        }
                    }, label: {
                        Image(systemName: "chevron.left")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 12)
                    })
                    
                    Spacer()
                    
                    Button(action: {}, label: {
                        Image(systemName: "heart.fill")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 20)
                    })
                    .frame(width: 80, height: 50)
                    .background(Color.white.opacity(0.3))
                    .cornerRadius(25)
                }
                .padding()
                .foregroundColor(.white)
                
                ZStack(alignment: .bottom) {
                    VStack {
                        HStack(alignment: .top) {
                            Image(selectedAbout.image)
                                //.resizable()
                                .aspectRatio(contentMode: .fit)
                                .offset(x: 30)
                                .matchedGeometryEffect(id: selectedAbout.id, in: animation)
                            
                            Spacer()
                            
                            VStack(alignment: .leading) {
                                Text(selectedAbout.title)
                                    .font(.system(size: 40, weight: .bold))
                                
                                Text("衛教資訊")
                                    .font(.system(size: 19, weight: .medium))
                            
                            }
                            .foregroundColor(.white)
                            
                            Spacer()
                        }
                        
                        Spacer()
                    }
                    
                    ZStack(alignment: .bottom) {
                        VStack {
                            Spacer()
                            
                            HStack(alignment: .top) {
                                ScrollView(.vertical, showsIndicators: false) {
                                VStack {
                                    Text(selectedAbout.info)
                                        .fontWeight(.medium)
                                        .lineSpacing(10.0)
                                    
                                }
                                .frame(width: 200)
                                .padding(38)
                                .foregroundColor(Color(#colorLiteral(red: 0.3126512468, green: 0.3103967607, blue: 0.3143810034, alpha: 1)))
                                .background(Color.white)
                                .cornerRadius(30, corners: .topRight)
                                
                                }.position(x: 130, y: 500)
                                Spacer()
                                
                                VStack {
                                    if(selectedAbout.title=="飲食"){
                                    InfoView(title: "", value: "")
                                        .padding(.top)
                                    InfoView(title: "每日飲食", value: "")
                                        .padding(.top)
                                    InfoView(title: "全榖雜糧類", value: "３碗")
                                        .padding(.top)
                                    InfoView(title: "豆魚蛋肉類", value: "６份")
                                        .padding(.top)
                                    
                                    InfoView(title: "乳品類", value: "1.5杯")
                                        .padding(.top)
                                    InfoView(title: "蔬菜類", value: "4份")
                                        .padding(.top)
                                    InfoView(title: "水果類", value: "3份")
                                        .padding(.top)
                                    InfoView(title: "油脂堅果類", value: "6份")
                                        .padding(.top)
                                    }
                                    else if(selectedAbout.title=="三高")
                                    {
                                        InfoView(title: "", value: "")
                                            .padding(.horizontal,0)
                                        InfoView(title: "積極控制三高\("\n")減少中風風險\("\n")", value: "健康飲食\("\n")\("\n")規律運動\("\n")\("\n")控制體重\("\n")\("\n")無菸害生活\("\n")\("\n")紓解壓力\("\n")\("\n")定期健康檢查\("\n")\("\n")")
                                            .position(x: 150, y: 350)
                                        
                                    }
                                    else
                                    {
                                        InfoView(title: "", value: "")
                                            .padding(.horizontal,0)
                                        InfoView(title: "保護眼睛健康\("\n")從飲食中攝取\("\n")", value: "葉黃素\("\n")\("\n")花青素\("\n")\("\n")牛磺酸\("\n")\("\n")蝦紅素\("\n")\("\n")Omega-3\("\n")\("\n")")
                                            .position(x: 150, y: 350)
                                    }
                                }
                                .foregroundColor(.white)
                                .padding(.top, 40)
                            
                                Spacer(minLength: 35)
                            }
                        }
                        .edgesIgnoringSafeArea(.bottom)
                        
                    }
                }
            }
        }
    }
}

struct InfoView: View {
    var title: String
    var value: String
    
    var body: some View {
        VStack {
            Text(title)
                .font(.system(size: 20))
                .fontWeight(.medium)
            
            Text(value)
                .font(.system(size: 20))
                .fontWeight(.bold)
        }
    }
}


struct ListView: View {
    @State var menuSelectedItem = 0
    @Binding var showDetails: Bool
    @Binding var selectedAbout: About
    var animation: Namespace.ID
    
    var body: some View {
        VStack {
            info()
           
            ScrollView(.vertical, showsIndicators: false, content: {
                VStack(spacing: 20) {
                    ForEach(AboutData) { about in
                        CardView(about: about, animation: animation)
                            .onTapGesture(count: 1, perform: {
                                withAnimation {
                                    self.selectedAbout = about
                                    self.showDetails.toggle()
                                }
                            })
                    }
                }
            })
            .padding(.top)
        }
        .padding(.horizontal, 20)
    }
}

struct CardView: View {
    var about: About
    var animation: Namespace.ID
    
    var body: some View {
        HStack {
            VStack(alignment: .leading) {
                Text(about.title)
                
                Text("衛教內容")
                    .font(.system(size: 18, weight: .bold))
            }
            .foregroundColor(.white)
            
            Spacer(minLength: 0)
            
            Image(about.image)
                .resizable()
                .aspectRatio(contentMode: .fit)
                //.matchedGeometryEffect(id: about.id, in: animation)
                .zIndex(1)
        }
        .padding(.vertical, 40)
        .padding(.horizontal, 35)
        .frame(height: 220)
        .background(about.backgroundColor)
        .cornerRadius(35, corners: [.topRight, .bottomLeft])
    }
}

struct About: Identifiable {
    var id = UUID().uuidString
    var backgroundColor: Color
    var title: String
    var image: String
    var info: String
}

let AboutData = [
    About(backgroundColor: Color(#colorLiteral(red: 0.0979558304, green: 0.1926653981, blue: 0.6239119172, alpha: 1)), title: "飲食", image: "三餐熱量", info: "飲食應依『每日飲食指南』的食物分類與建議份量，適當選擇搭配。特別注意應吃到足夠量的蔬菜、水果、全穀、豆類、堅果種子及乳製品。為使營養均衡，應依『每日飲食指南』的食物分類與建議份量來做選擇\("\n")1.「全穀雜糧類」取代「全穀根莖類」\("\n")以「雜糧」名稱取代「根莖」，讓民眾知道此類別食物不止稻米、大麥、玉米等穀類作物，還包括根莖類的薯類，以及紅豆、綠豆、皇帝豆、栗子、菱角等富含澱粉的種子豆類。\("\n")2. 調整「蛋」在蛋白質食物來源的順序\("\n")近年研究顯示，「蛋」的攝取與血液中膽固醇濃度、罹患心血管疾病風險較不具關聯性，加上蛋所含的營養豐富，因此調整蛋在蛋白質食物來源的順序。選擇蛋白質類食物時，不再遵循「豆➞魚➞肉➞蛋」的優先順序，而改為「豆➞魚➞蛋➞肉」。\("\n")3. 乳品類\("\n")乳品類是人類攝取鈣質最重要的來源，乳品類含有蛋白質、乳糖、脂肪、維生素、礦物質等營養素，營養價值相當高。乳品類一般指的是哺乳動物的乳汁或乳製品，包括牛乳、羊乳、優酪乳、起司、優格等。\("\n")4. 蔬菜類\("\n")蔬菜類指的就是一般的食用蔬菜，蔬菜類含有豐富的維生素、礦物質、膳食纖維等。蔬菜類的膳食纖維能夠有效的幫助排便、維持腸道健康，是邁向健康必不可少的食物種類。蔬菜類的種類繁多，依據食用部位可分為葉菜類、花菜類、根菜類、果菜類等。\("\n")5. 水果類\("\n")台灣是國際知名的水果產地，國內的水果產量多、品質好，國人們可以輕易購買到好吃的水果。水果類是人類補充維生素C不可或缺的來源，水果的外皮則含有膳食纖維，可以預防便祕、大腸癌等疾病。常見的水果包括芒果、蘋果、梨子、番茄等。\("\n")6. 油脂與堅果種子類\("\n")油脂與堅果種子類含有豐富的脂肪，而脂肪還可細分為動物脂肪和植物脂肪，動物性脂肪的飽和脂肪含量較高，對於心血管的負擔較大，因此在選擇進食此類食品時，應優先選擇植物油。常見的油脂與堅果種子類食物包括植物油、動物油、美乃滋、花生、瓜子等。\("\n")\("\n")\("\n")\("\n")\("\n")\("\n")\("\n")\("\n")\("\n")"),
    About(backgroundColor: Color(#colorLiteral(red: 0.05730711669, green: 0.5047739744, blue: 0.7162055373, alpha: 1)), title: "三高", image: "生理數值", info: "維持健康生活型態及積極控制三高，減少中風發生之風險大部分的中風是可以藉由健康的生活型態及規律服藥積極控制三高來預防的，國民健康署邱署長淑媞呼籲民眾只要把握以下「七招」，就能夠降低罹患中風之風險：\("\n")1.健康飲食：\("\n")養成三餐定時、少吃零嘴的好習慣，多喝白開水來取代含糖飲料，飲食上可多選用蔬菜、糙米、全穀雜糧，堅果、少油、少鹽、少糖，減少高飽和脂肪食物，避免攝食過度加工或精緻食品，烹調則建議以蒸、煮、川燙代替油炸。挑選低鈉飲食，有助控制血壓、選好油，拒反式脂肪、少動物脂肪，選天然植物油。\("\n")2. 規律運動：\("\n")每週累積150分鐘的中度身體活動，例如伸展操、做家事、陪小孩玩、跳舞、慢跑、騎自行車等等。所有運動不嫌晚，可以從每天運動 15 分鐘開始，再逐漸延長運動時間，多動多流汗，對身體健康肯定益處多多。\("\n")3.控制體重：\("\n")建議成人要維持BMI 18.5-24的健康體位;另在代謝症候群防治上，成年男生腰圍不超過90公分，成年女生腰圍不超過80公分，可透過「聰明吃、快樂動、天天量體重」的健康生活守則，遠離肥胖，並降低發生腦中風等慢性疾病的風險。\("\n")4.無菸害生活\("\n")不管是直接吸菸或被動吸入二手菸，都會增加罹患中風的風險，鼓勵吸菸民眾要立即主動戒菸。現在國民健康署提供二代戒菸服務，戒菸用藥也比照健保用藥，最高僅只須負擔200元，使戒菸不再是難事。民眾如有任何戒菸方面的問題，可撥打國民健康署設置的免費戒菸諮詢專線0800-636363，或洽各縣市衛生局、所接受戒菸諮詢服務。只要下定決心戒菸、拒菸以及避免親友暴露到二手菸的危害，也就是重拾健康的開始。\("\n")5.紓解壓力：\("\n")學習情緒管理，並安排閱讀或旅行等休閒活動，如有情緒不適問題，除可求助專業醫師外，也可找家人、朋友傾訴心事或主動尋求支持性團體協助，或洽詢國民健康署更年期保健諮詢服務專線「0800-00-5107」，提供您更年期症狀評估與健康照護的諮詢建議。\("\n")6.定期健康檢查\("\n")善加利用國民健康署提供40到64歲民眾每3年一次，65歲以上民眾每年1次的免費成人預防保健服務，服務內容包括BMI、腰圍、血壓、血糖、血脂等心臟病重要危險因子的檢查，以及早發現身體異常，俾能及早調整不良生活習慣及控制三高等危險因子，遠離疾病威脅。\("\n")7.掌握三高關鍵控制數字\("\n")有三高問題且正在服藥的民眾，除了養成健康的生活型態以外，應該要遵照醫師指示定期服藥及回診，將三高數值控制在血壓<140/90mmHg、醣化血色素<7%、低密度脂蛋白膽固醇<100mg/dl，或與您的醫師討論三高控制數值，更應積極採行健康的生活型態，如需用藥，應遵照醫師處方正確用藥及定期回診追蹤，以降低罹患中風的風險。\("\n")近期日夜溫差大，防範中風急性發作現正進入秋末冬初之際，早晚氣溫偏低，日夜溫差較大，國民健康署呼籲民眾，氣溫的變化容易造成血管的收縮，引發血壓的變化，可能會增加中 風急性發作的機會，請民眾持續注意氣溫的變化，做好保暖措施、控制三高，選擇健康的生活型態，遠離中風之危害。\("\n")\("\n")\("\n")\("\n")\("\n")\("\n")\("\n")\("\n")\("\n")"),
    About(backgroundColor: Color(#colorLiteral(red: 0.9372549057, green: 0.3490196168, blue: 0.1921568662, alpha: 1)), title: "眼部保健", image: "睡眠用眼", info: "對視力應有的認識﹕\("\n")一般人常以為眼睛模糊、看清楚就是近視(遠視、散光)，這種觀念是不對的。因為視力不良並不是單純的近視(遠視、散光)的問題，身體某些部位罹患疾病(如﹕糖尿病、高血壓等)，都可能造成視力不良;所以當您發現眼睛模糊、看不清楚時，請到醫院檢查(必要時才配眼鏡)，以確保眼睛健康。\("\n")常見的眼睛疾病及症狀﹕\("\n")常見的眼睛疾病，有屈光不正(如﹕如近視、遠視等)，斜視、結膜炎、角膜炎、白內障、青光眼、針眼、高血壓及糖尿病網膜病變、色盲、視神經炎、網膜中心血管阻塞、網膜剝離及外傷性眼疾等;其症狀為﹕流淚、視力模糊、眼前出現雙影、黑影或飛蚊現象，怕光、有異物感、眼睛腫脹疼痛、視野缺損等。\("\n")眼睛保健的方法﹕\("\n")1. 在閱讀書報時，應保持30公分以上距離，看電視時須與畫面至少保持3公尺距離。\("\n")2. 養成每閱讀50分鐘，休息10分鐘的習慣，並選擇光線由背後或左後方投射而來的方式閱讀。\("\n")3. 避免閱讀印刷不良、字體過小的書藉;也避免在行車、走路、光線不足及強光下閱讀。\("\n")4. 避免使用不潔毛巾及公共洗臉用具;不可用手揉眼睛。\("\n")5. 定期(最好每半年一次)到醫院作眼睛健康檢查。\("\n")6. 慎防酸鹼、銳器等危險物品傷及眼睛。\("\n")7. 勿逗留於灰、煙、高熱等環境，均有益眼睛健康。\("\n")8. 平時眼睛覺得乾澀可用溫熱毛巾濕熱敷。\("\n")\("\n")\("\n")\("\n")\("\n")\("\n")\("\n")\("\n")\("\n")")
]

struct info: View {
    var body: some View {
        HStack {
            Spacer()
            Text("衛教資訊")
                .font(.system(size: 24))
                .fontWeight(.bold)
                .foregroundColor(.orange)
            Spacer()
            
        }
    }
}

struct RoundedCorner: Shape {
    var radius: CGFloat = .infinity
    var corners: UIRectCorner = .allCorners

    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        return Path(path.cgPath)
    }
}

extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape(RoundedCorner(radius: radius, corners: corners))
    }
}
