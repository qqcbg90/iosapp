//
//  TermsAndPrivacyView.swift
//  LeftSlidingMenu-SwiftUI
//
//  Created by Hasan, MdAdit on 4/9/20.
//  Copyright © 2020 FirstAlert. All rights reserved.
//

import SwiftUI

struct TermsAndPrivacyView: View {
    var body: some View {
        Text("Terms And Conditions") 
    }
}

struct TermsAndPrivacyView_Previews: PreviewProvider {
    static var previews: some View {
        TermsAndPrivacyView()
    }
}
