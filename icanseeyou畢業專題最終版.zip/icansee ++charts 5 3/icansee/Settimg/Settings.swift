//
//  Settings.swift
//  icansee
//
//  Created by WenLi Lee on 2020/12/8.
//

import SwiftUI

struct Settings: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Settings_Previews: PreviewProvider {
    static var previews: some View {
        Settings()
    }
}
