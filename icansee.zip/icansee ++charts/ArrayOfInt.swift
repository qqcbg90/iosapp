import Foundation
public class ArrayOfInt{
     public var intArr : [Int] = [] 
}
