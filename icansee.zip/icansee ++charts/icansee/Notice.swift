//
//  Notice.swift
//  icansee
//
//  Created by WenLi Lee on 2020/12/8.
//

import SwiftUI
import Combine
//推播設定
struct Notice: View {
    
    @ObservedObject var bluetooth = settings_()//開藍芽
    @ObservedObject var faceid = settings_()//開啟face id
    @ObservedObject var sport = settings_() //運動量是否足夠
    @ObservedObject var screen = settings_()//螢幕使用過長
    @ObservedObject var roomtemp = settings_()//是否開啟冷暖氣
    @ObservedObject var medicine = settings_()//提醒服藥
    @ObservedObject var hightNum = settings_()//數值異常提醒
    
    var body: some View {
        ZStack(alignment: Alignment(horizontal: .center, vertical: .center)){
            VStack(alignment: .leading, spacing: 25) {
              Spacer(minLength: 20)
                VStack(alignment: .leading, spacing: 10){
                    Section() {
                        Toggle(isOn: $bluetooth.bluetooth) {
                            Text("是否開啟faceid")
                                .foregroundColor(Color("Color1"))
                                
                        }.toggleStyle(SwitchToggleStyle(tint: .blue))
                        Text(bluetooth.bluetooth ? "On" : "Off")
                             .foregroundColor(Color("Color1"))
                             .font(.system(size: 20))
                             .font(.subheadline)
                        Toggle(isOn: $faceid.faceid) {
                            Text("是否開啟藍芽")
                                .foregroundColor(Color("Color1"))
                                
                        }.toggleStyle(SwitchToggleStyle(tint: .blue))
                    }.background(Color("lightorange"))
                    Divider()
                }
                  
                  VStack(alignment: .leading, spacing: 10){
                    Section() {
                        Toggle(isOn: $sport.sport) {
                            Text("運動量是否足夠提醒")
                                .foregroundColor(Color("Color1"))
                                
                        }.toggleStyle(SwitchToggleStyle(tint: .orange))
                        Toggle(isOn: $screen.screen) {
                            Text("螢幕使用過長提醒")
                                .foregroundColor(Color("Color1"))
                                
                        }.toggleStyle(SwitchToggleStyle(tint: .orange))
                        Toggle(isOn: $roomtemp.roomtemp) {
                            Text("提醒調整冷暖氣通知")
                                .foregroundColor(Color("Color1"))
                                
                        }.toggleStyle(SwitchToggleStyle(tint: .orange))
                        
                        Toggle(isOn: $medicine.medicine) {
                            Text("提醒服藥")
                                .foregroundColor(Color("Color1"))
                                
                        }.toggleStyle(SwitchToggleStyle(tint: .orange))
                        Toggle(isOn: $hightNum.hightNum) {
                            Text("身體數值異常提醒")
                                .foregroundColor(Color("Color1"))
                                
                        }.toggleStyle(SwitchToggleStyle(tint: .orange))
                     }
                   
                  }
             
                HStack{
                    
                    Spacer()
                  
//MARK:- webservice
                    Button(action: {
                    
                    })
                    {
                        Text("Save")
                            .fontWeight(.bold)
                            .foregroundColor(Color.white)
                            .padding(.vertical)
                            .padding(.horizontal,45)
                            .background(Color("Color1"))
                            .clipShape(Capsule())
                      
                    }
                  
                    Spacer()
                }
                
                .padding(.top)
                
                Spacer(minLength: 0)
            }
            .padding()

        }.background(Color.white.edgesIgnoringSafeArea(.all))
        .edgesIgnoringSafeArea(.all)
        .statusBar(hidden: true)
       
            }
        }




struct Notice_Previews: PreviewProvider {
    static var previews: some View {
        Notice()
    }
}
