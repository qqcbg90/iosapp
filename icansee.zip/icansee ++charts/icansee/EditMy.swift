//
//  EditMy.swift
//  icansee
//
//  Created by WenLi Lee on 2020/12/8.
//

import SwiftUI
import Combine

struct EditMy: View {
    @State var  birth = Date()
    
    var formatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy/MM/dd"
        return formatter
    }()
    @State var height = ""
    @State var weight = ""
    @State var signUp = false
    @State var user = ""
    @State var pass = ""
    @State var uid = ""
    @State var name = ""
    @State var sex = ""
    @State var phone = ""
    @State var email = ""
    var body: some View {
        ZStack(alignment: Alignment(horizontal: .center, vertical: .center)){
            VStack(alignment: .leading, spacing: 25) {
                Spacer(minLength: 20)
                Text("修改個人資料")
                    .font(.system(size: 35, weight: .bold))
                    .foregroundColor(Color("Color1"))
                ScrollView(.vertical, showsIndicators: false) {
                    
                    Group{
                        
                        VStack(alignment: .leading, spacing: 10){
                            Text("帳號").foregroundColor(Color("Color1"))
                            Text("Biggg").foregroundColor(Color("Color1"))
                            Divider().background(Color("Color1").opacity(0.5))
                        }
                        
                        VStack(alignment: .leading, spacing: 10){
                            Text("信箱").foregroundColor(Color("Color1"))
                            TextField("信箱", text: $email)
                            Divider().background(Color("Color1").opacity(0.5))
                        }
                        VStack(alignment: .leading, spacing: 10){
                            Text("電話").foregroundColor(Color("Color1"))
                            TextField("電話", text: $phone)
                            Divider().background(Color("Color1").opacity(0.5))
                        }
                        VStack(alignment: .leading, spacing: 10){
                            Text("身高").foregroundColor(Color("Color1"))
                            TextField("身高", text: $height)
                            Divider().background(Color("Color1").opacity(0.5))
                        }
                        VStack(alignment: .leading, spacing: 10){
                            Text("體重").foregroundColor(Color("Color1"))
                            TextField("體重", text: $weight)
                            Divider().background(Color("Color1").opacity(0.5))
                        }
                        
                        
                    }
                    
                    VStack(alignment: .leading, spacing: 10){
                        Text("聯絡電話").foregroundColor(Color("Color1"))
                        TextField("聯絡電話", text: $phone)
                        Divider().background(Color("Color1").opacity(0.5))
                    }
                    
                    
                    HStack{
                        
                        Spacer()
                        //MARK:- webservice
                        Button(action: {
                            
                            let w_email: String = email
                            let w_phone: String = phone
                            let w_height: String = height
                            let w_weight: String = weight
                            
                            re.Edit(newid: "Biggg", email: w_email, phone:w_phone, height: w_height, weight: w_weight)
                            
                        }){
                            
                            Text("Save")
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                                .padding(.vertical)
                                .padding(.horizontal,45)
                                .background(Color("Color1"))
                                .clipShape(Capsule())
                            
                        }
                        
                        Spacer()
                    }
                    .padding(.top)
                }
                Spacer(minLength: 80)
            }
            .padding(.top,(UIApplication.shared.windows.first?.safeAreaInsets.top)! + 50)
            .padding()
            
        }.background(Color.white.edgesIgnoringSafeArea(.all))
        .edgesIgnoringSafeArea(.all)
        .statusBar(hidden: true)
    }
    
}


struct EditMy_Previews: PreviewProvider {
    static var previews: some View {
        EditMy()
    }
}
