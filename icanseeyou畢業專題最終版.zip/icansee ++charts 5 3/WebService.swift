﻿ import Foundation 
public class WebService {
 public var Url:String = "http://120.125.78.213:9487/WebService2.asmx"
 public var Host:String = "120.125.78.213:9487"
public func dataToBase64(data:NSData)->String{
        
        let result = data.base64EncodedString(options: NSData.Base64EncodingOptions.init(rawValue: 0))
        return result;
    }
    public func dataToBase64(data: Data)->String {
        let result = data.base64EncodedString()
        return result
    }
    public func byteArrayToBase64(data:[UInt])->String{
        let nsdata = NSData(bytes: data, length: data.count)
        let data  = Data.init(referencing: nsdata)
        if let str = String.init(data: data, encoding: String.Encoding.utf8){
            return str
        }
        return "";
    }
    public func timeToString(date:Date)->String{
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "HH:mm:ss"
        let dateString = dateFormatter.string(from: date)
        return dateString
    }
    public func dateToString(date:Date)->String{
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let dateString = dateFormatter.string(from: date)
        return dateString
    }
    
    public func base64ToByteArray(base64String: String) -> [UInt8] {
        let data = Data.init(base64Encoded: base64String)
        let dataCount = data!.count
        var bytes = [UInt8].init(repeating: 0, count: dataCount)
        data!.copyBytes(to: &bytes, count: dataCount)
        return bytes
    }
    func stringFromXMLString(xmlToParse:String)->String {
        do
        {
            let xml = SWXMLHash.lazy(xmlToParse)
            let xmlResponse : XMLIndexer? = xml.children.first?.children.first?.children.first
            let xmlResult: XMLIndexer?  = xmlResponse?.children.last
            
            let xmlElement = xmlResult?.element
            let str = xmlElement?.text
            let xmlElementFirst = xmlElement?.children[0] as!TextElement
            return xmlElementFirst.text
        }
        catch
        {
        }
        //NOT IMPLETEMENTED!
        var returnValue:String!
        return returnValue
    }
    func stringFromXML(data:Data)-> String
    {
        
        let xmlToParse :String? = String.init(data: data, encoding: String.Encoding.utf8)
        if xmlToParse == nil {
            return ""
        }
        if xmlToParse!.count == 0 {
            return ""
        }
        let  stringVal = stringFromXMLString(xmlToParse:  xmlToParse!)
        return stringVal
        
    }
    func stringArrFromXMLString(xmlToParse :String)->[String?]{
        let xml  = SWXMLHash.lazy(xmlToParse)
        let xmlRoot  = xml.children.first
        let xmlBody = xmlRoot?.children.last
        let xmlResponse : XMLIndexer? =  xmlBody?.children.first
        let xmlResult : XMLIndexer?  = xmlResponse?.children.last
        
        var strList = [String?]()
        let childs = xmlResult!.children
        for child in childs {
            let text = child.element?.text
            strList.append(text)
        }
        
        return strList
    }
    func stringArrFromXML(data:Data)->[String?]{
        let xmlToParse :String? = String.init(data: data, encoding: String.Encoding.utf8)
        if xmlToParse == nil {
            return [String?]()
        }
        if xmlToParse!.count == 0 {
            return [String?]()
        }
        
        let  stringVal = stringArrFromXMLString(xmlToParse:  xmlToParse!)
        return stringVal
    }
    
    func byteArrayToBase64(bytes: [UInt8]) -> String {
        
        let data = Data.init(bytes: bytes)
        let base64Encoded = data.base64EncodedString()
        return base64Encoded;
       
    }
    
    func base64ToByteArray(base64String: String) -> [UInt8]? {
        if let data = Data.init(base64Encoded: base64String){
            var bytes = [UInt8](repeating: 0, count: data.count)
            data.copyBytes(to: &bytes, count: data.count)
            return bytes;
        }
        return nil // Invalid input
    }
  
public func Login(userid:String, userpass:String)-> String{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Login xmlns=\"http://tempuri.org/\">"
soapReqXML += "<userid>"
soapReqXML += userid
soapReqXML += "</userid>"
soapReqXML += "<userpass>"
soapReqXML += userpass
soapReqXML += "</userpass>"
soapReqXML += "</Login>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Login"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  ""
 }
 let returnValue:String = strVal!
   return returnValue
}
public func SignUp(newid:String, name:String, ID:String, birth:String, sex:String, newpass:String, email:String, phone:String, height:String, weight:String)-> Bool{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<SignUp xmlns=\"http://tempuri.org/\">"
soapReqXML += "<newid>"
soapReqXML += newid
soapReqXML += "</newid>"
soapReqXML += "<name>"
soapReqXML += name
soapReqXML += "</name>"
soapReqXML += "<ID>"
soapReqXML += ID
soapReqXML += "</ID>"
soapReqXML += "<birth>"
soapReqXML += birth
soapReqXML += "</birth>"
soapReqXML += "<sex>"
soapReqXML += sex
soapReqXML += "</sex>"
soapReqXML += "<newpass>"
soapReqXML += newpass
soapReqXML += "</newpass>"
soapReqXML += "<email>"
soapReqXML += email
soapReqXML += "</email>"
soapReqXML += "<phone>"
soapReqXML += phone
soapReqXML += "</phone>"
soapReqXML += "<height>"
soapReqXML += height
soapReqXML += "</height>"
soapReqXML += "<weight>"
soapReqXML += weight
soapReqXML += "</weight>"
soapReqXML += "</SignUp>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/SignUp"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  false
 }
 let returnValue:Bool = strVal!.lowercased() == "true" 
   return returnValue
}
public func SignUp2(newid:String, name:String, ID:String, birth:String, sex:String, newpass:String, email:String, phone:String, height:String, weight:String)-> String{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<SignUp2 xmlns=\"http://tempuri.org/\">"
soapReqXML += "<newid>"
soapReqXML += newid
soapReqXML += "</newid>"
soapReqXML += "<name>"
soapReqXML += name
soapReqXML += "</name>"
soapReqXML += "<ID>"
soapReqXML += ID
soapReqXML += "</ID>"
soapReqXML += "<birth>"
soapReqXML += birth
soapReqXML += "</birth>"
soapReqXML += "<sex>"
soapReqXML += sex
soapReqXML += "</sex>"
soapReqXML += "<newpass>"
soapReqXML += newpass
soapReqXML += "</newpass>"
soapReqXML += "<email>"
soapReqXML += email
soapReqXML += "</email>"
soapReqXML += "<phone>"
soapReqXML += phone
soapReqXML += "</phone>"
soapReqXML += "<height>"
soapReqXML += height
soapReqXML += "</height>"
soapReqXML += "<weight>"
soapReqXML += weight
soapReqXML += "</weight>"
soapReqXML += "</SignUp2>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/SignUp2"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  ""
 }
 let returnValue:String = strVal!
   return returnValue
}
public func profile(uid:String, choose:String)-> String{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<profile xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "</profile>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/profile"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  ""
 }
 let returnValue:String = strVal!
   return returnValue
}
public func con_profile(uid:String)-> [String?]{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<con_profile xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "</con_profile>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/con_profile"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVals :[String?] = stringArrFromXML(data : responseData);
 var vals = [String?]()
 for i in 0  ..< strVals.count {
    let xVal =  strVals[i]
    vals.append(xVal) 
 }
 let returnValue:[String?] = vals 
   return returnValue
}
public func update_profile(uid:String, choose:String, email:String, phone:String, height:String, weight:String, password:String, newpassword:String, onoff1:String, onoff2:String, onoff3:String, onoff4:String)-> Bool{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<update_profile xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "<email>"
soapReqXML += email
soapReqXML += "</email>"
soapReqXML += "<phone>"
soapReqXML += phone
soapReqXML += "</phone>"
soapReqXML += "<height>"
soapReqXML += height
soapReqXML += "</height>"
soapReqXML += "<weight>"
soapReqXML += weight
soapReqXML += "</weight>"
soapReqXML += "<password>"
soapReqXML += password
soapReqXML += "</password>"
soapReqXML += "<newpassword>"
soapReqXML += newpassword
soapReqXML += "</newpassword>"
soapReqXML += "<onoff1>"
soapReqXML += onoff1
soapReqXML += "</onoff1>"
soapReqXML += "<onoff2>"
soapReqXML += onoff2
soapReqXML += "</onoff2>"
soapReqXML += "<onoff3>"
soapReqXML += onoff3
soapReqXML += "</onoff3>"
soapReqXML += "<onoff4>"
soapReqXML += onoff4
soapReqXML += "</onoff4>"
soapReqXML += "</update_profile>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/update_profile"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  false
 }
 let returnValue:Bool = strVal!.lowercased() == "true" 
   return returnValue
}
public func update_profile2(uid:String, choose:String, email:String, phone:String, height:String, weight:String, password:String, newpassword:String, n1:String, n2:String, n3:String, n4:String)-> String{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<update_profile2 xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "<email>"
soapReqXML += email
soapReqXML += "</email>"
soapReqXML += "<phone>"
soapReqXML += phone
soapReqXML += "</phone>"
soapReqXML += "<height>"
soapReqXML += height
soapReqXML += "</height>"
soapReqXML += "<weight>"
soapReqXML += weight
soapReqXML += "</weight>"
soapReqXML += "<password>"
soapReqXML += password
soapReqXML += "</password>"
soapReqXML += "<newpassword>"
soapReqXML += newpassword
soapReqXML += "</newpassword>"
soapReqXML += "<n1>"
soapReqXML += n1
soapReqXML += "</n1>"
soapReqXML += "<n2>"
soapReqXML += n2
soapReqXML += "</n2>"
soapReqXML += "<n3>"
soapReqXML += n3
soapReqXML += "</n3>"
soapReqXML += "<n4>"
soapReqXML += n4
soapReqXML += "</n4>"
soapReqXML += "</update_profile2>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/update_profile2"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  ""
 }
 let returnValue:String = strVal!
   return returnValue
}
public func set_Content(User1:String, User2:String)-> String{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<set_Content xmlns=\"http://tempuri.org/\">"
soapReqXML += "<User1>"
soapReqXML += User1
soapReqXML += "</User1>"
soapReqXML += "<User2>"
soapReqXML += User2
soapReqXML += "</User2>"
soapReqXML += "</set_Content>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/set_Content"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  ""
 }
 let returnValue:String = strVal!
   return returnValue
}
public func Insert_Content(User1:String, User2:String, User1身分:String, User2身分:String)-> Bool{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Insert_Content xmlns=\"http://tempuri.org/\">"
soapReqXML += "<User1>"
soapReqXML += User1
soapReqXML += "</User1>"
soapReqXML += "<User2>"
soapReqXML += User2
soapReqXML += "</User2>"
soapReqXML += "<User1身分>"
soapReqXML += User1身分
soapReqXML += "</User1身分>"
soapReqXML += "<User2身分>"
soapReqXML += User2身分
soapReqXML += "</User2身分>"
soapReqXML += "</Insert_Content>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Insert_Content"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  false
 }
 let returnValue:Bool = strVal!.lowercased() == "true" 
   return returnValue
}
public func limit(choose:String)-> String{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<limit xmlns=\"http://tempuri.org/\">"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "</limit>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/limit"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  ""
 }
 let returnValue:String = strVal!
   return returnValue
}
public func Test_BP(uid:String, choose:String, Startday:String, Endday:String)-> [String?]{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Test_BP xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "<Startday>"
soapReqXML += Startday
soapReqXML += "</Startday>"
soapReqXML += "<Endday>"
soapReqXML += Endday
soapReqXML += "</Endday>"
soapReqXML += "</Test_BP>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Test_BP"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVals :[String?] = stringArrFromXML(data : responseData);
 var vals = [String?]()
 for i in 0  ..< strVals.count {
    let xVal =  strVals[i]
    vals.append(xVal) 
 }
 let returnValue:[String?] = vals 
   return returnValue
}
public func Test_HR(uid:String, choose:String, Startday:String, Endday:String)-> [String?]{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Test_HR xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "<Startday>"
soapReqXML += Startday
soapReqXML += "</Startday>"
soapReqXML += "<Endday>"
soapReqXML += Endday
soapReqXML += "</Endday>"
soapReqXML += "</Test_HR>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Test_HR"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVals :[String?] = stringArrFromXML(data : responseData);
 var vals = [String?]()
 for i in 0  ..< strVals.count {
    let xVal =  strVals[i]
    vals.append(xVal) 
 }
 let returnValue:[String?] = vals 
   return returnValue
}
public func Test_Temp(uid:String, choose:String, Startday:String, Endday:String)-> [String?]{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Test_Temp xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "<Startday>"
soapReqXML += Startday
soapReqXML += "</Startday>"
soapReqXML += "<Endday>"
soapReqXML += Endday
soapReqXML += "</Endday>"
soapReqXML += "</Test_Temp>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Test_Temp"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVals :[String?] = stringArrFromXML(data : responseData);
 var vals = [String?]()
 for i in 0  ..< strVals.count {
    let xVal =  strVals[i]
    vals.append(xVal) 
 }
 let returnValue:[String?] = vals 
   return returnValue
}
public func Test_SpO2(uid:String, choose:String, Startday:String, Endday:String)-> [String?]{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Test_SpO2 xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "<Startday>"
soapReqXML += Startday
soapReqXML += "</Startday>"
soapReqXML += "<Endday>"
soapReqXML += Endday
soapReqXML += "</Endday>"
soapReqXML += "</Test_SpO2>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Test_SpO2"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVals :[String?] = stringArrFromXML(data : responseData);
 var vals = [String?]()
 for i in 0  ..< strVals.count {
    let xVal =  strVals[i]
    vals.append(xVal) 
 }
 let returnValue:[String?] = vals 
   return returnValue
}
public func Test_Exercise(uid:String, choose:String, Startday:String, Endday:String)-> [String?]{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Test_Exercise xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "<Startday>"
soapReqXML += Startday
soapReqXML += "</Startday>"
soapReqXML += "<Endday>"
soapReqXML += Endday
soapReqXML += "</Endday>"
soapReqXML += "</Test_Exercise>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Test_Exercise"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVals :[String?] = stringArrFromXML(data : responseData);
 var vals = [String?]()
 for i in 0  ..< strVals.count {
    let xVal =  strVals[i]
    vals.append(xVal) 
 }
 let returnValue:[String?] = vals 
   return returnValue
}
public func Test_Sleep(uid:String, choose:String, Startday:String, Endday:String)-> [String?]{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Test_Sleep xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "<Startday>"
soapReqXML += Startday
soapReqXML += "</Startday>"
soapReqXML += "<Endday>"
soapReqXML += Endday
soapReqXML += "</Endday>"
soapReqXML += "</Test_Sleep>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Test_Sleep"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVals :[String?] = stringArrFromXML(data : responseData);
 var vals = [String?]()
 for i in 0  ..< strVals.count {
    let xVal =  strVals[i]
    vals.append(xVal) 
 }
 let returnValue:[String?] = vals 
   return returnValue
}
public func Test_Food(uid:String, choose:String, Startday:String, Endday:String)-> [String?]{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Test_Food xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "<Startday>"
soapReqXML += Startday
soapReqXML += "</Startday>"
soapReqXML += "<Endday>"
soapReqXML += Endday
soapReqXML += "</Endday>"
soapReqXML += "</Test_Food>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Test_Food"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVals :[String?] = stringArrFromXML(data : responseData);
 var vals = [String?]()
 for i in 0  ..< strVals.count {
    let xVal =  strVals[i]
    vals.append(xVal) 
 }
 let returnValue:[String?] = vals 
   return returnValue
}
public func Test_Poo(uid:String, choose:String, Startday:String, Endday:String)-> [String?]{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Test_Poo xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "<Startday>"
soapReqXML += Startday
soapReqXML += "</Startday>"
soapReqXML += "<Endday>"
soapReqXML += Endday
soapReqXML += "</Endday>"
soapReqXML += "</Test_Poo>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Test_Poo"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVals :[String?] = stringArrFromXML(data : responseData);
 var vals = [String?]()
 for i in 0  ..< strVals.count {
    let xVal =  strVals[i]
    vals.append(xVal) 
 }
 let returnValue:[String?] = vals 
   return returnValue
}
public func Test_Red(uid:String, choose:String, Startday:String, Endday:String)-> [String?]{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Test_Red xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "<Startday>"
soapReqXML += Startday
soapReqXML += "</Startday>"
soapReqXML += "<Endday>"
soapReqXML += Endday
soapReqXML += "</Endday>"
soapReqXML += "</Test_Red>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Test_Red"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVals :[String?] = stringArrFromXML(data : responseData);
 var vals = [String?]()
 for i in 0  ..< strVals.count {
    let xVal =  strVals[i]
    vals.append(xVal) 
 }
 let returnValue:[String?] = vals 
   return returnValue
}
public func Test_air(uid:String)-> String{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Test_air xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "</Test_air>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Test_air"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  ""
 }
 let returnValue:String = strVal!
   return returnValue
}
public func Total_BP(uid:String, choose:String, StartTime:String, EndTime:String)-> [String?]{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Total_BP xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "<StartTime>"
soapReqXML += StartTime
soapReqXML += "</StartTime>"
soapReqXML += "<EndTime>"
soapReqXML += EndTime
soapReqXML += "</EndTime>"
soapReqXML += "</Total_BP>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Total_BP"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVals :[String?] = stringArrFromXML(data : responseData);
 var vals = [String?]()
 for i in 0  ..< strVals.count {
    let xVal =  strVals[i]
    vals.append(xVal) 
 }
 let returnValue:[String?] = vals 
   return returnValue
}
public func Total_HR(uid:String, choose:String, StartTime:String, EndTime:String)-> [String?]{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Total_HR xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "<StartTime>"
soapReqXML += StartTime
soapReqXML += "</StartTime>"
soapReqXML += "<EndTime>"
soapReqXML += EndTime
soapReqXML += "</EndTime>"
soapReqXML += "</Total_HR>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Total_HR"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVals :[String?] = stringArrFromXML(data : responseData);
 var vals = [String?]()
 for i in 0  ..< strVals.count {
    let xVal =  strVals[i]
    vals.append(xVal) 
 }
 let returnValue:[String?] = vals 
   return returnValue
}
public func Total_SpO2(uid:String, choose:String, StartTime:String, EndTime:String)-> [String?]{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Total_SpO2 xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "<StartTime>"
soapReqXML += StartTime
soapReqXML += "</StartTime>"
soapReqXML += "<EndTime>"
soapReqXML += EndTime
soapReqXML += "</EndTime>"
soapReqXML += "</Total_SpO2>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Total_SpO2"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVals :[String?] = stringArrFromXML(data : responseData);
 var vals = [String?]()
 for i in 0  ..< strVals.count {
    let xVal =  strVals[i]
    vals.append(xVal) 
 }
 let returnValue:[String?] = vals 
   return returnValue
}
public func Total_Temp(uid:String, choose:String, StartTime:String, EndTime:String)-> [String?]{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Total_Temp xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "<StartTime>"
soapReqXML += StartTime
soapReqXML += "</StartTime>"
soapReqXML += "<EndTime>"
soapReqXML += EndTime
soapReqXML += "</EndTime>"
soapReqXML += "</Total_Temp>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Total_Temp"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVals :[String?] = stringArrFromXML(data : responseData);
 var vals = [String?]()
 for i in 0  ..< strVals.count {
    let xVal =  strVals[i]
    vals.append(xVal) 
 }
 let returnValue:[String?] = vals 
   return returnValue
}
public func IOS_addBP(uid:String, 收縮壓:String, 舒縮壓:String)-> Bool{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<IOS_addBP xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<收縮壓>"
soapReqXML += 收縮壓
soapReqXML += "</收縮壓>"
soapReqXML += "<舒縮壓>"
soapReqXML += 舒縮壓
soapReqXML += "</舒縮壓>"
soapReqXML += "</IOS_addBP>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/IOS_addBP"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  false
 }
 let returnValue:Bool = strVal!.lowercased() == "true" 
   return returnValue
}
public func IOS_addHR(uid:String, 脈搏:String)-> Bool{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<IOS_addHR xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<脈搏>"
soapReqXML += 脈搏
soapReqXML += "</脈搏>"
soapReqXML += "</IOS_addHR>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/IOS_addHR"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  false
 }
 let returnValue:Bool = strVal!.lowercased() == "true" 
   return returnValue
}
public func IOS_addTemp(uid:String, 體溫:String)-> Bool{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<IOS_addTemp xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<體溫>"
soapReqXML += 體溫
soapReqXML += "</體溫>"
soapReqXML += "</IOS_addTemp>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/IOS_addTemp"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  false
 }
 let returnValue:Bool = strVal!.lowercased() == "true" 
   return returnValue
}
public func IOS_addSpO2(uid:String, 血氧:String)-> Bool{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<IOS_addSpO2 xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<血氧>"
soapReqXML += 血氧
soapReqXML += "</血氧>"
soapReqXML += "</IOS_addSpO2>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/IOS_addSpO2"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  false
 }
 let returnValue:Bool = strVal!.lowercased() == "true" 
   return returnValue
}
public func IOS_addExercise(uid:String, 運動強度:String, 運動時長:String)-> Bool{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<IOS_addExercise xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<運動強度>"
soapReqXML += 運動強度
soapReqXML += "</運動強度>"
soapReqXML += "<運動時長>"
soapReqXML += 運動時長
soapReqXML += "</運動時長>"
soapReqXML += "</IOS_addExercise>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/IOS_addExercise"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  false
 }
 let returnValue:Bool = strVal!.lowercased() == "true" 
   return returnValue
}
public func IOS_addSleep(uid:String, 開始結束:String)-> Bool{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<IOS_addSleep xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<開始結束>"
soapReqXML += 開始結束
soapReqXML += "</開始結束>"
soapReqXML += "</IOS_addSleep>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/IOS_addSleep"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  false
 }
 let returnValue:Bool = strVal!.lowercased() == "true" 
   return returnValue
}
public func IOS_addPoo(uid:String, 排便:String)-> Bool{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<IOS_addPoo xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<排便>"
soapReqXML += 排便
soapReqXML += "</排便>"
soapReqXML += "</IOS_addPoo>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/IOS_addPoo"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  false
 }
 let returnValue:Bool = strVal!.lowercased() == "true" 
   return returnValue
}
public func IOS_addFood(uid:String, 早餐熱量:String, 午餐熱量:String, 晚餐熱量:String)-> Bool{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<IOS_addFood xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<早餐熱量>"
soapReqXML += 早餐熱量
soapReqXML += "</早餐熱量>"
soapReqXML += "<午餐熱量>"
soapReqXML += 午餐熱量
soapReqXML += "</午餐熱量>"
soapReqXML += "<晚餐熱量>"
soapReqXML += 晚餐熱量
soapReqXML += "</晚餐熱量>"
soapReqXML += "</IOS_addFood>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/IOS_addFood"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  false
 }
 let returnValue:Bool = strVal!.lowercased() == "true" 
   return returnValue
}
public func Insert_chat(num:String, topic:String, body:String)-> Int{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Insert_chat xmlns=\"http://tempuri.org/\">"
soapReqXML += "<num>"
soapReqXML += num
soapReqXML += "</num>"
soapReqXML += "<topic>"
soapReqXML += topic
soapReqXML += "</topic>"
soapReqXML += "<body>"
soapReqXML += body
soapReqXML += "</body>"
soapReqXML += "</Insert_chat>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Insert_chat"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML( data : responseData);
 if strVal == nil {

    return  0
 }
 let returnValue:Int = strVal!.toInt()!
   return returnValue
}
public func All_chat(num:String)-> [String?]{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<All_chat xmlns=\"http://tempuri.org/\">"
soapReqXML += "<num>"
soapReqXML += num
soapReqXML += "</num>"
soapReqXML += "</All_chat>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/All_chat"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVals :[String?] = stringArrFromXML(data : responseData);
 var vals = [String?]()
 for i in 0  ..< strVals.count {
    let xVal =  strVals[i]
    vals.append(xVal) 
 }
 let returnValue:[String?] = vals 
   return returnValue
}
public func One_chat(id:String)-> String{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<One_chat xmlns=\"http://tempuri.org/\">"
soapReqXML += "<id>"
soapReqXML += id
soapReqXML += "</id>"
soapReqXML += "</One_chat>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/One_chat"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  ""
 }
 let returnValue:String = strVal!
   return returnValue
}
public func update_gps(uid:String, 經度:String, 緯度:String)-> Bool{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<update_gps xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<經度>"
soapReqXML += 經度
soapReqXML += "</經度>"
soapReqXML += "<緯度>"
soapReqXML += 緯度
soapReqXML += "</緯度>"
soapReqXML += "</update_gps>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/update_gps"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  false
 }
 let returnValue:Bool = strVal!.lowercased() == "true" 
   return returnValue
}
public func select_Pulse(num:String, startday:String, endday:String, choose:String)-> String{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<select_Pulse xmlns=\"http://tempuri.org/\">"
soapReqXML += "<num>"
soapReqXML += num
soapReqXML += "</num>"
soapReqXML += "<startday>"
soapReqXML += startday
soapReqXML += "</startday>"
soapReqXML += "<endday>"
soapReqXML += endday
soapReqXML += "</endday>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "</select_Pulse>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/select_Pulse"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  ""
 }
 let returnValue:String = strVal!
   return returnValue
}
public func HelloWorld()-> String{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<HelloWorld xmlns=\"http://tempuri.org/\">"
soapReqXML += "</HelloWorld>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/HelloWorld"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  ""
 }
 let returnValue:String = strVal!
   return returnValue
}
public func Json_newBP(uid:String, choose:String, Startday:String, Endday:String)-> String{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Json_newBP xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "<Startday>"
soapReqXML += Startday
soapReqXML += "</Startday>"
soapReqXML += "<Endday>"
soapReqXML += Endday
soapReqXML += "</Endday>"
soapReqXML += "</Json_newBP>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Json_newBP"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  ""
 }
 let returnValue:String = strVal!
   return returnValue
}
public func Json_newHR(uid:String, choose:String, Startday:String, Endday:String)-> String{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Json_newHR xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "<Startday>"
soapReqXML += Startday
soapReqXML += "</Startday>"
soapReqXML += "<Endday>"
soapReqXML += Endday
soapReqXML += "</Endday>"
soapReqXML += "</Json_newHR>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Json_newHR"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  ""
 }
 let returnValue:String = strVal!
   return returnValue
}
public func Json_newTemp(uid:String, choose:String, Startday:String, Endday:String)-> String{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Json_newTemp xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "<Startday>"
soapReqXML += Startday
soapReqXML += "</Startday>"
soapReqXML += "<Endday>"
soapReqXML += Endday
soapReqXML += "</Endday>"
soapReqXML += "</Json_newTemp>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Json_newTemp"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  ""
 }
 let returnValue:String = strVal!
   return returnValue
}
public func Json_newSpO2(uid:String, choose:String, Startday:String, Endday:String)-> String{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Json_newSpO2 xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "<Startday>"
soapReqXML += Startday
soapReqXML += "</Startday>"
soapReqXML += "<Endday>"
soapReqXML += Endday
soapReqXML += "</Endday>"
soapReqXML += "</Json_newSpO2>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Json_newSpO2"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  ""
 }
 let returnValue:String = strVal!
   return returnValue
}
public func Json_newExercise(uid:String, choose:String, Startday:String, Endday:String)-> String{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Json_newExercise xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "<Startday>"
soapReqXML += Startday
soapReqXML += "</Startday>"
soapReqXML += "<Endday>"
soapReqXML += Endday
soapReqXML += "</Endday>"
soapReqXML += "</Json_newExercise>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Json_newExercise"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  ""
 }
 let returnValue:String = strVal!
   return returnValue
}
public func Json_newSleep(uid:String, choose:String, Startday:String, Endday:String)-> String{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Json_newSleep xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "<Startday>"
soapReqXML += Startday
soapReqXML += "</Startday>"
soapReqXML += "<Endday>"
soapReqXML += Endday
soapReqXML += "</Endday>"
soapReqXML += "</Json_newSleep>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Json_newSleep"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  ""
 }
 let returnValue:String = strVal!
   return returnValue
}
public func Json_newFood(uid:String, choose:String, Startday:String, Endday:String)-> String{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Json_newFood xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "<Startday>"
soapReqXML += Startday
soapReqXML += "</Startday>"
soapReqXML += "<Endday>"
soapReqXML += Endday
soapReqXML += "</Endday>"
soapReqXML += "</Json_newFood>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Json_newFood"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  ""
 }
 let returnValue:String = strVal!
   return returnValue
}
public func Json_newPoo(uid:String, choose:String, Startday:String, Endday:String)-> String{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Json_newPoo xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "<Startday>"
soapReqXML += Startday
soapReqXML += "</Startday>"
soapReqXML += "<Endday>"
soapReqXML += Endday
soapReqXML += "</Endday>"
soapReqXML += "</Json_newPoo>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Json_newPoo"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  ""
 }
 let returnValue:String = strVal!
   return returnValue
}
public func Json_newRed(uid:String, choose:String, Startday:String, Endday:String)-> String{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Json_newRed xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "<Startday>"
soapReqXML += Startday
soapReqXML += "</Startday>"
soapReqXML += "<Endday>"
soapReqXML += Endday
soapReqXML += "</Endday>"
soapReqXML += "</Json_newRed>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Json_newRed"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  ""
 }
 let returnValue:String = strVal!
   return returnValue
}
public func Json_newair(uid:String)-> String{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Json_newair xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "</Json_newair>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Json_newair"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  ""
 }
 let returnValue:String = strVal!
   return returnValue
}
public func Json_totalSpO2(uid:String, choose:String, StartTime:String, EndTime:String)-> String{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Json_totalSpO2 xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "<StartTime>"
soapReqXML += StartTime
soapReqXML += "</StartTime>"
soapReqXML += "<EndTime>"
soapReqXML += EndTime
soapReqXML += "</EndTime>"
soapReqXML += "</Json_totalSpO2>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Json_totalSpO2"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  ""
 }
 let returnValue:String = strVal!
   return returnValue
}
public func Json_totalHR(uid:String, choose:String, StartTime:String, EndTime:String)-> String{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Json_totalHR xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "<StartTime>"
soapReqXML += StartTime
soapReqXML += "</StartTime>"
soapReqXML += "<EndTime>"
soapReqXML += EndTime
soapReqXML += "</EndTime>"
soapReqXML += "</Json_totalHR>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Json_totalHR"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  ""
 }
 let returnValue:String = strVal!
   return returnValue
}
public func Json_totalTemp(uid:String, choose:String, StartTime:String, EndTime:String)-> String{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Json_totalTemp xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "<StartTime>"
soapReqXML += StartTime
soapReqXML += "</StartTime>"
soapReqXML += "<EndTime>"
soapReqXML += EndTime
soapReqXML += "</EndTime>"
soapReqXML += "</Json_totalTemp>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Json_totalTemp"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  ""
 }
 let returnValue:String = strVal!
   return returnValue
}
public func Json_totalBP(uid:String, choose:String, StartTime:String, EndTime:String)-> String{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Json_totalBP xmlns=\"http://tempuri.org/\">"
soapReqXML += "<uid>"
soapReqXML += uid
soapReqXML += "</uid>"
soapReqXML += "<choose>"
soapReqXML += choose
soapReqXML += "</choose>"
soapReqXML += "<StartTime>"
soapReqXML += StartTime
soapReqXML += "</StartTime>"
soapReqXML += "<EndTime>"
soapReqXML += EndTime
soapReqXML += "</EndTime>"
soapReqXML += "</Json_totalBP>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Json_totalBP"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  ""
 }
 let returnValue:String = strVal!
   return returnValue
}
public func Json_Allchat(num:String)-> String{
   var soapReqXML:String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"

soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
soapReqXML += " <soap:Body>"
soapReqXML += "<Json_Allchat xmlns=\"http://tempuri.org/\">"
soapReqXML += "<num>"
soapReqXML += num
soapReqXML += "</num>"
soapReqXML += "</Json_Allchat>"
soapReqXML += "</soap:Body>"
soapReqXML += "</soap:Envelope>"

   let soapAction :String = "http://tempuri.org/Json_Allchat"

   let responseData:Data = SoapHttpClient.callWS(Host : self.Host,WebServiceUrl:self.Url,SoapAction:soapAction,SoapMessage:soapReqXML)
 let strVal :String? = stringFromXML(data : responseData);
 if strVal == nil {

    return  ""
 }
 let returnValue:String = strVal!
   return returnValue
}
}