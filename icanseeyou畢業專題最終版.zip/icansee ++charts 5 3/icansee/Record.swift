//
//  Record.swift
//  icansee
//
//  Created by WenLi Lee on 2020/11/10.
//

import SwiftUI
import Combine



public struct Record: View {
    @Binding var user : String
    var re = [
        //生理數值-----------------------------------------------------------------------
        RecordView(id: 0, category: "生理數值", title: "心跳", image: "heart", data: "\(res_HR)"+"bpm", suggest: "Healthy\n80-120"),
        RecordView(id: 1, category: "生理數值", title: "血壓", image: "Blood Pressure", data: "\(res_BP)", suggest: "收縮壓＜120\n舒張壓＜80"),
        RecordView(id: 2, category: "生理數值", title: "血氧", image: "Blood SpO2", data: "\(res_SpO2) "+"％", suggest: "Healthy\n95∼100％"),
        RecordView(id: 3, category: "生理數值", title: "體溫", image: "temp", data: "\(res_Temp) "+" °C", suggest: "\n"+"38°C體溫過高！"),
        //-----------------------------------------------------------------------------
        RecordView(id: 4, category: "運動", title: "運動", image: "energy", data: "\(res_Exercise) "+"小時", suggest: "Daily Goal\n900 kcal"),
        RecordView(id: 5, category: "睡眠", title: "睡眠", image: "sleep", data: "\(res_Sleep) "+"小時", suggest: "eyes: 8hr\nDaily sleep : 8hr"),
        RecordView(id: 6, category: "排便", title: "排便", image: "poopoo", data: "\(res_Poo) ", suggest: "正常人每天會排便1到2次"),
        RecordView(id: 7, category: "熱量", title: "三餐熱量", image: "food", data: "\(res_Food) "+" kcal", suggest: "Daily Goal\n1500 kcal"),
    ]
    public var body: some View {
        LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 20), count: 2),spacing: 20){
            ForEach(re){record in
                 NavigationLink(destination: DetailView(record: record, user: $user))
                {
                    RecordCardView( record: record, user: $user)
                }
            }//將re的陣列放入
        }
        .padding(.top)
    }
}

public struct Record_Previews: PreviewProvider {
    
    public static var previews: some View {
        Record(user: .constant(""))
    }
}

//MARK:- 一格一格框框裡要顯示的字跟圖
public struct RecordCardView : View {
    
    var record : RecordView
    @Binding var user : String //>>顯示資料的user
   
    public var body: some View{
        //每個框框的樣式
        ZStack(alignment: Alignment(horizontal: .trailing, vertical: .top)){
            
            VStack(alignment: .leading, spacing: 20) {
             
                Text(record.title)
                    .foregroundColor(.white)
                
                Text(record.data)
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    .padding(.top,10)
                
                HStack{
                    
                    Spacer(minLength: 0)
                    Text(record.suggest)
                        .foregroundColor(.white)
                }
            }
            .padding()
            .background(Color(record.image))
            .cornerRadius(20)
            .shadow(color: Color.black.opacity(0.2), radius: 5, x: 0, y: 5)
            
            // top Image
            Image(record.image)
                .renderingMode(.template)
                .foregroundColor(.white)
                .padding()
                .background(Color.white.opacity(0.12))
                .clipShape(Circle())
        }
        
        
    }
    
}

//MARK:- 每個框框裡的型別
struct RecordView : Identifiable {
    var id : Int
    var category: String
    var title : String
    var image : String
    var data: String
    var suggest : String
}


//連接資料庫
let re = WebService()
let first:CharacterSet = ["：",","];



//MARK:-new BP ??????????
let w_BP = re.Test_BP(uid: "Biggg", choose: "new", Startday: "", Endday: "")
let data_BP = String(w_BP[0]!)
let first2 = data_BP.components(separatedBy: first)
let res_BP = first2[1]+" / "+first2[3]
//MARK:-new HR
let w_HR = re.Test_HR(uid: "Biggg", choose: "new", Startday: "", Endday: "")
let data_HR = String(w_HR[0]!)
let first2_HR = data_HR.components(separatedBy: first)
let res_HR = first2_HR[1]
//MARK:-new SpO2
let w_SpO2 = re.Test_SpO2(uid: "Biggg", choose: "new", Startday: "", Endday: "")
let data_SpO2 = String(w_SpO2[0]!)
let first2_SpO2 = data_SpO2.components(separatedBy: first)
let res_SpO2 = first2_SpO2[1]
//MARK:-new Temp
let w_Temp = re.Test_Temp(uid: "Biggg", choose: "new", Startday: "", Endday: "")
let data_Temp = String(w_Temp[0]!)
let first2_Temp = data_Temp.components(separatedBy: first)
let res_Temp = first2_Temp[1]
//MARK:-new Exercise
let w_Exercise = re.Test_Exercise(uid: "Biggg", choose: "new", Startday: "", Endday: "")
let data_Exercise = String(w_Exercise[0]!)
let first2_Exercise = data_Exercise.components(separatedBy: first)
let res_Exercise = first2_Exercise[1]
//MARK:-new Sleep
let w_Sleep = re.Test_Sleep(uid: "Biggg", choose: "new", Startday: "", Endday: "")
let data_Sleep = String(w_Sleep[0]!)
let first2_Sleep = data_Sleep.components(separatedBy: first)
let res_Sleep = first2_Sleep[1]
//MARK:-new Poo
let w_Poo = re.Test_Poo(uid: "Biggg", choose: "new", Startday: "", Endday: "")
let data_Poo = String(w_Poo[0]!)
let first2_Poo = data_Poo.components(separatedBy: first)
let res_Poo = first2_Poo[1]
//MARK:-new Food
let w_Food = re.Test_Food(uid: "Biggg", choose: "new", Startday: "", Endday: "")
let data_Food = String(w_Food[0]!)
let first2_Food = data_Food.components(separatedBy: first)
let res_Food = first2_Food[7]




//MARK:- 顯示最新一筆資料的陣列
var records = [
    //生理數值-----------------------------------------------------------------------
    RecordView(id: 0, category: "生理數值", title: "心跳", image: "heart", data: "\(res_HR)"+"bpm", suggest: "Healthy\n80-120"),
    RecordView(id: 1, category: "生理數值", title: "血壓", image: "Blood Pressure", data: "\(res_BP)", suggest: "收縮壓＜120\n舒張壓＜80"),
    RecordView(id: 2, category: "生理數值", title: "血氧", image: "Blood SpO2", data: "\(res_SpO2) "+"％", suggest: "Healthy\n95∼100％"),
    RecordView(id: 3, category: "生理數值", title: "體溫", image: "temp", data: "\(res_Temp) "+" °C", suggest: "\n"+"38°C體溫過高！"),
    //-----------------------------------------------------------------------------
    
    RecordView(id: 4, category: "運動", title: "運動", image: "energy", data: "\(res_Exercise) "+"小時", suggest: "Daily Goal\n900 kcal"),
    RecordView(id: 5, category: "睡眠", title: "睡眠", image: "sleep", data: "\(res_Sleep) "+"小時", suggest: "eyes: 8hr\nDaily sleep : 8hr"),
    RecordView(id: 6, category: "排便", title: "排便", image: "poopoo", data: "\(res_Poo) ", suggest: "正常人每天會排便1到2次"),
    RecordView(id: 7, category: "熱量", title: "三餐熱量", image: "food", data: "\(res_Food) "+" kcal", suggest: "Daily Goal\n1500 kcal"),
    
]
//MARK:- 新增資料的頁面 - 心跳血氧血壓體溫 運動三餐排便...

struct DetailView : View {
    var alert: Alert { Alert(title: Text("新增"), message: Text("新增成功"), dismissButton: .cancel(Text("OK")))}
    var alert2: Alert { Alert(title: Text("新增"), message: Text("新增失敗"), dismissButton: .cancel(Text("OK"))) }
    var alert3: Alert { Alert(title: Text("新增"), message: Text("設置成功！起床之後記得再按下按鈕"), dismissButton: .cancel(Text("OK"))) }
    
    var record : RecordView
    var strrength = ["費","中","輕","坐"]
    var sport = ["走路", "爬樓梯", "跑步", "騎腳踏車","球類運動"]
    @Binding var user : String
    @State var hourSelection = 0
    @State var minuteSelection = 0
    @EnvironmentObject var obs : chatobser
    @ObservedObject var now = settings_()
    @State private var sportAmount = 0.5
    @State var selectedsport = "走路"
    @State var selectedStr = "費"
    @State var signUp = false
    @State var heart = ""
    @State var sugar = ""
    @State var BP = ""
    @State var BPP = ""
    @State var SpO2 = ""
    @State var temp = ""
    @State var rePass = ""
    @State var breakfast = ""
    @State var lunch = ""
    @State var dinner = ""
    @State var showAlert = false//登入錯
    @State var currentlySelectedId: Int = 0
    @State private var isActive: Bool = false
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    @State var selectedDate = Date()
    //選日期-----------------
    func showDatePickerAlert() {
        let alertVC = UIAlertController(title: "\n\n", message: nil, preferredStyle: .actionSheet)
        let datePicker: UIDatePicker = UIDatePicker()
        alertVC.view.addSubview(datePicker)
        
        let okAction = UIAlertAction(title: "OK", style: .default) { _ in
            self.selectedDate = datePicker.date
        }
        alertVC.addAction(okAction)
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)
        alertVC.addAction(cancelAction)
        
        if let viewController = UIApplication.shared.windows.first?.rootViewController {
            viewController.present(alertVC, animated: true, completion: nil)
        }
    }
    static let formatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.setLocalizedDateFormatFromTemplate("yyMMdd")
        return formatter
    }() //日期顯示yyMMdd
    
    
    var body: some View{
        
        ZStack(alignment: .top){
            //MARK:- 生理數值
            VStack{
                if (record.category == "生理數值"){
                    VStack(alignment: .leading, spacing: 25) {
                        
                        Text("新增"+"生理數值_"+"\(record.title)")
                            .font(.system(size: 25, weight: .bold))
                            .foregroundColor(Color("Color1"))
                        
                        VStack{
                            
                            if (record.title == "心跳")
                            {
                                TextField("心跳", text: $heart).autocapitalization(.none)
                                    .foregroundColor(Color(.black))
                                    .keyboardType(.numberPad)
                                Divider()
                                
                            }
                            else if (record.title == "血氧")
                            {
                                TextField("血氧", text: $SpO2).autocapitalization(.none)
                                    .foregroundColor(Color(.black))
                                    .keyboardType(.numberPad)
                                Divider()
                            }
                            else if (record.title == "血壓")
                            {
                                Text("收縮壓")//>>新增資料的user
                                    .font(.system(size: 25, weight: .bold))
                                    .foregroundColor(Color("Color1"))
                                    .padding(.top,10)
                                
                                TextField("收縮壓", text: $BP).autocapitalization(.none)
                                    
                                    .foregroundColor(Color(.black))
                                    .keyboardType(.numberPad)
                                Divider()
                                
                                Text("舒張壓")//>>新增資料的user
                                    .font(.system(size: 25, weight: .bold))
                                    .foregroundColor(Color("Color1"))
                                    .padding(.top,10)
                                
                                TextField("舒張壓", text: $BPP).autocapitalization(.none)
                                    .foregroundColor(Color(.black))
                                    .keyboardType(.numberPad)
                                Divider()
                                
                            }
                            else if (record.title == "體溫")
                            {
                                TextField("體溫", text: $temp).autocapitalization(.none)
                                    .foregroundColor(Color(.black))
                                    .keyboardType(.decimalPad)
                                Divider()
                            }
                            else
                            {
                                TextField("血糖", text: $sugar).autocapitalization(.none)
                                    .foregroundColor(Color(.black))
                                    .keyboardType(.numberPad)
                                Divider()
                            }
                        }
                        //MARK:- 儲存生理數值save
                        VStack{
                            
                            NavigationLink(destination: TabBarView(user: $user) , isActive: self.$isActive) {
                                Text("")
                            }
                            Button(action: {
                                if (record.title == "心跳")
                                {
                                    let re = WebService();
                                    let w1 = re.IOS_addHR(uid: user, 脈搏: heart)
                                    
                                    if w1 == true
                                    {
                                        
                                        self.showAlert = true
                                        
                                    }
                                    else if w1 == false
                                    {
                                        self.showAlert = true
                                    }
                                }
                                else if (record.title == "血氧")
                                {
                                    let re = WebService();
                                    let w1 = re.IOS_addSpO2(uid: user, 血氧: SpO2)
                                    if w1 == true
                                    {
                                        
                                        self.isActive = true
                                        self.showAlert = true
                                    }
                                    else if w1 == false
                                    {
                                        self.showAlert = true
                                    }
                                }
                                else if (record.title == "血壓")
                                {
                                    let re = WebService();
                                    let w1 = re.IOS_addBP(uid: user, 收縮壓: BP, 舒縮壓: BPP)
                                    if w1 == true
                                    {
                                        self.isActive = true
                                        self.showAlert = true
                                    }
                                    else if w1 == false
                                    {
                                        self.showAlert = true
                                    }
                                }
                                else if (record.title == "體溫")
                                {
                                    let re = WebService();
                                    let w1 = re.IOS_addTemp(uid: user, 體溫: temp)
                                    if w1 == true
                                    {
                                        self.isActive = true
                                        self.showAlert = true
                                    }
                                    else if w1 == false
                                    {
                                        self.showAlert = true
                                    }
                                }
                            }) {
                                
                                Text("確定")
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding(.vertical)
                                    .padding(.horizontal,45)
                                    .background(Color("Color1"))
                                    .clipShape(Capsule())
                            }
                            .alert(isPresented: $showAlert, content: { self.alert })
                            
                            Spacer(minLength: 10)
                            if (record.title == "血氧")
                            {
                                Text("血氧濃度參考值")
                                Image("血氧參考").resizable()
                                    .scaledToFit()
                                HStack{
                                    Image("公告")
                                    Text("參考來源：衛福部")
                                    Link("血氧濃度標準", destination: URL(string: "https://www.hpa.gov.tw/Pages/Detail.aspx?nodeid=641&pid=1230")!).foregroundColor(.yellow)
                                }
                            }
                            else if (record.title == "血壓")
                            {
                                
                                Text("血壓參考值")
                                Image("血壓參考").resizable()
                                    .scaledToFit()
                                HStack{
                                    Image("公告")
                                    Text("參考來源：衛福部")
                                    Link("血糖血壓參考標準", destination: URL(string: "https://www.hpa.gov.tw/Pages/Detail.aspx?nodeid=641&pid=1230")!).foregroundColor(.yellow)
                                }
                            }
                            else if (record.title == "體溫")
                            {
                                Text("體溫參考值")
                                Image("體溫參考").resizable()
                                    .scaledToFit()
                                HStack{
                                    Image("公告")
                                    Text("參考來源：")
                                    Link("健康的叮嚀 打破發燒迷思", destination: URL(string: "https://www.hpa.gov.tw/Pages/Detail.aspx?nodeid=1125&pid=1610")!).foregroundColor(.yellow)
                                }
                            }
                            
                            Spacer(minLength: 0)
                            
                        }
                    }
                    .padding(.top,(UIApplication.shared.windows.first?.safeAreaInsets.top)! + 30)
                    .padding()
                    .background(Color.white.edgesIgnoringSafeArea(.all))
                    
                }
                //MARK:- 運動
                else if (record.title == "運動"){
                    
                    VStack(alignment: .leading, spacing: 25) {
                        
                        Section(header:Text("運動強度：\(selectedStr)").font(.headline)){
                            
                            HStack(spacing: 15){
                                
                                ForEach(strrength,id: \.self){i in
                                    
                                    Button(action: {
                                        selectedStr = i
                                        
                                    }) {
                                        
                                        Text("\(i)")
                                            .font(UIScreen.main.bounds.height < 750 ? .caption : .body)
                                            .foregroundColor(selectedStr == i ? .white : .black)
                                            .padding(.vertical,8)
                                            .padding(.horizontal,10)
                                            .background(
                                                ZStack{
                                                    RoundedRectangle(cornerRadius: 5)
                                                        .fill(Color("Color1").opacity(selectedStr == i ? 1 : 0))
                                                    
                                                    RoundedRectangle(cornerRadius: 5)
                                                        .stroke(Color("Color1"),lineWidth: 1)
                                                }
                                            )
                                        
                                    }
                                    
                                }
                            }
                        }
                        //運動時長-------------------------------------------------------------------------------------------
                        Section(header:Text("運動時長").font(.headline)) {
                            Stepper(value: $sportAmount, in: 0.5...8, step: 0.5){
                                Text("\(sportAmount,specifier: "%g") 小時")
                            }
                        }
                        
                        HStack{
                            
                            Spacer()
                            
                            //MARK:- 儲存運動save
                            Button(action: {
                                let re = WebService()
                                var a = ""
                                if (selectedStr == "坐")
                                {
                                    a = "1"
                                }
                                else if (selectedStr == "輕")
                                {
                                    a = "2"
                                }
                                else if (selectedStr == "中")
                                {
                                    a = "3"
                                }
                                else if (selectedStr == "費")
                                {
                                    a = "4"
                                }
                                let w1 = re.IOS_addExercise(uid: user, 運動強度: a, 運動時長: "\(sportAmount)")
                                self.showAlert = true
                            }) {
                                
                                Text("確定")
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding(.vertical)
                                    .padding(.horizontal,45)
                                    .background(Color("Color1"))
                                    .clipShape(Capsule())
                            }.alert(isPresented: $showAlert, content: { self.alert })
                            
                            
                            
                        }
                        .padding(.top)
                        HStack{
                            Image("公告")
                            Text("參考來源：衛福部")
                            Link("運動強度", destination: URL(string: "https://www.hpa.gov.tw/Pages/Detail.aspx?nodeid=571&pid=9739")!).foregroundColor(.yellow)
                        }
                        Spacer(minLength: 0)
                    }
                    .padding(.top,(UIApplication.shared.windows.first?.safeAreaInsets.top)! + 10)
                    .padding()
                    .background(Color.white.edgesIgnoringSafeArea(.all))
                    
                    
                }
                //MARK:- 睡眠時間
                else if (record.title == "睡眠"){
                    
                    VStack(alignment: .leading, spacing: 25) {
                        
                        VStack {
                            Text("紀錄說明：").font(.system(size: 25, weight: .bold))
                                .foregroundColor(Color("Color1"))
                                .padding()
                            
                            
                            Text("請先按下下方的睡覺鈕開始記錄\("\n")顯示『睡覺』：已經紀錄好睡覺的時間\("\n")顯示『起床』：已經紀錄好完整的睡眠時長")
                                .font(.system(size: 18, weight: .bold))
                                .foregroundColor(Color("Color1"))
                            
                        }
                        
                        HStack{
                            
                            Spacer()
                            
                            //MARK:- 儲存睡眠時間save
                            
                            if (now.nowTime == false){
                                Button(action: {
                                    
                                    let w1 = re.IOS_addSleep(uid: user, 開始結束: "0")
                                    now.nowTime = true
                                    self.showAlert = true
                                })
                                {
                                    Text("睡覺")
                                        .fontWeight(.bold)
                                        .foregroundColor(.white)
                                        .padding(.vertical)
                                        .padding(.horizontal,45)
                                        .background(Color("Color1"))
                                        .clipShape(Capsule())
                                    
                                }.alert(isPresented: $showAlert, content: { self.alert })
                            }
                            else
                            {
                                Button(action: {
                                    let w1 = re.IOS_addSleep(uid: user, 開始結束: "1")
                                    now.nowTime = false
                                    self.showAlert = true
                                })
                                {
                                    Text("起床")
                                        .fontWeight(.bold)
                                        .foregroundColor(.white)
                                        .padding(.vertical)
                                        .padding(.horizontal,45)
                                        .background(Color("Color1"))
                                        .clipShape(Capsule())
                                    
                                }
                                .alert(isPresented: $showAlert, content: { self.alert3 })
                            }
                            //Toggle("再點一下更改開始結束！", isOn: $nowTime)
                            Spacer()
                        }
                        .padding(.top)
                        
                        Spacer(minLength: 0)
                        
                        
                    }
                    .padding(.top,(UIApplication.shared.windows.first?.safeAreaInsets.top)! + 30)
                    .padding()
                    .background(Color.white.edgesIgnoringSafeArea(.all))
                    
                }
                //MARK:- 排便
                else if (record.title == "排便"){
                    
                    VStack(alignment: .center, spacing: 35) {
                        if(currentlySelectedId == 1){
                            Text("您的排便狀態：第一型")
                        }
                        else if(currentlySelectedId == 2){
                            Text("您的排便狀態：第二型")
                        }
                        else if(currentlySelectedId == 3){
                            Text("您的排便狀態：第三型")
                        }
                        else if(currentlySelectedId == 4){
                            Text("您的排便狀態：第四型")
                        }
                        else if(currentlySelectedId == 5){
                            Text("您的排便狀態：第五型")
                        }
                        else if(currentlySelectedId == 6){
                            Text("您的排便狀態：第六型")
                        }
                        else
                        {
                            Text("您的排便狀態：第七型")
                        }
                        
                        HStack(spacing: 35){
                            
                            //MARK:- 儲存排便save
                            
                            Button(action: {
                                if(currentlySelectedId == 1){let w1 = re.IOS_addPoo(uid: user, 排便: "1")}
                                else if(currentlySelectedId == 2){let w1 = re.IOS_addPoo(uid: user, 排便: "2")}
                                else if(currentlySelectedId == 3){let w1 = re.IOS_addPoo(uid: user, 排便: "3")}
                                else if(currentlySelectedId == 4){let w1 = re.IOS_addPoo(uid: user, 排便: "4")}
                                else if(currentlySelectedId == 5){let w1 = re.IOS_addPoo(uid: user, 排便: "5")}
                                else if(currentlySelectedId == 6){let w1 = re.IOS_addPoo(uid: user, 排便: "6")}
                                else{ let w1 = re.IOS_addPoo(uid: user, 排便: "7")}
                                self.showAlert = true
                            }) {
                                Text("確定")
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding(.vertical)
                                    .padding(.horizontal,45)
                                    .background(Color("Color1"))
                                    .clipShape(Capsule())
                                
                            }.alert(isPresented: $showAlert, content: { self.alert })
                            
                        }
                        
                        Text("請點選下圖排便的類型")
                        HStack(spacing: 20) {
                            PoopoobtnView(id: 1, currentlySelectedId: $currentlySelectedId, text: "poo1")
                            PoopoobtnView(id: 2, currentlySelectedId: $currentlySelectedId, text: "poo2")
                            PoopoobtnView(id: 3, currentlySelectedId: $currentlySelectedId, text: "poo3")
                            
                        }
                        HStack(spacing: 5) {
                            PoopoobtnView(id: 4, currentlySelectedId: $currentlySelectedId, text: "poo4")
                            PoopoobtnView(id: 5, currentlySelectedId: $currentlySelectedId, text: "poo5")
                            PoopoobtnView(id: 6, currentlySelectedId: $currentlySelectedId, text: "poo6")
                            PoopoobtnView(id: 7, currentlySelectedId: $currentlySelectedId, text: "poo7")
                        }
                        HStack{
                            Image("公告")
                            Text("參考來源：衛福部")
                            Link("布里斯托大便分類法", destination: URL(string: "https://www.merit-times.com/NewsPage.aspx?unid=572911")!).foregroundColor(.yellow)
                        }
                        Spacer(minLength: 0)
                        
                    }
                    .padding(.top,(UIApplication.shared.windows.first?.safeAreaInsets.top)! + 30)
                    .padding()
                    .background(Color.white.edgesIgnoringSafeArea(.all))
                    
                }
                //MARK:- 三餐熱量
                else if (record.title == "三餐熱量"){
                    
                    VStack(alignment: .leading, spacing: 25) {
                        
                        
                        VStack{
                            
                            Text("早餐")
                                .font(.system(size: 25, weight: .bold))
                                .foregroundColor(Color("Color1"))
                            TextField("早餐", text: $breakfast).autocapitalization(.none)
                                .foregroundColor(Color(.black))
                                .keyboardType(.numberPad)
                            Divider()
                            Text("午餐")
                                .font(.system(size: 25, weight: .bold))
                                .foregroundColor(Color("Color1"))
                            TextField("午餐", text: $lunch).autocapitalization(.none)
                                .foregroundColor(Color(.black))
                                .keyboardType(.numberPad)
                            Divider()
                            
                            Text("晚餐")
                                .font(.system(size: 25, weight: .bold))
                                .foregroundColor(Color("Color1"))
                            TextField("晚餐", text: $dinner).autocapitalization(.none)
                                .foregroundColor(Color(.black))
                                .keyboardType(.numberPad)
                            Divider()
                            
                        }
                        
                        HStack{
                            
                            Spacer()
                            
                            //MARK:- 儲存三餐熱量save
                            
                            Button(action: {
                                let w1 = re.IOS_addFood(uid: user, 早餐熱量: "\(breakfast)", 午餐熱量: "\(lunch)", 晚餐熱量: "\(dinner)")
                                self.showAlert = true
                            }) {
                                
                                Text("確定")
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding(.vertical)
                                    .padding(.horizontal,45)
                                    .background(Color("Color1"))
                                    .clipShape(Capsule())
                            }.alert(isPresented: $showAlert, content: { self.alert })
                            
                            Spacer()
                        }
                        .padding(.top)
                        
                        Spacer(minLength: 0)
                        
                    }
                    .padding(.top,(UIApplication.shared.windows.first?.safeAreaInsets.top)! + 30)
                    .padding()
                    .background(Color.white.edgesIgnoringSafeArea(.all))
                    
                }
                else{
                    
                }
            }
        }
        .edgesIgnoringSafeArea(.all)
        .statusBar(hidden: true)
    }
}


struct PoopoobtnView: View {
    
    let id: Int
    @Binding var currentlySelectedId: Int
    
    var text: String
    
    var body: some View {
        Button(action: { self.currentlySelectedId = self.id }, label: { Image(text) })
            .foregroundColor(id == currentlySelectedId ? .white : .orange)
            .background(
                Circle()
                    .fill(id == currentlySelectedId ? Color.orange :  Color.white)
                    .frame(width: 50, height: 50)
                    .overlay(
                        Circle()
                            .stroke(lineWidth: 2)
                            .foregroundColor(.orange)
                            .padding(0)
                    )
            )
    }
}

