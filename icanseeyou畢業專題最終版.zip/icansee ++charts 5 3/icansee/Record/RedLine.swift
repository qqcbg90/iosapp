//
//  RedLine.swift
//  icansee
//
//  Created by WenLi Lee on 2021/3/9.
//

import SwiftUI
import Charts
struct RedLine: View {
    @State private var show_7: Bool = false
    @State private var show_28: Bool = false
    @State private var show_all: Bool = false
    //
    @State var tab = "Today"
    @Namespace var animation
    //
    var body: some View {
        

            ZStack{
                Spacer(minLength: 50)
                Color("lightorang")
                    //.clipShape(CustomCorners(corners: [.topLeft,.topRight], size: 45))
                    .ignoresSafeArea(.all, edges: .bottom)
                
                VStack{
                    HStack{
                        Button(action: {
                            show_7 = true
                            show_28 = false
                            show_all = false
                            
                        }) {
                            
                           Text(" 7天")
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                                .padding(.vertical,30)
                                .padding(.horizontal,30)
                                .background(Color("Color1"))
                                .clipShape(Capsule())
 
                        }
                        Button(action: {
                            show_7 = false
                            show_all = false
                            show_28 = true
                        }) {
                            
                           Text("28天")
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                                .padding(.vertical,30)
                                .padding(.horizontal,30)
                                .background(Color("Color1"))
                                .clipShape(Capsule())
 
                        }
                        Button(action: {
                            show_7 = false
                            show_28 = false
                            show_all = true
                        }) {
                            
                           Text("全部")
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                                .padding(.vertical,30)
                                .padding(.horizontal,30)
                                .background(Color("Color1"))
                                .clipShape(Capsule())
 
                        }
                        
                        
                        
                    }
                    .padding(.top,30)
                    HStack{
                    if (show_7 == true){
                        LineChartSwiftUI_red()
                    }
                    else if(show_28 == true)
                    {
                        LineChartSwiftUI_red28()
                    }
                    else{
                        LineChartSwiftUI_redall()
                    }
                    }.padding(.bottom,50)
                    
                       Spacer(minLength: 100)
                
                    
                    

                }
                .padding(.top,20)
            }.ignoresSafeArea(.all)
            .background(Color("lightorang").ignoresSafeArea(.all, edges: .bottom))
        

    }
}

struct RedLine_Previews: PreviewProvider {
    static var previews: some View {
        RedLine()
    }
}

struct LineChartSwiftUI_red: UIViewRepresentable {
    let lineChart = LineChartView()
    
    // let BP1 = Double(w_BP1[1]!)
    func makeUIView(context: UIViewRepresentableContext<LineChartSwiftUI_red>) -> LineChartView {
        setUpChart()
        return lineChart
    }
    
    func updateUIView(_ uiView: LineChartView, context: UIViewRepresentableContext<LineChartSwiftUI_red>) {
        
    }
    
    func setUpChart() {
        lineChart.noDataText = "No Data Available"
        let dataSets = [getLineChartDataSet()]
        let data = LineChartData(dataSets: dataSets)
        
        data.setValueFont(.systemFont(ofSize: 10, weight: .light))
        data.setValueTextColor(UIColor(.black))
        
        lineChart.data = data
    }
    
    func getChartDataPoints(sessions: [Int], accuracy: [Double]) -> [ChartDataEntry] {
        var dataPoints: [ChartDataEntry] = []
        for count in (0..<sessions.count) {
            dataPoints.append(ChartDataEntry.init(x: Double(sessions[count]), y: accuracy[count]))
        }
        
        
        return dataPoints
    }
    
    func getLineChartDataSet() -> LineChartDataSet {
        
        var 數量 = [Int]()
        var 次數 = [Double]()
        var k = 0
        var 日期 = [String]()
        let w_BP1 = re.Test_Red(uid: "Biggg", choose: "7day", Startday: "", Endday: "")
        let i = w_BP1.count
        
        for _ in k...i{
            if(k>=i)
            {
                break;
            }
            else if(w_BP1[0]=="null")
            {
                數量.append(0)
                次數.append(0)
                
                break;
            }
            else{
                let data_BP1 = String(w_BP1[k]!)
                let first:CharacterSet = [",",","];
                let first2 = data_BP1.components(separatedBy: first)
                數量.append(k)
                次數.append(first2[0].toDouble()!)
                日期.append(first2[1])
                print(次數)
                k+=1
            }
            
            //var xValues: [String] = 日期
            let xAxis = lineChart.xAxis
            //xValues.append(contentsOf: xValues)
            xAxis.valueFormatter = IndexAxisValueFormatter(values: 日期)
            xAxis.granularity = 1 // 曲線間格為1
            
            
        }
        
        let dataPoints = getChartDataPoints(sessions: 數量, accuracy : 次數)
        //session是放總共有幾筆資料accuracy是放我們收到的數值
        let set = LineChartDataSet(entries: dataPoints, label: "經過次數")
        
        //左邊圖表大小值設定
        let leftAxis = lineChart.leftAxis
        leftAxis.axisMaximum = 20.0
        leftAxis.axisMinimum = 0.0
        //leftAxis.labelCount = 7
        
        
        
        set.lineWidth = 2
        set.circleRadius = 4
        set.circleHoleRadius = 2
        //let color = ChartColorTemplates.vordiplom()[0]
        set.setColor(UIColor.init(displayP3Red: 1/255, green: 52/255, blue: 96/255, alpha: 1))
        set.setCircleColor(UIColor.init(displayP3Red: 1/255, green: 52/255, blue: 96/255, alpha: 1))
        //設立界線
        
        
        
        //標籤換到下方
        lineChart.xAxis.labelPosition = .bottom
        
        //取消雙擊
        lineChart.doubleTapToZoomEnabled=false
        //設定X軸文字
        lineChart.xAxis.labelTextColor = UIColor.brown
        lineChart.xAxis.labelFont = UIFont.systemFont(ofSize: 5)  //文字字型
        
        lineChart.rightAxis.enabled = false
        
        //設定Y軸上標籤的樣式
        lineChart.leftAxis.labelPosition = .outsideChart   //label位置
        lineChart.leftAxis.labelTextColor = UIColor.brown   //文字顏色
        lineChart.leftAxis.labelFont = UIFont.systemFont(ofSize: 8)  //文字字型
        return set
    }
    
}

struct LineChartSwiftUI_red28: UIViewRepresentable {
    let lineChart = LineChartView()
    
    // let BP1 = Double(w_BP1[1]!)
    func makeUIView(context: UIViewRepresentableContext<LineChartSwiftUI_red28>) -> LineChartView {
        setUpChart()
        return lineChart
    }
    
    func updateUIView(_ uiView: LineChartView, context: UIViewRepresentableContext<LineChartSwiftUI_red28>) {
        
    }
    
    func setUpChart() {
        lineChart.noDataText = "No Data Available"
        let dataSets = [getLineChartDataSet()]
        let data = LineChartData(dataSets: dataSets)
        
        data.setValueFont(.systemFont(ofSize: 10, weight: .light))
        data.setValueTextColor(UIColor(.black))
        
        lineChart.data = data
    }
    
    func getChartDataPoints(sessions: [Int], accuracy: [Double]) -> [ChartDataEntry] {
        var dataPoints: [ChartDataEntry] = []
        for count in (0..<sessions.count) {
            dataPoints.append(ChartDataEntry.init(x: Double(sessions[count]), y: accuracy[count]))
        }
        
        
        return dataPoints
    }
    
    func getLineChartDataSet() -> LineChartDataSet {
        
        var 數量 = [Int]()
        var 次數 = [Double]()
        var k = 0
        var 日期 = [String]()
        let w_BP1 = re.Test_Red(uid: "Biggg", choose: "28day", Startday: "", Endday: "")
        let i = w_BP1.count
        
        for _ in k...i{
            if(k>=i)
            {
                break;
            }
            else if(w_BP1[0]=="null")
            {
                數量.append(0)
                次數.append(0)
                
                break;
            }
            else{
                let data_BP1 = String(w_BP1[k]!)
                let first:CharacterSet = [",",","];
                let first2 = data_BP1.components(separatedBy: first)
                數量.append(k)
                次數.append(first2[0].toDouble()!)
                日期.append(first2[1])
                print(次數)
                k+=1
            }
            
            //var xValues: [String] = 日期
            let xAxis = lineChart.xAxis
            //xValues.append(contentsOf: xValues)
            xAxis.valueFormatter = IndexAxisValueFormatter(values: 日期)
            xAxis.granularity = 1 // 曲線間格為1
            
            
        }
        
        let dataPoints = getChartDataPoints(sessions: 數量, accuracy : 次數)
        //session是放總共有幾筆資料accuracy是放我們收到的數值
        let set = LineChartDataSet(entries: dataPoints, label: "經過次數")
        
        //左邊圖表大小值設定
        let leftAxis = lineChart.leftAxis
        leftAxis.axisMaximum = 20.0
        leftAxis.axisMinimum = 0.0
        //leftAxis.labelCount = 7
        
        
        
        set.lineWidth = 2
        set.circleRadius = 4
        set.circleHoleRadius = 2
        //let color = ChartColorTemplates.vordiplom()[0]
        set.setColor(UIColor.init(displayP3Red: 28/255, green: 118/255, blue: 100/255, alpha: 1))
        set.setCircleColor(UIColor.init(displayP3Red: 28/255, green: 118/255, blue: 100/255, alpha: 1))
        //設立界線
        
        
        
        //標籤換到下方
        lineChart.xAxis.labelPosition = .bottom
        
        //取消雙擊
        lineChart.doubleTapToZoomEnabled=false
        //設定X軸文字
        lineChart.xAxis.labelTextColor = UIColor.brown
        lineChart.xAxis.labelFont = UIFont.systemFont(ofSize: 5)  //文字字型
        
        lineChart.rightAxis.enabled = false
        
        //設定Y軸上標籤的樣式
        lineChart.leftAxis.labelPosition = .outsideChart   //label位置
        lineChart.leftAxis.labelTextColor = UIColor.brown   //文字顏色
        lineChart.leftAxis.labelFont = UIFont.systemFont(ofSize: 8)  //文字字型
        return set
    }
    
}

struct LineChartSwiftUI_redall: UIViewRepresentable {
    let lineChart = LineChartView()
    
    // let BP1 = Double(w_BP1[1]!)
    func makeUIView(context: UIViewRepresentableContext<LineChartSwiftUI_redall>) -> LineChartView {
        setUpChart()
        return lineChart
    }
    
    func updateUIView(_ uiView: LineChartView, context: UIViewRepresentableContext<LineChartSwiftUI_redall>) {
        
    }
    
    func setUpChart() {
        lineChart.noDataText = "No Data Available"
        let dataSets = [getLineChartDataSet()]
        let data = LineChartData(dataSets: dataSets)
        lineChart.frame(forAlignmentRect: .init(x:0,y:0,width: 50, height: 100))
        data.setValueFont(.systemFont(ofSize: 10, weight: .light))
        data.setValueTextColor(UIColor(.black))
        
        lineChart.data = data
    }
    
    func getChartDataPoints(sessions: [Int], accuracy: [Double]) -> [ChartDataEntry] {
        var dataPoints: [ChartDataEntry] = []
        for count in (0..<sessions.count) {
            dataPoints.append(ChartDataEntry.init(x: Double(sessions[count]), y: accuracy[count]))
        }
        
        
        return dataPoints
    }
    
    func getLineChartDataSet() -> LineChartDataSet {
        
        var 數量 = [Int]()
        var 次數 = [Double]()
        var k = 0
        var 日期 = [String]()
        let w_BP1 = re.Test_Red(uid: "Biggg", choose: "all", Startday: "", Endday: "")
        let i = w_BP1.count
        
        for _ in k...i{
            if(k>=i)
            {
                break;
            }
            else if(w_BP1[0]=="null")
            {
                數量.append(0)
                次數.append(0)
                
                break;
            }
            else{
                let data_BP1 = String(w_BP1[k]!)
                let first:CharacterSet = [",",","];
                let first2 = data_BP1.components(separatedBy: first)
                數量.append(k)
                次數.append(first2[0].toDouble()!)
                日期.append(first2[1])
                print(次數)
                k+=1
            }
            
            //var xValues: [String] = 日期
            let xAxis = lineChart.xAxis
            //xValues.append(contentsOf: xValues)
            xAxis.valueFormatter = IndexAxisValueFormatter(values: 日期)
            xAxis.granularity = 1 // 曲線間格為1
            
            
        }
        
        let dataPoints = getChartDataPoints(sessions: 數量, accuracy : 次數)
        //session是放總共有幾筆資料accuracy是放我們收到的數值
        let set = LineChartDataSet(entries: dataPoints, label: "經過次數")
        
        //左邊圖表大小值設定
        let leftAxis = lineChart.leftAxis
        leftAxis.axisMaximum = 20.0
        leftAxis.axisMinimum = 0.0
        //leftAxis.labelCount = 7
        
        
        
        set.lineWidth = 2
        set.circleRadius = 4
        set.circleHoleRadius = 2
        //let color = ChartColorTemplates.vordiplom()[0]
        set.setColor(UIColor.init(displayP3Red: 203/255, green: 56/255, blue: 64/255, alpha: 1))
        set.setCircleColor(UIColor.init(displayP3Red: 203/255, green: 56/255, blue: 64/255, alpha: 1))
        //設立界線
        
        
        
        //標籤換到下方
        lineChart.xAxis.labelPosition = .bottom
        
        //取消雙擊
        lineChart.doubleTapToZoomEnabled=false
        //設定X軸文字
        lineChart.xAxis.labelTextColor = UIColor.brown
        lineChart.xAxis.labelFont = UIFont.systemFont(ofSize: 5)  //文字字型
        
        lineChart.rightAxis.enabled = false
        
        //設定Y軸上標籤的樣式
        lineChart.leftAxis.labelPosition = .outsideChart   //label位置
        lineChart.leftAxis.labelTextColor = UIColor.brown   //文字顏色
        lineChart.leftAxis.labelFont = UIFont.systemFont(ofSize: 8)  //文字字型
        return set
    }
    
}
