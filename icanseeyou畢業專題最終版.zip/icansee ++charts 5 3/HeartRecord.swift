//
//  HeartRecord.swift
//  icansee
//
//  Created by WenLi Lee on 2020/11/14.
//

import SwiftUI
import Combine
import Charts

struct HeartRecord: View {
    
    @Binding var user : String
    
    var body: some View {
        NavigationView{
            
            heartRecord(title: Binding<String>.constant("28day"))
                .navigationBarHidden(true)
                .edgesIgnoringSafeArea(.all)
                .navigationBarHidden(true)
        }
        
    }
}


struct HeartRecord_Previews: PreviewProvider {
    static var previews: some View {
        HeartRecord(user: .constant(""))
        
    }
}

struct heartRecord : View {
    //var dataa : Datas
    @State var tab = "Today"
    @State var subTab = "7day"
    @State var tab3 = "28day"
    @Binding var title : String
    @State private var show_HR: Bool = false
    @State private var show_SpO2: Bool = false
    @State private var show_BP: Bool = false
    @State private var show_Temp: Bool = false
    @Namespace var animation
    
    
    // var qqq :tabbutton
    @State var edges = UIApplication.shared.windows.first?.safeAreaInsets

    var body: some View{

        
        VStack{
            
            HStack{
                
                Button(action: {}) {
                    
                    /*Image("menu")
                     .renderingMode(.template)
                     .foregroundColor(.white)*/
                }
                
                Spacer(minLength: 0)
                
                Button(action: {}) {
                    
                    Image("bell")
                        .renderingMode(.template)
                        .foregroundColor(.white)
                }
            }
            .padding()
            
            
            // Or YOu can use Foreach Also...
            VStack(spacing: 20){
                Text("最新一筆資料")
                    .font(.title2)
                
                HStack(spacing: 15){
                    Button(action: {
                        show_HR = true
                        show_SpO2 = false
                        show_BP = false
                        show_Temp = false
                    }) {
                        DatasView(data: myData[0])
                    }
                    
                    Button(action: {
                        show_SpO2 = true
                        show_HR = false
                        show_BP = false
                        show_Temp = false
                        
                    }) {
                        DatasView(data: myData[1])
                    }
                }
                
                HStack(spacing: 15){
                    
                    Button(action: {
                        show_BP = true
                        show_HR = false
                        show_Temp = false
                        show_SpO2 = false
                    }) {
                        DatasView(data: myData[2])
                    }
                    Button(action: {
                        show_Temp = true
                        show_HR = false
                        show_BP = false
                        show_SpO2 = false
                    }) {
                        DatasView(data: myData[3])
                    }
                    
                }
            }
            .padding(.horizontal)
            
            HStack(spacing: 10){
                
                //tabbutton(selected: $tab, title: "Today", animation: animation)
                
                tabbutton(selected: $tab, title: "7day", animation: animation)
                
                
                tabbutton(selected: $tab, title: "28day", animation: animation)
            }
            .background(Color.white.opacity(0.08))
            .clipShape(Capsule())
        
            
            ZStack{
                
                Color("lightorang")
                    //.clipShape(CustomCorners(corners: [.topLeft,.topRight], size: 45))
                    .ignoresSafeArea(.all, edges: .bottom)
                
                VStack{
                    
                    HStack{
                        if(show_HR==true){
                            if (tab == "7day")
                            {
                                GeometryReader { p in
                                    VStack {
                                        LineChartSwiftUI_7HR()
                                        //use frame to change the graph size within your SwiftUI view
                                        //.frame(width: p.size.width, height: p.size.height/5, alignment: .center)
                                    }
                                }
                            }
                            else if (tab == "28day")
                            {
                                GeometryReader { p in
                                    VStack {
                                        LineChartSwiftUI_28HR()
                                        //use frame to change the graph size within your SwiftUI view
                                        //.frame(width: p.size.width, height: p.size.height/5, alignment: .center)
                                    }
                                }
                            }
                            Spacer(minLength: 0)
                            
                        }
                        
                        else if(show_SpO2==true){
                            if (tab == "7day")
                            {
                                GeometryReader { p in
                                    VStack {
                                        LineChartSwiftUI_7SpO2()
                                        
                                        //use frame to change the graph size within your SwiftUI view
                                        //.frame(width: p.size.width, height: p.size.height/5, alignment: .center)
                                    }
                                }
                            }
                            else if (tab == "28day")
                            {
                                GeometryReader { p in
                                    VStack {
                                        LineChartSwiftUI_28SpO2()
                                        
                                        //use frame to change the graph size within your SwiftUI view
                                        //.frame(width: p.size.width, height: p.size.height/5, alignment: .center)
                                    }
                                }
                            }
                            
                            Spacer(minLength: 0)
                        }
                        
                        else if(show_BP==true){
                            if (tab == "7day")
                            {
                                GeometryReader { p in
                                    VStack {
                                        LineChartSwiftUI_7BP()
                                        //use frame to change the graph size within your SwiftUI view
                                        //.frame(width: p.size.width, height: p.size.height/5, alignment: .center)
                                    }
                                }
                            }
                            else if (tab == "28day")
                            {
                                GeometryReader { p in
                                    VStack {
                                        LineChartSwiftUI_28BP()
                                        //use frame to change the graph size within your SwiftUI view
                                        //.frame(width: p.size.width, height: p.size.height/5, alignment: .center)
                                    }
                                }
                            }
                            Spacer(minLength: 0)
                        }
                        
                        else if(show_Temp==true){
                            if (tab == "7day")
                            {
                                GeometryReader { p in
                                    VStack {
                                        LineChartSwiftUI_7Temp()
                                        //use frame to change the graph size within your SwiftUI view
                                        //.frame(width: p.size.width, height: p.size.height/5, alignment: .center)
                                    }
                                }
                            }
                            else if (tab == "28day")
                            {
                                GeometryReader { p in
                                    VStack {
                                        LineChartSwiftUI_28Temp()
                                      
                                    }
                                }
                            }
                            Spacer(minLength: 0)
                        }
                    } .padding()
                    .padding(.top,10)
                    VStack(spacing: 10){
                        
                        
                    }
                    .padding(.horizontal,20)
                    .padding(.bottom,130)
                    
                }
            }
            .padding(.top,20)
        }
        .background(Color("lightorang").ignoresSafeArea(.all, edges: .bottom))
        
        

        
    }
    
}




struct tabbutton : View {
    
    @Binding var selected : String
    @State var title : String
    var animation : Namespace.ID
    
    var body: some View{
        
        Button(action: {
            
            withAnimation(.spring()){
                selected = title
                
                
                /*Divider()
                 HeartRecord();
                 heartRecord(title: Binding<String>.constant(""), selected: self.$selected)*/
                
            }
            
        }) {
            
            ZStack{
                
                // Capsule And Sliding Effect...
                
                Capsule()
                    .fill(Color.clear)
                    .frame(height: 45)
                
                if selected == title{
                    
                    Capsule()
                        .fill(Color.white)
                        .frame(height: 45)
                        // Mathced Geometry Effect...
                        .matchedGeometryEffect(id: "Tab", in: animation)
                }
                
                Text(title)
                    .foregroundColor(selected == title ? .black : .white)
                    .fontWeight(.bold)
            }
        }
    }
    
   /* struct LineChartSwiftUI_7HR: UIViewRepresentable {
        @Binding var user : String
        let lineChart = LineChartView()
        
        // let BP1 = Double(w_BP1[1]!)
        func makeUIView(context: UIViewRepresentableContext<LineChartSwiftUI_7HR>) -> LineChartView {
            setUpChart()
            return lineChart
        }
        
        func updateUIView(_ uiView: LineChartView, context: UIViewRepresentableContext<LineChartSwiftUI_7HR>) {
            
        }
        
        func setUpChart() {
            lineChart.noDataText = "No Data Available"
            let dataSets = [getLineChartDataSet()]
            let data = LineChartData(dataSets: dataSets)
            
            data.setValueFont(.systemFont(ofSize: 10, weight: .light))
            data.setValueTextColor(UIColor(.black))
            
            lineChart.data = data
        }
        
        func getChartDataPoints(sessions: [Int], accuracy: [Double]) -> [ChartDataEntry] {
            var dataPoints: [ChartDataEntry] = []
            for count in (0..<sessions.count) {
                dataPoints.append(ChartDataEntry.init(x: Double(sessions[count]), y: accuracy[count]))
            }
           
            
            return dataPoints
        }
        
        func getLineChartDataSet() -> LineChartDataSet {
            
            
            var 數量 = [Int]()
            var 收 = [Double]()
            var k = 0
            var 日期 = [String]()
            let w_BP1 = re.Test_HR(uid: user, choose: "7day", Startday: "", Endday: "")
            let i = w_BP1.count
            
            for _ in k...i{
                if(k>=i)
                {
                    break;
                }
                else if(w_BP1[0]=="null")
                {
                    數量.append(0)
                    收.append(0)
                    
                    break;
                }
                else{
                    let data_BP1 = String(w_BP1[k]!)
                    let first:CharacterSet = ["：",","];
                    let first2 = data_BP1.components(separatedBy: first)
                    數量.append(k)
                    收.append(first2[1].toDouble()!)
                    日期.append(first2[3])
                    print(收)
                    k+=1
                }
                
                //var xValues: [String] = 日期
                let xAxis = lineChart.xAxis
                //xValues.append(contentsOf: xValues)
                xAxis.valueFormatter = IndexAxisValueFormatter(values: 日期)
                xAxis.granularity = 1 // 曲線間格為1
                
                
            }
           
            let dataPoints = getChartDataPoints(sessions: 數量, accuracy : 收)
            //session是放總共有幾筆資料accuracy是放我們收到的數值
            let set = LineChartDataSet(entries: dataPoints, label: "脈搏")
            
            //左邊圖表大小值設定
            let leftAxis = lineChart.leftAxis
            leftAxis.axisMaximum = 160.0
            leftAxis.axisMinimum = 20.0
            leftAxis.labelCount = 7
            
            
           
            set.lineWidth = 2
            set.circleRadius = 4
            set.circleHoleRadius = 2
            //let color = ChartColorTemplates.vordiplom()[0]
            set.setColor(UIColor.init(displayP3Red: 242/255, green: 114/255, blue: 86/255, alpha: 1))
            set.setCircleColor(UIColor.init(displayP3Red: 242/255, green: 114/255, blue: 86/255, alpha: 1))
            //設立界線
            let HR = HR_limit.components(separatedBy: first)
            
            let HR上限 = ChartLimitLine(limit: HR[1].toDouble()!, label: "")
            HR上限.lineWidth = 2
            HR上限.lineColor = (UIColor.init(displayP3Red: 242/255, green: 114/255, blue: 86/255, alpha: 1))
            HR上限.lineDashLengths = [5.0, 5.0]   //虛線樣式
            HR上限.labelPosition = .topRight  //位置
            lineChart.leftAxis.addLimitLine(HR上限)  //新增到Y軸上
            lineChart.leftAxis.drawLimitLinesBehindDataEnabled = true  //設定限制線繪製在柱形圖的後面
            
            let HR下限 = ChartLimitLine(limit: HR[3].toDouble()!, label: "")
            HR下限.lineWidth = 2
            HR下限.lineColor = (UIColor.init(displayP3Red: 78/255, green: 131/255, blue: 158/255, alpha: 1))
            HR下限.lineDashLengths = [5.0, 5.0]   //虛線樣式
            HR下限.labelPosition = .topRight  //位置
            lineChart.leftAxis.addLimitLine(HR下限)  //新增到Y軸上
            lineChart.leftAxis.drawLimitLinesBehindDataEnabled = true  //設定限制線繪製在柱形圖的後面
            
            
            //標籤換到下方
            lineChart.xAxis.labelPosition = .bottom
            
            //取消雙擊
            lineChart.doubleTapToZoomEnabled=false
            //設定X軸文字
            lineChart.xAxis.labelTextColor = UIColor.brown
            lineChart.xAxis.labelFont = UIFont.systemFont(ofSize: 5)  //文字字型
            
            //設定y軸文字
            lineChart.rightAxis.enabled = false
            let limit = ChartLimitLine(limit: 36.8, label: "脈搏")
            lineChart.xAxis.addLimitLine(limit)
            lineChart.leftAxis.drawZeroLineEnabled = true   //從0開始繪製
            lineChart.leftAxis.axisLineColor =  UIColor.black  //Y軸顏色

            //設定Y軸上標籤的樣式
            lineChart.leftAxis.labelPosition = .outsideChart   //label位置
            lineChart.leftAxis.labelTextColor = UIColor.brown   //文字顏色
            lineChart.leftAxis.labelFont = UIFont.systemFont(ofSize: 8)  //文字字型
            return set
        }
        
    } //28dayHR*/
    
}

// Sample Model Data....

struct Datas: Identifiable {
    
    var id = UUID().uuidString
    var title : String
    var value : String
    var color : Color
}




//MARK:-new BP

/*
 
 
 let w_BP1 = re.Test_BP(uid: "Biggg", choose: "7day", Startday: "", Endday: "")
 var i = w_BP1.count
 var res1 = [Double]()
 var k = 0
 
 
 let data_BP1 = String(w_BP1[0]!)
 
 let start_BP = data_BP1.index(data_BP1.startIndex, offsetBy: 0)
 let end_BP = data_BP1.index(data_BP1.startIndex, offsetBy: 6)
 let resBP1 = data_BP1[start_BP...end_BP]
 var 收 = [Double](repeating: 2.0, count: i)
 
 
 
 let start_BP1 = data_BP1.index(data_BP1.startIndex, offsetBy: 8)
 let end_BP2 = data_BP1.index(data_BP1.startIndex, offsetBy: 14)
 let res_BP2 = data_BP1[start_BP1...end_BP2]
 
 
 //let i = username.
 
 //MARK:-new HR
 /*
 let HR1 = re.Test_HR(uid: "Biggg", time: "new")
 let dataHR = String(HR1[0]!)
 //let index脈搏 = String(data_HR.prefix(6))
 let startHR = dataHR.index(dataHR.startIndex, offsetBy: 3)
 let endHR = dataHR.index(dataHR.startIndex, offsetBy: 5)
 let resHR = dataHR[startHR...endHR]
 
 //MARK:-new SpO2
 let wSpO2 = re1.Test_SpO2(uid: "Biggg", time: "new")
 let dataSpO2 = String(wSpO2[0]!)
 //let index血氧 = String(data_SpO2.prefix(6))
 let startSpO2 = dataSpO2.index(dataSpO2.startIndex, offsetBy: 3)
 let endSpO2 = dataSpO2.index(dataSpO2.startIndex, offsetBy: 5)
 let resSpO2 = dataSpO2[startSpO2...endSpO2]
 
 //MARK:-new Temp
 let wTemp = re1.Test_Temp(uid: "Biggg", time: "new")
 let dataTemp = String(wTemp[0]!)
 //let index體溫 = String(data_Temp.prefix(7))
 let startTemp = dataTemp.index(dataTemp.startIndex, offsetBy: 3)
 let endTemp = dataTemp.index(dataTemp.startIndex, offsetBy: 6)
 let resTemp = dataTemp[startTemp...endTemp]
 */
 */

var myData = [
    
    Datas(title: "心跳", value: "\(res_HR) bpm", color: Color.orange),
    Datas(title: "血氧", value: "\(res_SpO2) %", color: Color.red),
    Datas(title: "血壓", value: "\(res_BP) mmHg", color: Color.blue),
    // Datas(title: "血糖", value: "130mg/dl", color: Color.pink),
    Datas(title: "體溫", value: "\(res_Temp) 度", color: Color.purple),
]

// Daily Sold Model And Data....

struct DailySales : Identifiable {
    var id = UUID().uuidString
    var day : Date
    var value : CGFloat
    var show : Bool
}
//心跳血氧血壓數值顯示的框框
struct DatasView : View {
    
    var data : Datas
    
    var body: some View{
        
        ZStack{
            
            HStack{
                
                VStack(alignment: .leading, spacing: 22) {
                    
                    Text(data.title)
                        .foregroundColor(.black)
                    
                    Text(data.value)
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                }
                
                Spacer(minLength: 0)
            }
            .padding()
        }
        .background(data.color)
        .cornerRadius(10)
    }
}


//MARK:- 七天

let HR_limit = re.limit(choose: "HR")
let SpO2_limit = re.limit(choose: "SpO2")
let BP_limit = re.limit(choose: "BP")
let Temp_limit = re.limit(choose: "Temp")

struct LineChartSwiftUI_7HR: UIViewRepresentable {
    
    let lineChart = LineChartView()
    
    // let BP1 = Double(w_BP1[1]!)
    func makeUIView(context: UIViewRepresentableContext<LineChartSwiftUI_7HR>) -> LineChartView {
        setUpChart()
        return lineChart
    }
    
    func updateUIView(_ uiView: LineChartView, context: UIViewRepresentableContext<LineChartSwiftUI_7HR>) {
        
    }
    
    func setUpChart() {
        lineChart.noDataText = "No Data Available"
        let dataSets = [getLineChartDataSet()]
        let data = LineChartData(dataSets: dataSets)
        
        data.setValueFont(.systemFont(ofSize: 10, weight: .light))
        data.setValueTextColor(UIColor(.black))
        
        lineChart.data = data
    }
    
    func getChartDataPoints(sessions: [Int], accuracy: [Double]) -> [ChartDataEntry] {
        var dataPoints: [ChartDataEntry] = []
        for count in (0..<sessions.count) {
            dataPoints.append(ChartDataEntry.init(x: Double(sessions[count]), y: accuracy[count]))
        }
       
        
        return dataPoints
    }
    
    func getLineChartDataSet() -> LineChartDataSet {
        
        
        var 數量 = [Int]()
        var 收 = [Double]()
        var k = 0
        var 日期 = [String]()
        let w_BP1 = re.Test_HR(uid: "Biggg", choose: "7day", Startday: "", Endday: "")
        let i = w_BP1.count
    
        
        for _ in k...i{
            if(k>=i)
            {
                break;
            }
            else if(w_BP1[0]=="null")
            {
                數量.append(0)
                收.append(0)
                
                break;
            }
            else{
                let data_BP1 = String(w_BP1[k]!)
                let first:CharacterSet = ["：",","];
                let first2 = data_BP1.components(separatedBy: first)
                數量.append(k)
                收.append(first2[1].toDouble()!)
                日期.append(first2[3])
                print(收)
                k+=1
            }
            
            //var xValues: [String] = 日期
            let xAxis = lineChart.xAxis
            //xValues.append(contentsOf: xValues)
            xAxis.valueFormatter = IndexAxisValueFormatter(values: 日期)
            xAxis.granularity = 1 // 曲線間格為1
            
            
        }
       
        let dataPoints = getChartDataPoints(sessions: 數量, accuracy : 收)
        //session是放總共有幾筆資料accuracy是放我們收到的數值
        let set = LineChartDataSet(entries: dataPoints, label: "脈搏")
        
        //左邊圖表大小值設定
        let leftAxis = lineChart.leftAxis
        leftAxis.axisMaximum = 160.0
        leftAxis.axisMinimum = 20.0
        leftAxis.labelCount = 7
        
        
       
        set.lineWidth = 2
        set.circleRadius = 4
        set.circleHoleRadius = 2
        //let color = ChartColorTemplates.vordiplom()[0]
        set.setColor(UIColor.init(displayP3Red: 242/255, green: 114/255, blue: 86/255, alpha: 1))
        set.setCircleColor(UIColor.init(displayP3Red: 242/255, green: 114/255, blue: 86/255, alpha: 1))
        //設立界線
        let HR = HR_limit.components(separatedBy: first)
        
        let HR上限 = ChartLimitLine(limit: HR[1].toDouble()!, label: "")
        HR上限.lineWidth = 2
        HR上限.lineColor = (UIColor.init(displayP3Red: 242/255, green: 114/255, blue: 86/255, alpha: 1))
        HR上限.lineDashLengths = [5.0, 5.0]   //虛線樣式
        HR上限.labelPosition = .topRight  //位置
        lineChart.leftAxis.addLimitLine(HR上限)  //新增到Y軸上
        lineChart.leftAxis.drawLimitLinesBehindDataEnabled = true  //設定限制線繪製在柱形圖的後面
        
        let HR下限 = ChartLimitLine(limit: HR[3].toDouble()!, label: "")
        HR下限.lineWidth = 2
        HR下限.lineColor = (UIColor.init(displayP3Red: 78/255, green: 131/255, blue: 158/255, alpha: 1))
        HR下限.lineDashLengths = [5.0, 5.0]   //虛線樣式
        HR下限.labelPosition = .topRight  //位置
        lineChart.leftAxis.addLimitLine(HR下限)  //新增到Y軸上
        lineChart.leftAxis.drawLimitLinesBehindDataEnabled = true  //設定限制線繪製在柱形圖的後面
        
        
        //標籤換到下方
        lineChart.xAxis.labelPosition = .bottom
        
        //取消雙擊
        lineChart.doubleTapToZoomEnabled=false
        //設定X軸文字
        lineChart.xAxis.labelTextColor = UIColor.brown
        lineChart.xAxis.labelFont = UIFont.systemFont(ofSize: 5)  //文字字型
        
        //設定y軸文字
        lineChart.rightAxis.enabled = false
        let limit = ChartLimitLine(limit: 36.8, label: "脈搏")
        lineChart.xAxis.addLimitLine(limit)
        lineChart.leftAxis.drawZeroLineEnabled = true   //從0開始繪製
        lineChart.leftAxis.axisLineColor =  UIColor.black  //Y軸顏色

        //設定Y軸上標籤的樣式
        lineChart.leftAxis.labelPosition = .outsideChart   //label位置
        lineChart.leftAxis.labelTextColor = UIColor.brown   //文字顏色
        lineChart.leftAxis.labelFont = UIFont.systemFont(ofSize: 8)  //文字字型
        return set
    }
    
} //28dayHR

struct LineChartSwiftUI_7SpO2: UIViewRepresentable {
    let lineChart = LineChartView()
    
    // let BP1 = Double(w_BP1[1]!)
    func makeUIView(context: UIViewRepresentableContext<LineChartSwiftUI_7SpO2>) -> LineChartView {
        setUpChart()
        return lineChart
    }
    
    func updateUIView(_ uiView: LineChartView, context: UIViewRepresentableContext<LineChartSwiftUI_7SpO2>) {
        
    }
    
    func setUpChart() {
        lineChart.noDataText = "No Data Available"
        let dataSets = [getLineChartDataSet()]
        let data = LineChartData(dataSets: dataSets)
        data.setValueFont(.systemFont(ofSize: 10, weight: .light))
        data.setValueTextColor(UIColor(.black))
        lineChart.data = data
    }
    
    func getChartDataPoints(sessions: [Int], accuracy: [Double]) -> [ChartDataEntry] {
        var dataPoints: [ChartDataEntry] = []
        for count in (0..<sessions.count) {
            dataPoints.append(ChartDataEntry.init(x: Double(sessions[count]), y: accuracy[count]))
        }
        return dataPoints
    }
    
    func getLineChartDataSet() -> LineChartDataSet {
        
        var 數量 = [Int]()
        var 收 = [Double]()
        var k = 0
        var 日期 = [String]()
        let w_BP1 = re.Test_SpO2(uid: "Biggg", choose: "7day", Startday: "", Endday: "")
        let i = w_BP1.count
        
        for _ in k...i{
            if(k>=i)
            {
                break;
            }
            else if(w_BP1[0]=="null")
            {
                數量.append(0)
                收.append(0)
                break;
            }
            else{
                let data_BP1 = String(w_BP1[k]!)
                let first:CharacterSet = ["：",","];
                let first2 = data_BP1.components(separatedBy: first)
                數量.append(k)
                收.append(first2[1].toDouble()!)
                日期.append(first2[3])
                print(收)
                k+=1
            }
            
            //var xValues: [String] = 日期
            let xAxis = lineChart.xAxis
            //xValues.append(contentsOf: xValues)
            xAxis.valueFormatter = IndexAxisValueFormatter(values: 日期)
            xAxis.granularity = 1 // 曲線間格為1
        }
        
        let dataPoints = getChartDataPoints(sessions: 數量, accuracy : 收)
        //session是放總共有幾筆資料accuracy是放我們收到的數值
        let set = LineChartDataSet(entries: dataPoints, label: "血氧")
        
        //左邊圖表大小值設定
        let leftAxis = lineChart.leftAxis
        leftAxis.axisMaximum = 100.0
        leftAxis.axisMinimum = 70.0
        leftAxis.labelCount = 16
        
        set.lineWidth = 2
        set.circleRadius = 4
        set.circleHoleRadius = 2
        //let color = ChartColorTemplates.vordiplom()[0]
        set.setColor(UIColor.init(displayP3Red: 78/255, green: 131/255, blue: 158/255, alpha: 1))//折線圖顏色
        set.setCircleColor(UIColor.init(displayP3Red: 78/255, green: 131/255, blue: 158/255, alpha: 1))//折線圖點的顏色
        //設立界線
        let SpO2 = SpO2_limit.components(separatedBy: first)
        
        let 血氧下限 = ChartLimitLine(limit: SpO2[1].toDouble()!, label: "")
        血氧下限.lineWidth = 2
        血氧下限.lineColor = (UIColor.init(displayP3Red: 242/255, green: 114/255, blue: 86/255, alpha: 1))
        血氧下限.lineDashLengths = [5.0, 5.0]   //虛線樣式
        血氧下限.labelPosition = .topRight  //位置
        lineChart.leftAxis.addLimitLine(血氧下限)  //新增到Y軸上
        lineChart.leftAxis.drawLimitLinesBehindDataEnabled = true  //設定限制線繪製在柱形圖的後面
       
        
        
        //標籤換到下方
        lineChart.xAxis.labelPosition = .bottom
        
        //取消雙擊
        lineChart.doubleTapToZoomEnabled=false
        //設定X軸文字
        lineChart.xAxis.labelTextColor = UIColor.brown
        lineChart.xAxis.labelFont = UIFont.systemFont(ofSize: 6.5)  //文字字型
        
        //設定y軸文字
        lineChart.rightAxis.enabled = false
        lineChart.leftAxis.drawZeroLineEnabled = true   //從0開始繪製
        lineChart.leftAxis.axisLineColor =  UIColor.black  //Y軸顏色
        //設定Y軸上標籤的樣式
        lineChart.leftAxis.labelPosition = .outsideChart   //label位置
        lineChart.leftAxis.labelTextColor = UIColor.brown   //文字顏色
        lineChart.leftAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        //xValues.append(contentsOf: xValues)
        lineChart.xAxis.valueFormatter = IndexAxisValueFormatter(values: 日期)
        
        //session是放總共有幾筆資料accuracy是放我們收到的數值
        return set
    }//7dayHR
    
} //7daySpO2

struct LineChartSwiftUI_7BP: UIViewRepresentable {
    let lineChart = LineChartView()
    
    // let BP1 = Double(w_BP1[1]!)
    func makeUIView(context: UIViewRepresentableContext<LineChartSwiftUI_7BP>) -> LineChartView {
        getLineChartDataSet()
        return lineChart
    }
    
    func updateUIView(_ uiView: LineChartView, context: UIViewRepresentableContext<LineChartSwiftUI_7BP>) {
        
    }
    
    func getChartDataPoints(sessions: [Int], accuracy: [Double]) -> [ChartDataEntry] {
        
        var dataPoints: [ChartDataEntry] = []
        for count in (0..<sessions.count) {
            dataPoints.append(ChartDataEntry.init(x: Double(sessions[count]), y: accuracy[count]))
        }
        return dataPoints
    }
    
    func getChartDataPoints2(sessions: [Int], accuracy: [Double]) -> [ChartDataEntry] {
        var dataPoints2: [ChartDataEntry] = []
        for count in (0..<sessions.count) {
            dataPoints2.append(ChartDataEntry.init(x: Double(sessions[count]), y: accuracy[count]))
        }
        return dataPoints2
    }
    
    func getLineChartDataSet() {
        
        var 數量 = [Int]()
        var 收 = [Double]()
        var 縮 = [Double]()
        var k = 0
        var 日期 = [String]()
        let w_BP1 = re.Test_BP(uid: "Biggg", choose: "7day", Startday: "", Endday: "")
        let i = w_BP1.count
        
        for _ in k...i{
            if(k>=i)
            {
                break;
            }
            else if(w_BP1[0]=="null")
            {
                數量.append(0)
                收.append(0)
                縮.append(0)
                break;
            }
            else{
                let data_BP1 = String(w_BP1[k]!)
                let first:CharacterSet = ["：",","];
                let first2 = data_BP1.components(separatedBy: first)
                數量.append(k)
                收.append(first2[1].toDouble()!)
                縮.append(first2[3].toDouble()!)
                print(收)
                print(縮)
                日期.append(first2[5])
                k+=1
            }
         
            let xAxis = lineChart.xAxis
            //xValues.append(contentsOf: xValues)
            xAxis.valueFormatter = IndexAxisValueFormatter(values: 日期)
            xAxis.granularity = 1 // 曲線間格為1
            
        }
        
        let dataPoints = getChartDataPoints(sessions: 數量, accuracy : 收)
        let dataPoints2 = getChartDataPoints2(sessions: 數量, accuracy : 縮)
        //session是放總共有幾筆資料accuracy是放我們收到的數值
        let set = LineChartDataSet(entries: dataPoints, label: "收縮壓")
        let set2 = LineChartDataSet(entries: dataPoints2, label: "舒張壓")
        
        //左邊圖表大小值設定
        let leftAxis = lineChart.leftAxis
        leftAxis.axisMaximum = 200.0
        leftAxis.axisMinimum = 40.0
        leftAxis.labelCount = 8
        
        set.lineWidth = 2.5
        set.circleRadius = 4
        set.circleHoleRadius = 2
        //
        set2.lineWidth = 2.5
        set2.circleRadius = 4
        set2.circleHoleRadius = 2
        //
        set.setColor(UIColor.init(displayP3Red: 78/255, green: 131/255, blue: 158/255, alpha: 1))//折線圖顏色
        set.setCircleColor(UIColor.init(displayP3Red: 78/255, green: 131/255, blue: 158/255, alpha: 1))//折線圖點的顏色
        set2.setColor(UIColor.init(displayP3Red: 242/255, green: 114/255, blue: 86/255, alpha: 1))
        set2.setCircleColor(UIColor.init(displayP3Red: 242/255, green: 114/255, blue: 86/255, alpha: 1))
        let data = LineChartData(dataSets: [set, set2])
        data.setValueFont(.systemFont(ofSize: 10, weight: .light))
        data.setValueTextColor(UIColor(.black))
        lineChart.data = data
     
        //設立界線
        let BP = BP_limit.components(separatedBy: first)
        
        let 收縮上限 = ChartLimitLine(limit: BP[1].toDouble()!, label: "")
        收縮上限.lineWidth = 2
        收縮上限.lineColor = (UIColor.init(displayP3Red: 242/255, green: 114/255, blue: 86/255, alpha: 1))
        收縮上限.lineDashLengths = [5.0, 5.0]   //虛線樣式
        收縮上限.labelPosition = .topRight  //位置
        lineChart.leftAxis.addLimitLine(收縮上限)  //新增到Y軸上
        lineChart.leftAxis.drawLimitLinesBehindDataEnabled = true  //設定限制線繪製在柱形圖的後面
        
        let 收縮下限 = ChartLimitLine(limit: BP[3].toDouble()!, label: "")
        收縮下限.lineWidth = 2
        收縮下限.lineColor = (UIColor.init(displayP3Red: 78/255, green: 131/255, blue: 158/255, alpha: 1))
        收縮下限.lineDashLengths = [5.0, 5.0]   //虛線樣式
        收縮下限.labelPosition = .topRight  //位置
        lineChart.leftAxis.addLimitLine(收縮下限)  //新增到Y軸上
        lineChart.leftAxis.drawLimitLinesBehindDataEnabled = true  //設定限制線繪製在柱形圖的後面
        
        //
        let 舒張上限 = ChartLimitLine(limit: BP[5].toDouble()!, label: "")
        舒張上限.lineWidth = 2
        舒張上限.lineColor = (UIColor.init(displayP3Red: 242/255, green: 114/255, blue: 86/255, alpha: 1))
        舒張上限.lineDashLengths = [5.0, 5.0]   //虛線樣式
        舒張上限.labelPosition = .topRight  //位置
        lineChart.leftAxis.addLimitLine(舒張上限)  //新增到Y軸上
        lineChart.leftAxis.drawLimitLinesBehindDataEnabled = true  //設定限制線繪製在柱形圖的後面
        
        let 舒張下限 = ChartLimitLine(limit: BP[7].toDouble()!, label: "")
        舒張下限.lineWidth = 2
        舒張下限.lineColor = (UIColor.init(displayP3Red: 78/255, green: 131/255, blue: 158/255, alpha: 1))
        舒張下限.lineDashLengths = [5.0, 5.0]   //虛線樣式
        舒張下限.labelPosition = .topRight  //位置
        lineChart.leftAxis.addLimitLine(舒張下限)  //新增到Y軸上
        lineChart.leftAxis.drawLimitLinesBehindDataEnabled = true  //設定限制線繪製在柱形圖的後面
        
        //
        data.setValueFont(.systemFont(ofSize: 10, weight: .light))
        data.setValueTextColor(UIColor(.black))
        lineChart.data = data
        //標籤換到下方
        lineChart.xAxis.labelPosition = .bottom
        //取消雙擊
        lineChart.doubleTapToZoomEnabled=false
        //設定X軸文字
        
        lineChart.xAxis.labelTextColor = UIColor.brown
        lineChart.xAxis.labelFont = UIFont.systemFont(ofSize: 6.5)  //文字字型
        
        //設定y軸文字
        lineChart.rightAxis.enabled = false
        lineChart.leftAxis.drawZeroLineEnabled = true   //從0開始繪製
        lineChart.leftAxis.axisLineColor =  UIColor.black  //Y軸顏色
        //設定Y軸上標籤的樣式
        lineChart.leftAxis.labelPosition = .outsideChart   //label位置
        lineChart.leftAxis.labelTextColor = UIColor.brown   //文字顏色
        lineChart.leftAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
       
       
        //session是放總共有幾筆資料accuracy是放我們收到的數值
        
    }//7dayHR
    
}//7dayBP >>>舒張壓超出索引？

struct LineChartSwiftUI_7Temp: UIViewRepresentable {
    let lineChart = LineChartView()
    
    // let BP1 = Double(w_BP1[1]!)
    func makeUIView(context: UIViewRepresentableContext<LineChartSwiftUI_7Temp>) -> LineChartView {
        setUpChart()
        return lineChart
    }
    
    func updateUIView(_ uiView: LineChartView, context: UIViewRepresentableContext<LineChartSwiftUI_7Temp>) {
        
    }
    
    func setUpChart() {
        lineChart.noDataText = "No Data Available"
        let dataSets = [getLineChartDataSet()]
        let data = LineChartData(dataSets: dataSets)
        data.setValueFont(.systemFont(ofSize: 10, weight: .light))
        data.setValueTextColor(UIColor(.black))
        lineChart.data = data
        
    }
    
    func getChartDataPoints(sessions: [Int], accuracy: [Double]) -> [ChartDataEntry] {
        var dataPoints: [ChartDataEntry] = []
        for count in (0..<sessions.count) {
            dataPoints.append(ChartDataEntry.init(x: Double(sessions[count]), y: accuracy[count]))
        }
        lineChart.xAxis.labelCount = dataPoints.count
        return dataPoints
    }
    
    func getLineChartDataSet() -> LineChartDataSet {
        
        var 數量 = [Int]()
        var 收 = [Double]()
        var k = 0
        var 日期 = [String]()
        let w_BP1 = re.Test_Temp(uid: "Biggg", choose: "7day", Startday: "", Endday: "")
        let i = w_BP1.count
        
        for _ in k...i{
            if(k>=i)
            {
                break;
            }
            else if(w_BP1[0]=="null")
            {
                數量.append(0)
                收.append(0)
                break;
            }
            else{
                let data_BP1 = String(w_BP1[k]!)
                let first:CharacterSet = ["：",","];
                let first2 = data_BP1.components(separatedBy: first)
                數量.append(k)
                收.append(first2[1].toDouble()!)
                print(收)
                日期.append(first2[3])
                k+=1
            }
            
            //var xValues: [String] = 日期
            let xAxis = lineChart.xAxis
            //xValues.append(contentsOf: xValues)
            xAxis.valueFormatter = IndexAxisValueFormatter(values: 日期)
            xAxis.granularity = 1 // 曲線間格為1
            
        }
        
        let dataPoints = getChartDataPoints(sessions: 數量, accuracy : 收)
        //session是放總共有幾筆資料accuracy是放我們收到的數值
        let set = LineChartDataSet(entries: dataPoints, label: "體溫")
        
        //左邊圖表大小值設定
        let leftAxis = lineChart.leftAxis
        leftAxis.axisMaximum = 40.0
        leftAxis.axisMinimum = 35.0
        leftAxis.labelCount = 10
        
        set.lineWidth = 2
        set.circleRadius = 4
        set.circleHoleRadius = 2
        //let color = ChartColorTemplates.vordiplom()[0]
        set.setColor(UIColor.init(displayP3Red: 78/255, green: 131/255, blue: 158/255, alpha: 1))//折線圖顏色
        set.setCircleColor(UIColor.init(displayP3Red: 78/255, green: 131/255, blue: 158/255, alpha: 1))//折線圖點的顏色
        
        //設立界線
        let Temp = Temp_limit.components(separatedBy: first)
        
        let Temp上限 = ChartLimitLine(limit: Temp[1].toDouble()!, label: "")
        Temp上限.lineWidth = 2
        Temp上限.lineColor = (UIColor.init(displayP3Red: 242/255, green: 114/255, blue: 86/255, alpha: 1))//red
        Temp上限.lineDashLengths = [5.0, 5.0]   //虛線樣式
        Temp上限.labelPosition = .topRight  //位置
        lineChart.leftAxis.addLimitLine(Temp上限)  //新增到Y軸上
        lineChart.leftAxis.drawLimitLinesBehindDataEnabled = true  //設定限制線繪製在柱形圖的後面
       
        let Temp下限 = ChartLimitLine(limit: Temp[3].toDouble()!, label: "")
        Temp下限.lineWidth = 2
        Temp下限.lineColor = (UIColor.init(displayP3Red: 78/255, green: 131/255, blue: 158/255, alpha: 1))//blue
        Temp下限.lineDashLengths = [5.0, 5.0]   //虛線樣式
        Temp下限.labelPosition = .topRight  //位置
        lineChart.leftAxis.addLimitLine(Temp下限)  //新增到Y軸上
        lineChart.leftAxis.drawLimitLinesBehindDataEnabled = true  //設定限制線繪製在柱形圖的後面
        
        
        //標籤換到下方
        lineChart.xAxis.labelPosition = .bottom
        
        //取消雙擊
        lineChart.doubleTapToZoomEnabled=false
        //設定X軸文字
        lineChart.xAxis.labelTextColor = UIColor.brown
        lineChart.xAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        
        //設定y軸文字
        lineChart.rightAxis.enabled = false
        lineChart.leftAxis.drawZeroLineEnabled = true   //從0開始繪製
        lineChart.leftAxis.axisLineColor =  UIColor.black  //Y軸顏色
        //設定Y軸上標籤的樣式
        lineChart.leftAxis.labelPosition = .outsideChart   //label位置
        lineChart.leftAxis.labelTextColor = UIColor.brown   //文字顏色
        lineChart.leftAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        
        // 設定X軸文字
       
        //session是放總共有幾筆資料accuracy是放我們收到的數值
        
        return set
    }
} //7dayTemp





//MARK:- 28天

struct LineChartSwiftUI_28HR: UIViewRepresentable {
    let lineChart = LineChartView()
    
    // let BP1 = Double(w_BP1[1]!)
    func makeUIView(context: UIViewRepresentableContext<LineChartSwiftUI_28HR>) -> LineChartView {
        setUpChart()
        return lineChart
    }
    
    func updateUIView(_ uiView: LineChartView, context: UIViewRepresentableContext<LineChartSwiftUI_28HR>) {
        
    }
    
    func setUpChart() {
        lineChart.noDataText = "No Data Available"
        let dataSets = [getLineChartDataSet()]
        let data = LineChartData(dataSets: dataSets)
        data.setValueFont(.systemFont(ofSize: 10, weight: .light))
        data.setValueTextColor(UIColor(.black))
        
        lineChart.data = data
    }
    
    func getChartDataPoints(sessions: [Int], accuracy: [Double]) -> [ChartDataEntry] {
        var dataPoints: [ChartDataEntry] = []
        for count in (0..<sessions.count) {
            dataPoints.append(ChartDataEntry.init(x: Double(sessions[count]), y: accuracy[count]))
        }
       
        
        return dataPoints
    }
    
    func getLineChartDataSet() -> LineChartDataSet {
        
        var 數量 = [Int]()
        var 收 = [Double]()
        var k = 0
        var 日期 = [String]()
        let w_BP1 = re.Test_HR(uid: "Biggg", choose: "28day", Startday: "", Endday: "")
        let i = w_BP1.count
        
        for _ in k...i{
            if(k>=i)
            {
                break;
            }
            else if(w_BP1[0]=="null")
            {
                數量.append(0)
                收.append(0)
                break;
            }
            else{
                let data_BP1 = String(w_BP1[k]!)
                let first:CharacterSet = ["：",","];
                let first2 = data_BP1.components(separatedBy: first)
                數量.append(k)
                收.append(first2[1].toDouble()!)
                日期.append(first2[3])
                print(收)
                k+=1
            }
            
            //var xValues: [String] = 日期
            let xAxis = lineChart.xAxis
            //xValues.append(contentsOf: xValues)
            xAxis.valueFormatter = IndexAxisValueFormatter(values: 日期)
            xAxis.granularity = 1 // 曲線間格為1
            
        }
       
        let dataPoints = getChartDataPoints(sessions: 數量, accuracy : 收)
        //session是放總共有幾筆資料accuracy是放我們收到的數值
        let set = LineChartDataSet(entries: dataPoints, label: "脈搏")
        
        //左邊圖表大小值設定
        let leftAxis = lineChart.leftAxis
        leftAxis.axisMaximum = 160.0
        leftAxis.axisMinimum = 20.0
        leftAxis.labelCount = 7
       
        set.lineWidth = 2
        set.circleRadius = 4
        set.circleHoleRadius = 2
        //let color = ChartColorTemplates.vordiplom()[0]
        set.setColor(UIColor.init(displayP3Red: 242/255, green: 114/255, blue: 86/255, alpha: 1))
        set.setCircleColor(UIColor.init(displayP3Red: 242/255, green: 114/255, blue: 86/255, alpha: 1))
        //設立界線
        let HR = HR_limit.components(separatedBy: first)
        
        let HR上限 = ChartLimitLine(limit: HR[1].toDouble()!, label: "")
        HR上限.lineWidth = 2
        HR上限.lineColor = (UIColor.init(displayP3Red: 242/255, green: 114/255, blue: 86/255, alpha: 1))
        HR上限.lineDashLengths = [5.0, 5.0]   //虛線樣式
        HR上限.labelPosition = .topRight  //位置
        lineChart.leftAxis.addLimitLine(HR上限)  //新增到Y軸上
        lineChart.leftAxis.drawLimitLinesBehindDataEnabled = true  //設定限制線繪製在柱形圖的後面
        
        let HR下限 = ChartLimitLine(limit: HR[3].toDouble()!, label: "")
        HR下限.lineWidth = 2
        HR下限.lineColor = (UIColor.init(displayP3Red: 78/255, green: 131/255, blue: 158/255, alpha: 1))
        HR下限.lineDashLengths = [5.0, 5.0]   //虛線樣式
        HR下限.labelPosition = .topRight  //位置
        lineChart.leftAxis.addLimitLine(HR下限)  //新增到Y軸上
        lineChart.leftAxis.drawLimitLinesBehindDataEnabled = true  //設定限制線繪製在柱形圖的後面
        
        
        //標籤換到下方
        lineChart.xAxis.labelPosition = .bottom
        
        //取消雙擊
        lineChart.doubleTapToZoomEnabled=false
        //設定X軸文字
        lineChart.xAxis.labelTextColor = UIColor.brown
        lineChart.xAxis.labelFont = UIFont.systemFont(ofSize: 5)  //文字字型
        
        //設定y軸文字
        lineChart.rightAxis.enabled = false
        let limit = ChartLimitLine(limit: 36.8, label: "脈搏")
        lineChart.xAxis.addLimitLine(limit)
        lineChart.leftAxis.drawZeroLineEnabled = true   //從0開始繪製
        lineChart.leftAxis.axisLineColor =  UIColor.black  //Y軸顏色
        //設定Y軸上標籤的樣式
        lineChart.leftAxis.labelPosition = .outsideChart   //label位置
        lineChart.leftAxis.labelTextColor = UIColor.brown   //文字顏色
        lineChart.leftAxis.labelFont = UIFont.systemFont(ofSize: 8)  //文字字型
        return set
    }
    
} //28dayHR

struct LineChartSwiftUI_28SpO2: UIViewRepresentable {
    let lineChart = LineChartView()
    
    // let BP1 = Double(w_BP1[1]!)
    func makeUIView(context: UIViewRepresentableContext<LineChartSwiftUI_28SpO2>) -> LineChartView {
        setUpChart()
        return lineChart
    }
    
    func updateUIView(_ uiView: LineChartView, context: UIViewRepresentableContext<LineChartSwiftUI_28SpO2>) {
        
    }
    
    func setUpChart() {
        lineChart.noDataText = "No Data Available"
        let dataSets = [getLineChartDataSet()]
        let data = LineChartData(dataSets: dataSets)
        data.setValueFont(.systemFont(ofSize: 10, weight: .light))
        data.setValueTextColor(UIColor(.black))
        
        lineChart.data = data
    }
    
    func getChartDataPoints(sessions: [Int], accuracy: [Double]) -> [ChartDataEntry] {
        var dataPoints: [ChartDataEntry] = []
        for count in (0..<sessions.count) {
            dataPoints.append(ChartDataEntry.init(x: Double(sessions[count]), y: accuracy[count]))
        }
        return dataPoints
    }
    
    func getLineChartDataSet() -> LineChartDataSet {
        
        var 數量 = [Int]()
        var 收 = [Double]()
        var k = 0
        var 日期 = [String]()
        let w_BP1 = re.Test_SpO2(uid: "Biggg", choose: "28day", Startday: "", Endday: "")
        let i = w_BP1.count
        
        for _ in k...i{
            if(k>=i)
            {
                break;
            }
            else if(w_BP1[0]=="null")
            {
                數量.append(0)
                收.append(0)
                break;
            }
            else{
                let data_BP1 = String(w_BP1[k]!)
                let first:CharacterSet = ["：",","];
                let first2 = data_BP1.components(separatedBy: first)
                數量.append(k)
                收.append(first2[1].toDouble()!)
                日期.append(first2[3])
                print(收)
                k+=1
            }
            
            //var xValues: [String] = 日期
            let xAxis = lineChart.xAxis
            //xValues.append(contentsOf: xValues)
            xAxis.valueFormatter = IndexAxisValueFormatter(values: 日期)
            xAxis.granularity = 1 // 曲線間格為1
        }
        
        let dataPoints = getChartDataPoints(sessions: 數量, accuracy : 收)
        //session是放總共有幾筆資料accuracy是放我們收到的數值
        let set = LineChartDataSet(entries: dataPoints, label: "血氧")
        
        //左邊圖表大小值設定
        let leftAxis = lineChart.leftAxis
        leftAxis.axisMaximum = 100.0
        leftAxis.axisMinimum = 70.0
        leftAxis.labelCount = 16
        
        set.lineWidth = 2
        set.circleRadius = 4
        set.circleHoleRadius = 2
        //let color = ChartColorTemplates.vordiplom()[0]
        set.setColor(UIColor.init(displayP3Red: 78/255, green: 131/255, blue: 158/255, alpha: 1))//折線圖顏色
        set.setCircleColor(UIColor.init(displayP3Red: 78/255, green: 131/255, blue: 158/255, alpha: 1))//折線圖點的顏色
        //設立界線
        let SpO2 = SpO2_limit.components(separatedBy: first)
        
        let 血氧下限 = ChartLimitLine(limit: SpO2[1].toDouble()!, label: "")
        血氧下限.lineWidth = 2
        血氧下限.lineColor = (UIColor.init(displayP3Red: 242/255, green: 114/255, blue: 86/255, alpha: 1))
        血氧下限.lineDashLengths = [5.0, 5.0]   //虛線樣式
        血氧下限.labelPosition = .topRight  //位置
        lineChart.leftAxis.addLimitLine(血氧下限)  //新增到Y軸上
        lineChart.leftAxis.drawLimitLinesBehindDataEnabled = true  //設定限制線繪製在柱形圖的後面
       
        
        
        //標籤換到下方
        lineChart.xAxis.labelPosition = .bottom
        
        //取消雙擊
        lineChart.doubleTapToZoomEnabled=false
        //設定X軸文字
        lineChart.xAxis.labelTextColor = UIColor.brown
        lineChart.xAxis.labelFont = UIFont.systemFont(ofSize: 6.5)  //文字字型
        
        //設定y軸文字
        lineChart.rightAxis.enabled = false
        lineChart.leftAxis.drawZeroLineEnabled = true   //從0開始繪製
        lineChart.leftAxis.axisLineColor =  UIColor.black  //Y軸顏色
        //設定Y軸上標籤的樣式
        lineChart.leftAxis.labelPosition = .outsideChart   //label位置
        lineChart.leftAxis.labelTextColor = UIColor.brown   //文字顏色
        lineChart.leftAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        //xValues.append(contentsOf: xValues)
        lineChart.xAxis.valueFormatter = IndexAxisValueFormatter(values: 日期)
        
        //session是放總共有幾筆資料accuracy是放我們收到的數值
        return set
    }
    
} //28daySpO2

struct LineChartSwiftUI_28BP: UIViewRepresentable {
    let lineChart = LineChartView()
    
    // let BP1 = Double(w_BP1[1]!)
    func makeUIView(context: UIViewRepresentableContext<LineChartSwiftUI_28BP>) -> LineChartView {
        getLineChartDataSet()
        return lineChart
    }
    
    func updateUIView(_ uiView: LineChartView, context: UIViewRepresentableContext<LineChartSwiftUI_28BP>) {
        
    }
    
    func getChartDataPoints(sessions: [Int], accuracy: [Double]) -> [ChartDataEntry] {
        
        var dataPoints: [ChartDataEntry] = []
        for count in (0..<sessions.count) {
            dataPoints.append(ChartDataEntry.init(x: Double(sessions[count]), y: accuracy[count]))
        }
        return dataPoints
    }
    
    func getChartDataPoints2(sessions: [Int], accuracy: [Double]) -> [ChartDataEntry] {
        var dataPoints2: [ChartDataEntry] = []
        for count in (0..<sessions.count) {
            dataPoints2.append(ChartDataEntry.init(x: Double(sessions[count]), y: accuracy[count]))
        }
        return dataPoints2
    }
    
    func getLineChartDataSet() {
        
        var 數量 = [Int]()
        var 收 = [Double]()
        var 縮 = [Double]()
        var k = 0
        var 日期 = [String]()
        let w_BP1 = re.Test_BP(uid: "Biggg", choose: "28day", Startday: "", Endday: "")
        let i = w_BP1.count
        
        for _ in k...i{
            if(k>=i)
            {
                break;
            }
            else if(w_BP1[0]=="null")
            {
                數量.append(0)
                收.append(0)
                break;
            }
            else{
                let data_BP1 = String(w_BP1[k]!)
                let first:CharacterSet = ["：",","];
                let first2 = data_BP1.components(separatedBy: first)
                數量.append(k)
                收.append(first2[1].toDouble()!)
                縮.append(first2[3].toDouble()!)
                print(收)
                print(縮)
                日期.append(first2[5])
                k+=1
            }
         
            let xAxis = lineChart.xAxis
            //xValues.append(contentsOf: xValues)
            xAxis.valueFormatter = IndexAxisValueFormatter(values: 日期)
            xAxis.granularity = 1 // 曲線間格為1
            
        }
        
        let dataPoints = getChartDataPoints(sessions: 數量, accuracy : 收)
        let dataPoints2 = getChartDataPoints2(sessions: 數量, accuracy : 縮)
        //session是放總共有幾筆資料accuracy是放我們收到的數值
        let set = LineChartDataSet(entries: dataPoints, label: "收縮壓")
        let set2 = LineChartDataSet(entries: dataPoints2, label: "舒張壓")
        
        //左邊圖表大小值設定
        let leftAxis = lineChart.leftAxis
        leftAxis.axisMaximum = 200.0
        leftAxis.axisMinimum = 40.0
        leftAxis.labelCount = 8
        //
        set.lineWidth = 2.5
        set.circleRadius = 4
        set.circleHoleRadius = 2
        //
        set2.lineWidth = 2.5
        set2.circleRadius = 4
        set2.circleHoleRadius = 2
        //
        set.setColor(UIColor.init(displayP3Red: 78/255, green: 131/255, blue: 158/255, alpha: 1))//折線圖顏色
        set.setCircleColor(UIColor.init(displayP3Red: 78/255, green: 131/255, blue: 158/255, alpha: 1))//折線圖點的顏色
        set2.setColor(UIColor.init(displayP3Red: 242/255, green: 114/255, blue: 86/255, alpha: 1))
        set2.setCircleColor(UIColor.init(displayP3Red: 242/255, green: 114/255, blue: 86/255, alpha: 1))
        let data = LineChartData(dataSets: [set, set2])
        data.setValueFont(.systemFont(ofSize: 10, weight: .light))
        data.setValueTextColor(UIColor(.black))
        lineChart.data = data
     
        //設立界線
        let BP = BP_limit.components(separatedBy: first)
        
        let 收縮上限 = ChartLimitLine(limit: BP[1].toDouble()!, label: "")
        收縮上限.lineWidth = 2
        收縮上限.lineColor = (UIColor.init(displayP3Red: 242/255, green: 114/255, blue: 86/255, alpha: 1))
        收縮上限.lineDashLengths = [5.0, 5.0]   //虛線樣式
        收縮上限.labelPosition = .topRight  //位置
        lineChart.leftAxis.addLimitLine(收縮上限)  //新增到Y軸上
        lineChart.leftAxis.drawLimitLinesBehindDataEnabled = true  //設定限制線繪製在柱形圖的後面
        
        let 收縮下限 = ChartLimitLine(limit: BP[3].toDouble()!, label: "")
        收縮下限.lineWidth = 2
        收縮下限.lineColor = (UIColor.init(displayP3Red: 78/255, green: 131/255, blue: 158/255, alpha: 1))
        收縮下限.lineDashLengths = [5.0, 5.0]   //虛線樣式
        收縮下限.labelPosition = .topRight  //位置
        lineChart.leftAxis.addLimitLine(收縮下限)  //新增到Y軸上
        lineChart.leftAxis.drawLimitLinesBehindDataEnabled = true  //設定限制線繪製在柱形圖的後面
        
        //
        let 舒張上限 = ChartLimitLine(limit: BP[5].toDouble()!, label: "")
        舒張上限.lineWidth = 2
        舒張上限.lineColor = (UIColor.init(displayP3Red: 242/255, green: 114/255, blue: 86/255, alpha: 1))
        舒張上限.lineDashLengths = [5.0, 5.0]   //虛線樣式
        舒張上限.labelPosition = .topRight  //位置
        lineChart.leftAxis.addLimitLine(舒張上限)  //新增到Y軸上
        lineChart.leftAxis.drawLimitLinesBehindDataEnabled = true  //設定限制線繪製在柱形圖的後面
        
        let 舒張下限 = ChartLimitLine(limit: BP[7].toDouble()!, label: "")
        舒張下限.lineWidth = 2
        舒張下限.lineColor = (UIColor.init(displayP3Red: 78/255, green: 131/255, blue: 158/255, alpha: 1))
        舒張下限.lineDashLengths = [5.0, 5.0]   //虛線樣式
        舒張下限.labelPosition = .topRight  //位置
        lineChart.leftAxis.addLimitLine(舒張下限)  //新增到Y軸上
        lineChart.leftAxis.drawLimitLinesBehindDataEnabled = true  //設定限制線繪製在柱形圖的後面
        
        //
        data.setValueFont(.systemFont(ofSize: 10, weight: .light))
        data.setValueTextColor(UIColor(.black))
        lineChart.data = data
        //標籤換到下方
        lineChart.xAxis.labelPosition = .bottom
        //取消雙擊
        lineChart.doubleTapToZoomEnabled=false
        //設定X軸文字
        
        lineChart.xAxis.labelTextColor = UIColor.brown
        lineChart.xAxis.labelFont = UIFont.systemFont(ofSize: 6.5)  //文字字型
        
        //設定y軸文字
        lineChart.rightAxis.enabled = false
        lineChart.leftAxis.drawZeroLineEnabled = true   //從0開始繪製
        lineChart.leftAxis.axisLineColor =  UIColor.black  //Y軸顏色
        //設定Y軸上標籤的樣式
        lineChart.leftAxis.labelPosition = .outsideChart   //label位置
        lineChart.leftAxis.labelTextColor = UIColor.brown   //文字顏色
        lineChart.leftAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
       
       
        //session是放總共有幾筆資料accuracy是放我們收到的數值
        
    }//7dayHR
    
}//28dayBP

struct LineChartSwiftUI_28Temp: UIViewRepresentable {
    let lineChart = LineChartView()
    
    // let BP1 = Double(w_BP1[1]!)
    func makeUIView(context: UIViewRepresentableContext<LineChartSwiftUI_28Temp>) -> LineChartView {
        setUpChart()
        return lineChart
    }
    
    func updateUIView(_ uiView: LineChartView, context: UIViewRepresentableContext<LineChartSwiftUI_28Temp>) {
        
    }
    
    func setUpChart() {
        lineChart.noDataText = "No Data Available"
        let dataSets = [getLineChartDataSet()]
        let data = LineChartData(dataSets: dataSets)
        data.setValueFont(.systemFont(ofSize: 10, weight: .light))
        data.setValueTextColor(UIColor(.black))
        lineChart.data = data
        
    }
    
    func getChartDataPoints(sessions: [Int], accuracy: [Double]) -> [ChartDataEntry] {
        var dataPoints: [ChartDataEntry] = []
        for count in (0..<sessions.count) {
            dataPoints.append(ChartDataEntry.init(x: Double(sessions[count]), y: accuracy[count]))
        }
        lineChart.xAxis.labelCount = dataPoints.count
        return dataPoints
    }
    
    func getLineChartDataSet() -> LineChartDataSet {
        
        var 數量 = [Int]()
        var 收 = [Double]()
        var k = 0
        var 日期 = [String]()
        let w_BP1 = re.Test_Temp(uid: "Biggg", choose: "28day", Startday: "", Endday: "")
        let i = w_BP1.count
        
        for _ in k...i{
            if(k>=i)
            {
                break;
            }
            else if(w_BP1[0]=="null")
            {
                數量.append(0)
                收.append(0)
                break;
            }
            else{
                let data_BP1 = String(w_BP1[k]!)
                let first:CharacterSet = ["：",","];
                let first2 = data_BP1.components(separatedBy: first)
                數量.append(k)
                收.append(first2[1].toDouble()!)
                print(收)
                日期.append(first2[3])
                k+=1
            }
            
            //var xValues: [String] = 日期
            let xAxis = lineChart.xAxis
            //xValues.append(contentsOf: xValues)
            xAxis.valueFormatter = IndexAxisValueFormatter(values: 日期)
            xAxis.granularity = 1 // 曲線間格為1
            
        }
        
        let dataPoints = getChartDataPoints(sessions: 數量, accuracy : 收)
        //session是放總共有幾筆資料accuracy是放我們收到的數值
        let set = LineChartDataSet(entries: dataPoints, label: "體溫")
        
        //左邊圖表大小值設定
        let leftAxis = lineChart.leftAxis
        leftAxis.axisMaximum = 40.0
        leftAxis.axisMinimum = 35.0
        leftAxis.labelCount = 10
        
        set.lineWidth = 2
        set.circleRadius = 4
        set.circleHoleRadius = 2
        //let color = ChartColorTemplates.vordiplom()[0]
        set.setColor(UIColor.init(displayP3Red: 78/255, green: 131/255, blue: 158/255, alpha: 1))//折線圖顏色
        set.setCircleColor(UIColor.init(displayP3Red: 78/255, green: 131/255, blue: 158/255, alpha: 1))//折線圖點的顏色
        
        //設立界線
        let Temp = Temp_limit.components(separatedBy: first)
        
        let Temp上限 = ChartLimitLine(limit: Temp[1].toDouble()!, label: "")
        Temp上限.lineWidth = 2
        Temp上限.lineColor = (UIColor.init(displayP3Red: 242/255, green: 114/255, blue: 86/255, alpha: 1))//red
        Temp上限.lineDashLengths = [5.0, 5.0]   //虛線樣式
        Temp上限.labelPosition = .topRight  //位置
        lineChart.leftAxis.addLimitLine(Temp上限)  //新增到Y軸上
        lineChart.leftAxis.drawLimitLinesBehindDataEnabled = true  //設定限制線繪製在柱形圖的後面
       
        let Temp下限 = ChartLimitLine(limit: Temp[3].toDouble()!, label: "")
        Temp下限.lineWidth = 2
        Temp下限.lineColor = (UIColor.init(displayP3Red: 78/255, green: 131/255, blue: 158/255, alpha: 1))//blue
        Temp下限.lineDashLengths = [5.0, 5.0]   //虛線樣式
        Temp下限.labelPosition = .topRight  //位置
        lineChart.leftAxis.addLimitLine(Temp下限)  //新增到Y軸上
        lineChart.leftAxis.drawLimitLinesBehindDataEnabled = true  //設定限制線繪製在柱形圖的後面
       
        
        
        //標籤換到下方
        lineChart.xAxis.labelPosition = .bottom
        
        //取消雙擊
        lineChart.doubleTapToZoomEnabled=false
        //設定X軸文字
        lineChart.xAxis.labelTextColor = UIColor.brown
        lineChart.xAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        
        //設定y軸文字
        lineChart.rightAxis.enabled = false
        lineChart.leftAxis.drawZeroLineEnabled = true   //從0開始繪製
        lineChart.leftAxis.axisLineColor =  UIColor.black  //Y軸顏色
        //設定Y軸上標籤的樣式
        lineChart.leftAxis.labelPosition = .outsideChart   //label位置
        lineChart.leftAxis.labelTextColor = UIColor.brown   //文字顏色
        lineChart.leftAxis.labelFont = UIFont.systemFont(ofSize: 10)  //文字字型
        
        // 設定X軸文字
       
        //session是放總共有幾筆資料accuracy是放我們收到的數值
        
        return set
    }
} //28dayTemp


