//
//  icanseeApp.swift
//  icansee
//
//  Created by WenLi Lee on 2020/11/1.
//

import SwiftUI

@main
struct icanseeApp: App {
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        
        }
    }
}
