//
//  ContentView.swift
//  exGPS
//
//  Created by WenLi Lee on 2021/3/1.
//
import MapKit
import SwiftUI
import CoreLocation

//let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()



struct GpsView: View {
    @State private var region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 25.042552, longitude: 121.444725), span: MKCoordinateSpan(latitudeDelta: 0.5, longitudeDelta: 0.5))
    @State var tracknig : MapUserTrackingMode = .follow
    @State var manager = CLLocationManager()
    @StateObject var managerDelegate = locationDelegate()
    
    let timer = Timer.publish(every: 30, on: .main, in: .common).autoconnect()

    var body: some View {
        VStack{
            MapView().edgesIgnoringSafeArea(.all)
             
        }
    }
}

struct GpsView_Previews: PreviewProvider {
    static var previews: some View {
        GpsView()
    }
}

class locationDelegate : NSObject,ObservableObject,CLLocationManagerDelegate{
    var locationManager = CLLocationManager()
    
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        locationManager.requestWhenInUseAuthorization()
        if CLLocationManager.authorizationStatus() == .authorizedWhenInUse {
            print("authorized..")
        }
        else{
            print("not autorized..")
        }
    }
}

let timer = Timer.publish(every: 30, on: .main, in: .common).autoconnect()


struct MapView: UIViewRepresentable {
    let mapView = MKMapView(frame: UIScreen.main.bounds)
    var locationManager = CLLocationManager()
    let geocoder: CLGeocoder = CLGeocoder()
    func setupManager() {
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        locationManager.requestAlwaysAuthorization()
        locationManager.distanceFilter =  CLLocationDistance(10); //每十公尺更新一次座標
        locationManager.startUpdatingLocation()  //開始update位置
    }
    func makeUIView(context: Context) -> MKMapView {
        
        setupManager()
        
        let point:MKPointAnnotation = MKPointAnnotation();
        //設定大頭針的座標位置(固定的位置)
        point.title = "銘傳大學"
        point.coordinate = CLLocationCoordinate2D(latitude:24.985144, longitude:121.344205)//(緯度,經度)
        //定位你現在的位置
        point.subtitle = "緯度：\(String(describing: locationManager.location?.coordinate.latitude))" +
        "/ 經度:\(String(describing: locationManager.location?.coordinate.longitude))"
        mapView.addAnnotation(point)
        mapView.showsUserLocation = true
        mapView.userTrackingMode = .follow
        return mapView
    }
    func updateUIView(_ uiView: MKMapView, context: Context) {
        let gps = String(describing: locationManager.location?.coordinate.latitude)
        let gps2 = String(describing: locationManager.location?.coordinate.longitude)
        let first:CharacterSet = ["(",")"];
        let first2 = gps.components(separatedBy: first)
        let first3 = gps2.components(separatedBy: first)
    }
}

